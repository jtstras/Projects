// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 7 - Problem 1

#include <iostream>
#include <string>
#include <fstream>
#include "User.h"
using namespace std;

//These are the Member functions for class "User" class per the specifications provided

User::User()//default constructor sets variables to default
{
    username="";
    numRatings=0;
    
    size=50;//size always 50
    ratings[size];
    for(int i=0;i<size;i++)
    {
    ratings[i]=0;//populating array with 0
    }
    
}

User::User(string s,int arr[], int i)//Parameterized Constructor that intializes variables with inputs
{
    username=s;
    for (int j=0;j<i;j++)
    {
     ratings[j]=arr[j];
    }
    if (i < 50)
    {
        int k=50-i;
        for (int m=0;m<k;m++)
        {
            ratings[0+i+m]=0;
        }
    }
    numRatings=i;
}

string User::getUsername()//grabs username
{
    return username;
}

void User::setUsername(string u)//sets username with input
{
    username=u;
}

int User::getRatingAt(int index)//grabs rating at index
{
    if (index >= 50 || index < 0)
    {
        return -1;
    }
    int holdRating;
    holdRating=ratings[index];
    return holdRating;
}

bool User::setRatingAt(int index, int value)//sets rating to value at the index
{
    if (index < 50 && value < 6 && value >= 0)
    {
    ratings[index]=value;
    return true;
    }
    else
    {
        return false;
    }
}

int User::getNumRatings()//grabs numRatings
{
    return numRatings;
}

void User::setNumRatings(int j)//sets numRatings
{
    numRatings=j;
}

int User::getSize()//grabs the size
{
    return size;
}

