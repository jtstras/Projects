// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 7 - Problem 2

#include "User.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

/**
* This function splits the input string into pieces seperated by the delimiter, and then takes the pieces and 
* inserts them into an array up to the number of split pieces
* 
* 1.while the string at index i
* if the index at i equals the delimiter ot the index at i is the end of the string
* then if the reset variable is not equal to i
*    then if counter is equal to the size of the array, return -1 because the array cannot be smaller than the number of substrings
*    if not at counter index of words insert the substring of split at reset and reset minus i
* set reset equal to i plus 1
* return count
*
 *Input parameters:string for the variable to be split, delimiter must be a char, the array must be a string type, the size of array must be int
 * Output:nothing
 * Returns:number of pieces string was split into
 */ 

int split(string split, char delimiter, string words[], int size)
{
int count=0,i=0,reset=0;//declaring three variables we will use all integers

while(i<=split.length()) //loops through the string
{
    if(split[i]==delimiter||split[i]=='\0') //if split at index i or split at i is end of the string
    {
        if(reset!=i) //if start is not equal to i then
        {
            if(count==size)//if count equal to size of array then
            {
            return -1; //returns -1
            }
        words[count++] = split.substr(reset,i-reset); //adds the substring into words array and increments the count by 1
        }
      reset = i+ 1; //assigns i+1 to reset
     }
    i++; //increments i by 1
}
    return count; //returns the count
}

/**
* This function combines the usernames and ratings of books into a Class object array
* 
* 1.open text file
* 2.if number of user sis greater than array size, return -2
* 3.if file is open
*   while grabbing each line
*   if line isnt empty
*       create temp array
*       call split function to parse the txt file
*           populate the user class array with the usernames and ratings grabbed form the txt file
*           if the number of users in the system equals the number of rows return -1
* 4.else return -1
*
 * Input parameters:string for the file name, User class object for the array, int for the number of users stored, int for the users array size,
 * int for the max number of columns 
 * Output:nothing
 * Returns:total number of users in the system
 */ 

int readRatings(string fileName, User users[], int numUsersStored, int usersArrSize, int maxCol)
{
string word = "";//create a variable for words
int count = numUsersStored;//set count to the number of users stored

ifstream myfile;//output stream
myfile.open(fileName);//Open the text file

if (numUsersStored >= usersArrSize)//When numUsersStored is greater than or equal to the usersArrSize, return -2
{
    return -2;
}

if (myfile.is_open())
{
    while (getline(myfile, word)) //Read each line from the text file
    {
            if (word != "")//make sure line isnt empty
            {
              string array[51];//temp array
              int j=split(word, ',', array, 51);        //Split each line
              users[count].setUsername(array[0]);       //populating the Users array with the usernames from the temp array grabbed from txt file                                  
              for (int i = 1; i < j; i++)
              {
              users[count].setRatingAt((i-1),stoi(array[i])); //populating the Users array with the ratings from the temp array grabbed from txt file
                                                              //stoi converting string to int
              }                         
              count++;//add 1 to count
              if (count == usersArrSize)//blocks a segmentation fault because total users in system cannot be accessed outside of while loop if it equals number of rows
              {
              return count;
              }
             }
     }
      return count;//return count
}

else // if anything else will return -1.
{
                return -1;
}

}

int main()
{
//test 1
//expected output:4 because the file contains 4 usernames
User users[10];
int numUsers = 0;
int maxRows = 10;
int maxColumns = 50;
numUsers = readRatings("money.txt", users, numUsers, maxRows, maxColumns);
cout << "Function returned value: " << numUsers << endl;

//test 2
//expected output:-1 because the file does not exist
User users2[10];
int numUsers2 = 0;
int maxRows2 = 10;
int maxColumns2 = 50;
cout<<readRatings("fileisnthere.txt", users2, numUsers2, maxRows2, maxColumns2)<<endl;


}