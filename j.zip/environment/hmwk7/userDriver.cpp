#include "User.h"
using namespace std;

//Test cases for the Member functions of the User Class

int main()
{
    User obj1=User();//testing Default
    string obj1_username=obj1.getUsername();//getting username
    int obj1_numRate=obj1.getNumRatings();//getting numRatings
    int size=50;//size is 50
    int ratings[size];
    
    int obj1_size=obj1.getSize();
    cout<<"size:"<<obj1_size<<endl;//testing size getter
    
    for(int i=0;i<size;i++)
    {
    cout<<obj1.getRatingAt(i)<<endl;//getting rating at i
    }
    if (obj1_username == "")//testing default
   {
      cout<<"Good stuff"<<endl;
   }
   if (obj1_numRate == 0)//testing default
   {
      cout<<"Good stuff"<<endl;
   }
   if (obj1_size == 0)//
   {
      cout<<"Good stuff"<<endl;
   }
   
   string s="fun tub";int i=50;
   int arr[50]={53,5,0,3,4,0,4,0,3,4,1,4,5,1,5,0,3,0,4,3,3,0,2,1,0,0,3,2,1,2,1,4,2,2,5,3,2,5,4,2,1,3,1,4,2,2,1,3,3,1};

   User obj2=User(s, arr, i);//testing Parameterized
   string obj2_username=obj2.getUsername();
   int obj2_numRate=obj2.getNumRatings();
   if (obj2_username == "fun tub")
   {
       cout<<"Good stuff"<<endl;
   }
    if (obj2_numRate == 50)//
   {
      cout<<"Good stuff"<<endl;
   }
   for(int j=0;j<size;j++)
    {
    cout<<obj2.getRatingAt(j)<<endl;
    }
    
    obj2.setUsername("jjdwizzle");//Testing setters and getters
    cout<<"username:"<<obj2.getUsername()<<endl;;
    
    obj2.setRatingAt(6, 3);
    cout<<"rating:"<<obj2.getRatingAt(6)<<endl;;
    
    obj2.setNumRatings(15);
    cout<<"num rating:"<<obj2.getNumRatings()<<endl;;

    
}