#include <iostream>
using namespace std;

//This is the header file for the User class, check User.cpp for comments on what these member functions do

class User
{
    private://Data members
    string username;
    int numRatings;
    int size;
   int ratings[50];
    
    public://Declaring all the member functions
    User();
    User(string s,int arr[], int i);
    string getUsername();
    void setUsername(string u);
    int getRatingAt(int index);
    bool setRatingAt(int index, int value);
    int getNumRatings();
    void setNumRatings(int j);
    int getSize();
};
