// Author: Jaret Strasheim
// Recitation: 304
// Homework 7 - Problem 5

#include "User.h"
#include "Book.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;

string to_lower(string s)//this helper function will convert a string to all lowercase characters
{
    
    string lowercase="";
    for (int i=0;i<s.length();i++)
    {
        lowercase += tolower(s[i]);//using tolower to lower upper to lower case characters
    }
     return lowercase;
    
}

/**
* This function calculates the average of the ratings of the books rated by users
* 
* 1.if no users return -3
* 2.if the title is the title input
*   hold that index
* 3.if book title does not exist return -3
* 4.the sum of the ratings equals the rating at the held index plus the sum
* 5.if the rating is greater than zero
*   add to count
*6.return sum divided by count
* 
 *Input parameters:User class object array, Book clas object array, integer for number of users, int for number of books,string for the title
 * Output:nothing
 * Returns:average rating of the books
 */ 


double calcAverageRating(User users[], Book books[], int numUsers, int numBooks, string title)
{
    if (numUsers==0)//if no users exist
    return -3;
    int holdIndex=-1;
    string temp1=to_lower(title);//lowering the case of title
    
    for (int i=0;i<numBooks;i++)
    {
    if (to_lower(books[i].getTitle())==temp1)//lower case version of get username compared to username
    {
        holdIndex=i;//hold that index
    }
    }
    if (holdIndex==-1)//if the book title does not exist
        return -3;
    
    double sum=0;
    double count2=0;
    for (int j=0;j<numUsers;j++)//loop through
    {
        sum=users[j].getRatingAt(holdIndex)+sum;//sum equals users at j index and grab rating at heldindex
        if(users[j].getRatingAt(holdIndex) > 0)//if rating is greater than 0
        {
            count2++;//add to count
        }
    }
    if (count2==0)//book has not been read by anyone
        return 0;//return 0
        
    return sum/count2;
}

int main()
{
//Create list of books
Book books[2];
books[0].setTitle("Title1");
books[0].setAuthor("Author1");
books[1].setTitle("Title2");
books[1].setAuthor("Author2");
//Create list of users
User users[2];
//Setting username and ratings for User1
users[0].setUsername("User1");
users[0].setNumRatings(2);
users[0].setRatingAt(0,2);
users[0].setRatingAt(1,2);
//Setting username and ratings for User2
users[1].setUsername("User2");
users[1].setNumRatings(4);
users[1].setRatingAt(0,4);
users[1].setRatingAt(1,3);
// calcAvgRating for Title2

//test 1
//expected output:3 because user 1 rated 2 and user 2 rated 4 and 6/2=3
cout <<calcAverageRating(users, books, 2, 2,"Title1")<<endl;

//test 2
//expected output:2.5 because user 1 rated 2 and user 2 rated 3 and 5/2=2.5
cout <<calcAverageRating(users, books, 2, 2,"Title2");

}