// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 7 - Problem 4

#include "User.h"
#include "Book.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;


/**
* This function count how many books a user has rated
* 
* 1.lower the username and title to be case insensitive
* 2.if no books exist return -3
* 3.for the number of users, if the lower case version of the grabbed username equals the username
*   hold that index
* 4.if the username doesnt exist return -3
* 5.for the number of books if a rating of a book in users array at the held index is greater than zero
*   add to count
*6.return count
* 
 *Input parameters:string for the username, User class object array, integer for number of users, int for number of books
 * Output:nothing
 * Returns:number of ratings of the book
 */ 

string to_lower(string s)//this helper function will convert a string to all lowercase characters
{
    
    string lowercase="";
    for (int i=0;i<s.length();i++)
    {
        lowercase += tolower(s[i]);//using tolower to lower upper to lower case characters
    }
     return lowercase;
    
}

int getCountReadBooks (string username, User users[], int numUsers, int numBooks)
{
int count=0;//all the counter variables
int holdIndex=0;
int testCaseCount=0;
string temp1=to_lower(username);
if (numBooks==0)//if there are no books
{
    return -3;
}

for (int i=0;i<numUsers;i++)
{
    if (to_lower(users[i].getUsername())==temp1)//lower case version of get username compared to username
    {
        holdIndex=i;//hold that index
        testCaseCount++;//for if the username does not exist
    }
   
}

if (testCaseCount==0)//if username does not exist
{
    return -3;
}
        
for (int j=0;j<numBooks;j++)//iterate as many times as num books
{
        if (users[holdIndex].getRatingAt(j) > 0)//if the rating at the held index of users is greater than zero
            {
                 count++;//add 1 to count
            }
        
}
        return count;
}



int main()
{
//Creating 2 users
User users[2];
//Setting username and ratings for User1
users[0].setUsername("User1");
users[0].setNumRatings(2);
users[0].setRatingAt(0,2);
users[0].setRatingAt(1,2);
//Setting username and ratings for User2
users[1].setUsername("User2");
users[1].setNumRatings(4);
users[1].setRatingAt(0,4);
users[1].setRatingAt(1,4);
users[1].setRatingAt(2,3);

//test 1
//expected output:2 because the user has rated two books
cout << getCountReadBooks("User1",users,2,6) <<endl;

//test 2
//expected output:3 because the user has rated three books
cout << getCountReadBooks("User2",users,2,6) <<endl;
}