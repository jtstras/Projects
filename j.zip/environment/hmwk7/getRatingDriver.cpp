// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 7 - Problem 3

#include "User.h"
#include "Book.h"
#include <iostream>
#include <fstream>
#include <string>
#include <ctype.h>
using namespace std;

/**
* This function  given a user’s name and a book’s title returns the rating that the user
 gave for that book.
* 
* 1.loop through users array checking for username
* 2.loop through book array checking for title
* 3.if both the title and username are found
* return the rating of the book at the users index
*
 *Input parameters:string for the username, string for the title, User class object array, Book class object array, int for numUsers and NumBooks
 * Output:nothing
 * Returns:rating by the user of the matching book
 */ 
 
string to_lower(string s)//this helper function will convert a string to all lowercase characters
{
    
    string lowercase="";
    for (int i=0;i<s.length();i++)
    {
        lowercase += tolower(s[i]);//using tolower to lower upper to lower case characters
    }
     return lowercase;
    
}

int getRating (string username, string title, User users[], Book books[], int numUsers, int numBooks)
{
    string temp=to_lower(username);//temps to hold the lowered username and title
    string temp2=to_lower (title);
    int foundUser=0;
    int holdIndex=0;
    if (numBooks <= 0)
    {
        return -3;
    }
    for (int i=0;i<numUsers;i++)
    {
        if (to_lower(users[i].getUsername())==temp)//looping through the users array to check if the username is there
        {
            foundUser++;//counter
            holdIndex=i;//grabbing that index
        }
    }
      int foundBook=0;
      int hold2=0;
      for (int j=0;j<numUsers;j++)
    {
        if (to_lower(books[j].getTitle())==temp2)//looping through the books array to check if the title is there
        {
            foundBook++;//counter
            hold2=j;//grabbing index
        }
    }
    if (foundUser > 0 && foundBook > 0)//if both the title and username exist
    {
        return users[holdIndex].getRatingAt(hold2);//return the rating at user index of username at get rating of the index of the title
    }
    else
    {
        return -3;//for other cases
    }
}


int main()
{
    //Creating 3 books
    Book books[3];
    //Setting book title and author for book 1
    books[0].setTitle("Stories");
    books[0].setAuthor("Yessir");
    //Setting book title and author for book 2
    books[1].setTitle("Clifford");
    books[1].setAuthor("Mamacita");
    //Setting book title and author for book 3
    books[2].setTitle("Money");
    books[2].setAuthor("Bookman");
    //Creating 2 users
    User users[2];
    //Setting username and ratings for User1
    users[0].setUsername("Jerry");
    users[0].setNumRatings(3);
    users[0].setRatingAt(0,1);
    users[0].setRatingAt(1,4);
    users[0].setRatingAt(2,2);
    //Setting username and ratings for User2
    users[1].setUsername("Healthyman");
    users[1].setNumRatings(3);
    users[1].setRatingAt(0,0);
    users[1].setRatingAt(1,5);
    users[1].setRatingAt(2,3);
    
    //test 1 
    //expected output:4 because Clifford is the 2nd book rating of Jerry
    cout<<getRating("Jerry", "Clifford", users, books, 2, 3)<<endl;
    
    //test 2 
    //expected output:0 because Stories is the 1st book rating of Healthyman
    cout<<getRating("Healthyman", "Stories", users, books, 2, 3)<<endl;
}