// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 7 - Problem 6

#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include "User.h"
#include "Book.h"
using namespace std;

int printMenu(){//print menu function from assignment
    cout << "======Main Menu=====" << endl;
    cout << "1. Read books" << endl;
    cout << "2. Read ratings" << endl;
    cout << "3. Get rating" << endl;
    cout << "4. Find number of books user rated" << endl;
    cout << "5. Get average rating" << endl;
    cout << "6. Quit" << endl;
    int number;
    cin>>number;
    return number;
}

/**
* This function count how many books a user has rated
* 
* 1.lower the username and title to be case insensitive
* 2.if no books exist return -3
* 3.for the number of users, if the lower case version of the grabbed username equals the username
*   hold that index
* 4.if the username doesnt exist return -3
* 5.for the number of books if a rating of a book in users array at the held index is greater than zero
*   add to count
*6.return count
* 
 *Input parameters:string for the username, User class object array, integer for number of users, int for number of books
 * Output:nothing
 * Returns:number of ratings of the book
 */ 

string to_lower(string s)//this helper function will convert a string to all lowercase characters
{
    
    string lowercase="";
    for (int i=0;i<s.length();i++)
    {
        lowercase += tolower(s[i]);//using tolower to lower upper to lower case characters
    }
     return lowercase;
    
}

int getCountReadBooks (string username, User users[], int numUsers, int numBooks)
{
int count=0;//all the counter variables
int holdIndex=0;
int testCaseCount=0;
string temp1=to_lower(username);
if (numBooks==0)//if there are no books
{
    return -3;
}

for (int i=0;i<numUsers;i++)
{
    if (to_lower(users[i].getUsername())==temp1)//lower case version of get username compared to username
    {
        holdIndex=i;//hold that index
        testCaseCount++;//for if the username does not exist
    }
   
}

if (testCaseCount==0)//if username does not exist
{
    return -3;
}
        
for (int j=0;j<numBooks;j++)//iterate as many times as num books
{
        if (users[holdIndex].getRatingAt(j) > 0)//if the rating at the held index of users is greater than zero
            {
                 count++;//add 1 to count
            }
        
}
        return count;
}

/**
* This function  given a user’s name and a book’s title returns the rating that the user
 gave for that book.
* 
* 1.loop through users array checking for username
* 2.loop through book array checking for title
* 3.if both the title and username are found
* return the rating of the book at the users index
*
 *Input parameters:string for the username, string for the title, User class object array, Book class object array, int for numUsers and NumBooks
 * Output:nothing
 * Returns:rating by the user of the matching book
 */ 

int getRating (string username, string title, User users[], Book books[], int numUsers, int numBooks)
{
    string temp=to_lower(username);//temps to hold the lowered username and title
    string temp2=to_lower (title);
    int foundUser=0;
    int holdIndex=0;
    if (numBooks <= 0)
    {
        return -3;
    }
    for (int i=0;i<numUsers;i++)
    {
        if (to_lower(users[i].getUsername())==temp)//looping through the users array to check if the username is there
        {
            foundUser++;//counter
            holdIndex=i;//grabbing that index
        }
    }
      int foundBook=0;
      int hold2=0;
      for (int j=0;j<numUsers;j++)
    {
        if (to_lower(books[j].getTitle())==temp2)//looping through the books array to check if the title is there
        {
            foundBook++;//counter
            hold2=j;//grabbing index
        }
    }
    if (foundUser > 0 && foundBook > 0)//if both the title and username exist
    {
        return users[holdIndex].getRatingAt(hold2);//return the rating at user index of username at get rating of the index of the title
    }
    else
    {
        return -3;//for other cases
    }
}

/**
* This function splits the input string into pieces seperated by the delimiter, and then takes the pieces and 
* inserts them into an array up to the number of split pieces
* 
* 1.while the string at index i
* if the index at i equals the delimiter ot the index at i is the end of the string
* then if the reset variable is not equal to i
*    then if counter is equal to the size of the array, return -1 because the array cannot be smaller than the number of substrings
*    if not at counter index of words insert the substring of split at reset and reset minus i
* set reset equal to i plus 1
* return count
*
 *Input parameters:string for the variable to be split, delimiter must be a char, the array must be a string type, the size of array must be int
 * Output:nothing
 * Returns:number of pieces string was split into
 */ 

int split(string split, char delimiter, string words[], int size)
{
int count=0,i=0,reset=0;//declaring three variables we will use all integers

while(i<=split.length()) //loops through the string
{
    if(split[i]==delimiter||split[i]=='\0') //if split at index i or split at i is end of the string
    {
        if(reset!=i) //if start is not equal to i then
        {
            if(count==size)//if count equal to size of array then
            {
            return -1; //returns -1
            }
        words[count++] = split.substr(reset,i-reset); //adds the substring into words array and increments the count by 1
        }
      reset = i+ 1; //assigns i+1 to reset
     }
    i++; //increments i by 1
}
    return count; //returns the count
}

/**
* This function combines the usernames and ratings of books into a Class object array
* 
* 1.open text file
* 2.if number of user sis greater than array size, return -2
* 3.if file is open
*   while grabbing each line
*   if line isnt empty
*       create temp array
*       call split function to parse the txt file
*           populate the user class array with the usernames and ratings grabbed form the txt file
*           if the number of users in the system equals the number of rows return -1
* 4.else return -1
*
 * Input parameters:string for the file name, User class object for the array, int for the number of users stored, int for the users array size,
 * int for the max number of columns 
 * Output:nothing
 * Returns:total number of users in the system
 */ 

int readRatings(string fileName, User users[], int numUsersStored, int usersArrSize, int maxCol)
{
string word = "";//create a variable for words
int count = numUsersStored;//set count to the number of users stored

ifstream myfile;//output stream
myfile.open(fileName);//Open the text file

if (numUsersStored >= usersArrSize)//When numUsersStored is greater than or equal to the usersArrSize, return -2
{
    return -2;
}

if (myfile.is_open())
{
    while (getline(myfile, word)) //Read each line from the text file
    {
            if (word != "")//make sure line isnt empty
            {
              string array[51];//temp array
              int j=split(word, ',', array, 51);        //Split each line
              users[count].setUsername(array[0]);       //populating the Users array with the usernames from the temp array grabbed from txt file                                  
              for (int i = 1; i < j; i++)
              {
              users[count].setRatingAt((i-1),stoi(array[i])); //populating the Users array with the ratings from the temp array grabbed from txt file
                                                              //stoi converting string to int
              }                         
              count++;//add 1 to count
              if (count == usersArrSize)//blocks a segmentation fault because total users in system cannot be accessed outside of while loop if it equals number of rows
              {
              return count;
              }
             }
     }
      return count;//return count
}

else // if anything else will return -1.
{
                return -1;
}

}

/**
* This function populates a pair of arrays with the titles and authors found in an txt file
* 1. open file
* 2. if file fails to open return negative one
* 3. if number of books stored equals the size of the array return negative two
* 4. if file is open
*   while looping through file and grabbing each line
*       if the line isn't empty
*           split the line by calling the split function
*           populate each cell of class object array with each author and book
*           add 1 to j
*           num of book stored equals j
*           reset the temp arrays
* 5. close file
* 6. return number of books added
*
 *Input parameters:string for titles array, string for authors array,  integer for length of arrays
 * Output:each book and its author
 * Returns:nothing
 */ 

int readBooks (string fileName, Book books[],int numBookStored, int booksArrSize=50)
{
ifstream myfile;//create an output file
myfile.open(fileName.c_str());//open the file with the file stream
string line;//line
string arr[2];//temp array
int j=numBookStored;//another integer set to numBookStored

if (numBookStored == booksArrSize)//if number of books currently stored in array equals the size of the array
{
    return -2;
}

if (myfile.fail())//if the file fails to open
{
    return -1;
}

if(myfile.is_open())//if file is open
{
    while (getline(myfile,line))//loop through file
    {
    if (numBookStored == booksArrSize)//zero case
    {
        return numBookStored;
    }
   else
   {
    if (line != "" )// if line is not empty
    {
       split (line, ',', arr , booksArrSize);//split line using comma as delimiter and calling split function
        books[j].setAuthor(arr[0]);//set author member function to populate array with authors
        books[j].setTitle(arr[1]);//set title member function to populate array with titles
        j++;//increment j
        numBookStored=j;//adding to numBookStored
        arr[0]="";//reset temp arrays
        arr[1]="";
    }
    }
}
}
myfile.close();// closing the file
 
return numBookStored;//return statement
}

double calcAverageRating(User users[], Book books[], int numUsers, int numBooks, string title)
{
    if (numUsers==0)//if no users exist
    return -3;
    int holdIndex=-1;
    string temp1=to_lower(title);//lowering the case of title
    
    for (int i=0;i<numBooks;i++)
    {
    if (to_lower(books[i].getTitle())==temp1)//lower case version of get username compared to username
    {
        holdIndex=i;//hold that index
    }
    }
    if (holdIndex==-1)//if the book title does not exist
        return -3;
    
    double sum=0;
    double count2=0;
    for (int j=0;j<numUsers;j++)//loop through
    {
        sum=users[j].getRatingAt(holdIndex)+sum;//sum equals users at j index and grab rating at heldindex
        if(users[j].getRatingAt(holdIndex) > 0)//if rating is greater than 0
        {
            count2++;//add to count
        }
    }
    if (count2==0)//book has not been read by anyone
        return 0;//return 0
        
    return sum/count2;
}

int main()
{
    Book books[50];User users[100];//setting arrays
     int userChoice=printMenu();//call what was returned from print menu function
         if (userChoice==6)//quit option in case user immediately quits
        {
            cout<<"Good bye!"<<endl;
        }
    while (userChoice != 6)//while user choice does not equal 4
{
      if (userChoice != 1 && userChoice != 2 && userChoice != 3 && userChoice != 4 && userChoice != 5 && userChoice != 6)//if the input is invalid
    {
            cout<<"Invalid input."<<endl;//output message
            userChoice=printMenu();
    }
    if (userChoice==1)//user choice equals 1
     {
        string fileName = "";//string empty
        cout<<"Enter a book file name:"<<endl;
        cin>>fileName;//input into string
        int booksArrSize=50;
        int numBookStored;
        int comparevalue=readBooks(fileName, books, numBookStored, booksArrSize);//call readbooks and store the result in numBookStored
        if (comparevalue == -1)//if function returns -1
        {
            cout<<"No books saved to the database."<<endl;
        }
        else if (comparevalue == -2)//readbooks called equals -2 or 50
        {
            cout<<"Database is already full. No books were added."<<endl;
        }
        else if (comparevalue == 50)
        {
            cout<<"Database is full. Some books may have not been added."<<endl;
        }
        else if ((comparevalue !=-1) && comparevalue !=-2 && comparevalue != 50)//if numBookStored isnt any of the above numbers
        {
            cout<<"Total books in the database: "<<comparevalue<<endl;
        }
        userChoice=printMenu();//print menu function
     }
    if  (userChoice==2)
     {
       string fileName2;
       cout<<"Enter a user file name:"<<endl;
       cin>>fileName2;
       int numUsersStored2;int usersArrSize2;int maxCol2;
       int valuecompare=readRatings(fileName2,users,numUsersStored2, usersArrSize2, maxCol2);
       if (valuecompare==-1)
       {
           cout<<"No users saved to the database"<<endl;
       }
        if (valuecompare==-2)
       {
           cout<<"Database is already full. No users were added."<<endl;
       }
       if (valuecompare==100)
       {
           cout<<"Database is full. Some users may have not been added."<<endl;
       }
       else
       {
           cout<<"Total users in the database:"<<valuecompare<<endl;
       }
       userChoice=printMenu();//print menu function
     }
        if (userChoice==3)
     {
         string username;string title;int numuserstored3;int numbooksstored3;
         cout<<"Enter a user name:"<<endl;
         getline(cin,username);
         cout<<"Enter a book title:"<<endl;
         getline(cin,title);
         to_lower(title);to_lower(username);
       int valuecompare3=getRating(username,title,users,books,numuserstored3,numbooksstored3);
        if (valuecompare3==0)
        {
            cout<<username<<"has not rated"<<title<<endl;
        }
        if (valuecompare3==-3)
        {
            cout<<username<<"or"<<title<<"does not exist"<<endl;
        }
        else
        {
            cout<<username<<"rated"<<title<<"with"<<valuecompare3<<endl;
        }
         userChoice=printMenu();//Print Menu functiom
     }
     if (userChoice==4)
     {
         string username;int numUsers;int numBooks;
         cout<<"Enter a user name:"<<endl;
         cin>>username;
         int valuecompare4=getCountReadBooks(username, users, numUsers, numBooks);
           if (valuecompare4==0)
        {
            cout<<username<<"has not rated any books."<<endl;
        }
        if (valuecompare4==-3)
        {
            cout<<username<<"does not exist"<<endl;
        }
        else
        {
            cout<<username<<"rated"<<valuecompare4<<"books."<<endl;
        }
         userChoice=printMenu();//Print Menu functiom
     }
     if (userChoice==5)
     {
         string booktitle;int numUsers;int numBooks;
         cout<<"Enter a book title:"<<endl;
         cin>>booktitle;
         int valuecompare5=calcAverageRating(users,books,numUsers, numBooks, booktitle);
          userChoice=printMenu();//Print Menu functiom
     }
     if (userChoice==6)//quit option
     {
            cout<<"Good bye!"<<endl;
     }
}
}
