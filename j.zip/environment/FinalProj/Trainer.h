#include <iostream>
#include <vector>
using namespace std;

//This is the header file for the Trainer class, check Trainer.cpp for comments on what these member functions do

class Trainer
{
    private://Data members
    int Pokeballs;
    int Trainers;
    int wildPokemonNumber;
    int suite[5]={0};
    int pokedex[150]={0};
    int numOfPokeInParty;
    
    public://Declaring all the member functions
    void setPokeballs(int pokeballs);
    int getPokeballs();
   // int getWildPokeNumber();
    void addPokeToSuite(int ID);
    void addPokeToPokedex(int ID);
    int getNumOfPokeInPartyVar();
    void Heal();
    void getNumOfPokeInParty();
    int getIDNumFromSuite(int i);
};