#include <iostream>
#include <string>
#include <fstream>
#include "Game.h"
using namespace std;

void Game::RandomChances()
{
    int y=rand() % 10;int keepsit;char activePokeChoice;
    int w=rand() % 150;
   objectP=getPokeObject(w);
    if (y==0 || y==1 || y==2)
    {
        cout<<"A wild pokemon appears!!! "<<objectP.getPokeName()<<" Do you want to:"<<endl<<"1. Catch it "<<endl<<"2. Release it"<<endl;
        cin>>keepsit;
        if (keepsit==1)
        objectT.addPokeToSuite(w);
        objectT.addPokeToPokedex(w);
        objectT.setPokeballs(objectT.getPokeballs()-1);
        cout<<"Awesome!"<<objectP.getPokeName()<<"joins the Pokédex. You still have room in your battle party. Do you want to make Charizard your Active Pokémon? Enter Y or N"<<endl;
        cin>>activePokeChoice;
        if (activePokeChoice=='Y')
        {
            setActivePoke(objectP.getIDNum());
        }
    }
    //EVENT 2
    int z=rand() % 4;int m=rand() % 2;
    if (z==0 && m==0)
    {
        objectT.setPokeballs(objectT.getPokeballs()+2);
        cout<<"Great news! You have stumbled upon a hidden stash of Pokéballs. Your reserves increased to"<<objectT.getPokeballs()<<endl;
    }
    if (z==0 && m==1)
    {
        cout<<"Great news! You have stumbled upon a hidden stash of Poffins. Your Pokémon are delighted. Choose one of them to feast on the Poffins and Level Up:"<<endl;
        //loop through suite thing
    }
    
    int a=rand() % 5;
    if (a==0)
    {
        cout<<"Oh no! After years of legendary battles,"<<endl;
        //pick a random poke from suite and remove it
    }
}


void Game::setWildPoke(int ID)
{
    wildpoke=ID;
}

void Game::ActivePoke()
{
    cout<<"Pick another Active Pokémon"<<endl;
 //   int first=objectT.
 //   objectP=getPokeObject()//need to feed id num into getPokeObject
}

void Game::EncounterMenu()
{
    int fightOption;
    cout<<"What do you want to do (pick 1, 2, or 3):"<<endl<<"1. Fight"<<endl<<"2. Switch Active Pokémon"<<endl<<"3. Run"<<endl;
    cin>>fightOption;
    if (fightOption==1)
    {
     Fight();
    }
    if (fightOption==2)
    {
        ActivePoke();
    }
    if (fightOption==3)
    {
        Run();
    }
}

void Game::Run()
{
    Poke obj6;Poke obj3;
      obj3=getPokeObject(activePoke);
    obj6=getPokeObject(wildpoke);
    cout<<"The player is trying to escape"<<endl;
    int randomnum=rand() % 256;int F;int A;int B;int C;
    A=obj6.getSpeed();B=(obj3.getSpeed()/4) % 256;C=1;
    
    cout<<A<<B<<C<<endl;
    F=((A*32)/B)+30*C;
    cout<<F<<endl;
    
    if (F>255)
    {
        cout<<"The player escapes"<<endl;
        //Nearest poke center
    }
    else
    {
        if (randomnum < F)
        {
                cout<<"The player escapes"<<endl;
                //nearest poke center
        }
        else
        {
            EncounterMenu();
        }
    }
    
    C++;
}

void Game::Fight()
{
    int wildPokeEncounters;int F;int A;int B;int C;Poke obj6;Poke obj3;
      obj3=getPokeObject(activePoke);
    obj6=getPokeObject(wildpoke);
    A=obj6.getSpeed();B=(obj3.getSpeed()/4) % 256;C=0;
      if (wildPokeEncounters<2)
        {
            cout<<obj6.getPokeName()<<" joined your party! Awesome. "<<endl;
            cout<<" HP: "<<obj6.getHP()<<" A: "<<obj6.getAttack()<<" D: "<<obj6.getDefense()<<" S: "<<obj6.getSpeed()<<" M: "<<obj6.getMax()<<endl;
            wildPokeEncounters++;
              objectP.setNumOfTypes(obj6);
                                           //add winnerCheck to every gym badge obtained and every pokemon caught
              
        }
        else
        {
            int randomnum=rand() % 5;int AA;int DD;int damage;int restoreHealth=obj6.getHP();
            if (randomnum != 1 && randomnum != 4)
            {
                cout<<"It's rumble time. Lets fight. "<<endl;
                if (obj3.getSpeed() > obj6.getSpeed())
                {
                    cout<<obj3.getPokeName()<<" attacks first."<<endl;
                AA=rand() % obj3.getSpeed();
                DD=rand() % obj6.getDefense();
                    if (AA > DD)
                    damage=AA-DD;
                    obj6.setHP(obj6.getHP()-damage);
                    cout<<obj3.getPokeName()<<" deals"<<damage<<" damage."<<endl;
                    cout<<obj6.getPokeName()<<" HP: "<<obj6.getHP()<<" A: "<<obj6.getAttack()<<" D: "<<obj6.getDefense()<<" S: "<<obj6.getSpeed()<<" M: "<<obj6.getMax()<<endl;
                     if (obj6.getHP() <= 0)
                     {
                         int j=obj6.getIDNum();
                         obj6.setHP(restoreHealth);
                         objectT.addPokeToPokedex(j);
                         objectT.addPokeToSuite(j);
                             cout<<obj6.getPokeName()<<" joined your party! Awesome. "<<endl;
                            cout<<" HP: "<<obj6.getHP()<<" A: "<<obj6.getAttack()<<" D: "<<obj6.getDefense()<<" S: "<<obj6.getSpeed()<<" M: "<<obj6.getMax()<<endl;
                            obj3.LvlPokeUp(obj3);
                             objectP.setNumOfTypes(obj6);
                     }
                     else
                     {
                         EncounterMenu();
                     }
                }
                else
                {
                cout<<obj6.getPokeName()<<" attacks first."<<endl;
                AA=rand() % obj6.getSpeed();
                DD=rand() % obj3.getDefense();
                 if (AA > DD)
                 damage=AA-DD;
                 obj3.setHP(obj3.getHP()-damage);
                 cout<<obj6.getPokeName()<<" deals"<<damage<<" damage."<<endl;
                 cout<<obj3.getPokeName()<<" HP: "<<obj3.getHP()<<" A: "<<obj3.getAttack()<<" D: "<<obj3.getDefense()<<" S: "<<obj3.getSpeed()<<" M: "<<obj3.getMax()<<endl;
                 objectT.getNumOfPokeInParty();
                   int t=objectT.getNumOfPokeInPartyVar();
                 if (obj3.getHP() <= 0 && t>1)
                 {
                    cout<<"Your poke has fainted. You must go to poke center to fix him or her up.  "<<endl;
                    obj6.LvlPokeUp(obj6);
                    EncounterMenu();
                 }
                 else if(obj3.getHP() <= 0 && t==1)
                 {
                      cout<<"You lost the battle. "<<endl;
                      obj6.LvlPokeUp(obj6);
                 }
                 else
                     {
                         EncounterMenu();
                     }
                }
            }
            else
            {
                cout<<obj6.getPokeName()<<" is trying to run."<<endl;
                F=((A*32)/B)+30*C;
                if (F > 255)
                {
                    cout<<"His attempt is successful."<<endl;
                    
                }
                else
                {
                    int c=rand() % 256;
                    if (c < F)
                    {
                     cout<<"His attempt is successful."<<endl;
                     int randomX=rand() % 26;int randomY=rand() %17;
                     obj6.setPokeX(randomX);
                     obj6.setPokeY(randomY);
                    }
                     else
                     {
                     cout<<obj6.getPokeName()<<" did not escape."<<endl;
                     }
                }
            }
        }
}

/*
void intializeTrainers()
{
    for (int i=0;i<15;i++)
    {
    Trainer object;
    int rando=rand() % 6 + 1;
    for (int j=0;,j < rando; j++)
    {
        
    }
    }
}
*/ 

void Game::setActivePoke(int ID)
{
    activePoke=ID;
}

int Game::readRatings(string fileName)
{

string word = "";//create a variable for words
int count = 0;//set count to the number of users stored

ifstream myfile;//output stream
myfile.open(fileName);//Open the text file

if (myfile.is_open())
{
    while (getline(myfile, word)) //Read each line from the text file
    {
            if (word != "")//make sure line isnt empty
            {
              string array[51];//temp array
              int j=split(word, ',', array, 51);   
              for (int i=0;i<j;i++)
              {
            if (i=0)
            {
            poke[count].setID(stoi(array[i])); 
            }
            if (i=1)
            poke[count].setName(array[i]);  
            if (i=2)
            poke[count].setHP(stoi(array[i]));//populating the Users array with the usernames from the temp array grabbed from txt file 
            if (i=3)
            poke[count].setAttack(stoi(array[i]));
            if (i=4)
            poke[count].setDefense(stoi(array[i]));
            if (i=5)
            poke[count].setSpeed(stoi(array[i]));  
            if (i=6)
            poke[count].setMax(stoi(array[i])); 
            if (i=7)
            poke[count].setMainType((array[i]));
            if (i=8)
            poke[count].setSecondType((array[i]));
              count++;//add 1 to count
              }
              if (count == 151)//blocks a segmentation fault because total users in system cannot be accessed outside of while loop if it equals number of rows
              {
              return count;
              }
             }
     }
      return count;//return count
}

else // if anything else will return -1.
{
                return -1;
}

}

Poke Game::getPokeObject(int i)
{
    return poke[i];
}