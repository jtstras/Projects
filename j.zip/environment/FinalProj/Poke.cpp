// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Project 3

#include <iostream>
#include <string>
#include <fstream>
#include "Poke.h"
using namespace std;

void Poke::setNumOfTypes(Poke object)
{
    int bugCount;int dragonCount;int iceCount;int fightCount;int fireCount;int flyingCount;int grassCount;int ghostCount;int groundCount;int electricCount;int normalCount;
    int poisonCount;int psychicCount; int rockCount;int waterCount;
    if (object.getMainType() == "Bug" && bugCount==0)
    {
        numberOfTypesAcquired++;
        bugCount++;
    }
    if (object.getMainType() == "Dragon" && dragonCount==0)
    {
        numberOfTypesAcquired++;
        dragonCount++;
    }
    if (object.getMainType() == "Ice" && iceCount==0)
    {
        numberOfTypesAcquired++;
        iceCount++;
    }
    if (object.getMainType() == "Fighting" && fightCount==0)
    {
        numberOfTypesAcquired++;
        fightCount++;
    }
     if (object.getMainType() == "Fire" && fireCount==0)
    {
        numberOfTypesAcquired++;
        fireCount++;
    }
     if (object.getMainType() == "Flying" && flyingCount==0)
    {
        numberOfTypesAcquired++;
        flyingCount++;
    }
     if (object.getMainType() == "Grass" && grassCount==0)
    {
        numberOfTypesAcquired++;
        grassCount++;
    }
     if (object.getMainType() == "Ghost" && ghostCount==0)
    {
        numberOfTypesAcquired++;
        ghostCount++;
    }
     if (object.getMainType() == "Ground" && groundCount==0)
    {
        numberOfTypesAcquired++;
        groundCount++;
    }
     if (object.getMainType() == "Electric" && electricCount==0)
    {
        numberOfTypesAcquired++;
        electricCount++;
    }
     if (object.getMainType() == "Normal" && normalCount==0)
    {
        numberOfTypesAcquired++;
        normalCount++;
    }
     if (object.getMainType() == "Poison" && poisonCount==0)
    {
        numberOfTypesAcquired++;
        poisonCount++;
    }
     if (object.getMainType() == "Psychic" && psychicCount==0)
    {
        numberOfTypesAcquired++;
        psychicCount++;
    }
     if (object.getMainType() == "Rock" && rockCount==0)
    {
        numberOfTypesAcquired++;
        rockCount++;
    }
     if (object.getMainType() == "Water" && waterCount==0)
    {
        numberOfTypesAcquired++;
        waterCount++;
    }
}

char Poke::winnerCheck()
{
    int k=getNumofTypes();
    if (k > 7)
    return 'Y';
    int m=getBadges();
    if (m > 5)
    return 'Y';
    else
    return 'N';
}

int Poke::getX()
{
    return X;
}

int Poke::getY()
{
    return Y;
}


void Poke::setPokeX(int x)
{
    X=x;
}

void Poke::setPokeY(int y)
{
    Y=y;
}


int Poke::getBadges()
{
    return badges;
}

void Poke::setID(int id)
{
    identityNum=id;
}

void Poke::setName(string n1)
{
    pokeName=n1;
}

void Poke::setHP(int h)
{
    HP=h;
}

void Poke::setAttack(int a)
{
    Attack=a;
}

void Poke::setDefense(int d)
{
    Defense=d;
}

void Poke::setSpeed(int s)
{
    Speed=s;
}

void Poke::setMax(int m)
{
    Max=m;
}

void Poke::setMainType(string m)
{
    mainType=m;
}

void Poke::setSecondType(string m2)
{
    secondaryType=m2;
}

int Poke::getHP()//returning name
{
    return HP;
}

int Poke::getAttack()//returning points
{
    return Attack;
}

int Poke::getDefense()//setting name to input
{
    return Defense;
}

int Poke::getSpeed()//setting name to input
{
    return Speed;
}

int Poke::getMax()//setting name to input
{
    return Max;
}

string Poke::getMainType()//setting name to input
{
    return mainType;
}

string Poke::getSecondaryType()//setting name to input
{
    return secondaryType;
}

int Poke::getNumofTypes()//setting name to input
{
    return numberOfTypesAcquired;
}

void Poke::LvlPokeUp(Poke obj1)
{
    obj1.setHP(obj1.getHP() * 1.02);
     obj1.setSpeed(obj1.getSpeed() * 1.02);
     
     if ((obj1.getAttack() * 1.02) <= obj1.getMax())
     {
     obj1.setAttack(obj1.getAttack() * 1.02);
     }
     
    if ((obj1.getDefense() * 1.02) <= obj1.getMax())
    {
    obj1.setDefense(obj1.getDefense() * 1.02);
    }
}

int Poke::getIDNum()
{
    return identityNum;
}

string Poke::getPokeName()
{
    return pokeName;
}