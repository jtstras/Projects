#include <iostream>
#include "Map.cpp"
#include "Trainer.cpp"
#include "Poke.cpp"
using namespace std;

//This is the header file for the Poke class, check Poke.cpp for comments on what these member functions do

class Game
{
    private://Data members
    Poke poke[151];
    Trainer trainer[15];
    int activePoke;
    int wildpoke;
    Trainer objectT;
    Poke objectP;
    
    public://Declaring all the member functions
    int readRatings(string fileName);
    Poke getPokeObject(int i);
    void setActivePoke(int ID);
    void setWildPoke(int ID);
  // void intializeTrainers;
    void Fight();
    void EncounterMenu();
    void ActivePoke();
    void RandomChances();
    void Run();

};