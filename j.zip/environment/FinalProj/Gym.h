#include <iostream>
using namespace std;

//This is the header file for the Gym class, check Gym.cpp for comments on what these member functions do
//map and trainer classes first

class Gym
{
    private://Data members
     int badges;
     int points;
    
    public://Declaring all the member functions
    int getPoints();
     int getBadges();
     void gymFight();
     void switchActive();
     void IWin();
     void UWin();
     string distributePokemonToUser();
    
};
