#include <iostream>
using namespace std;

//This is the header file for the Map class, check Map.cpp for comments on what these member functions do
//map and trainer classes first


class Map
{
    private://Data members
    int gyms;
    bool hasBadge;
    bool hasVisited;
    int startRows;
    int startColumn;
    char map[25][16];  
    int pokeChoice;
    int rows;
    int columns;
    vector <Poke> wildpokemon;
    Poke obj1;
    Trainer obj2;
    
    public://Declaring all the member functions
    void setWildPokeLocations();
    void setPokeChoice(int l);
    void setRowsStart(int r);
    void setColumnsStart(int s);
    int getStarterLocX();
    int getStarterLocY();
    char readMap(string fileName);
    void TryUrLuck();
    void displayMap();
    char moveNorth();
    char moveSouth();
    char moveWest();
    char moveEast();
    void displayMapFirst();
    int checkWildPokeProx();
    int checkWildPokeProx5x5();
    void moveWildPoke();
   // int getWildPokeLocations(vector <Poke> wildpokemon);
    void Travel();
    int getRows();
    int getColumns();
    void setColumns(int j);
    void setRows(int j);
    int checkIfPlayerAtGym();
};