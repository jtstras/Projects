// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Final Project 

#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include "Game.cpp"
using namespace std;

int main()
{
    Trainer obj1;Map obj2;Game obj4;Gym obj5;
    Poke obj3;//active poke
    Poke obj6;//wild poke
    Poke obj7;Poke obj8;Poke obj9;Poke obj10;Poke obj11;//suite pokes
    int pokeballs=10;
    obj1.setPokeballs(pokeballs);
    string name;
    cout<<"Welcome to Pokemon, The Ultimate Game. "<<endl;
    cout<<"Please state your name"<<endl;
    cin>>name;int pokeChoice;
    cout<<"Welcome, "<<name<<", before you can begin your Pokémon adventure you must choose a starting Pokémon,courtesy of the Professor.";
    cout<<"Please choose from the following Pokémon:"<<endl;
    cout<<"0. Bulbasaur"<<endl;
    cout<<"3. Charmander"<<endl;
    cout<<"6. Squirtle"<<endl;
    cout<<"24. Pikachu"<<endl;
    cin>>pokeChoice;
    obj4.setActivePoke(pokeChoice);
    obj1.addPokeToSuite(pokeChoice);
    obj1.addPokeToPokedex(pokeChoice);
    obj2.setWildPokeLocations();
    if (pokeChoice != 0 && pokeChoice != 3 and pokeChoice != 6 && pokeChoice != 24)
    {
        cout<<"Choose a pokemon bruh. Look at the numbers. "<<endl;
    }
    
    int rows=13;int columns;
    if (pokeChoice==0)
    columns=7;
    if (pokeChoice==3)
    columns=8;
    if (pokeChoice==6)
    columns=9;
    if (pokeChoice==24)
    columns=10;
    obj2.setColumns(columns);
    obj2.setRows(rows);
    obj2.readMap("mapPoke.txt");
   obj2.displayMap();
   
    int turnChoice;
    cout<<"The sun is shining "<<name<<". It’s a beautiful day, we have "<<obj1.getPokeballs()<<" Pokéball left and your Pokémon are strong."<<endl;
   
    obj4.readRatings("pokemon.txt");
    obj3=obj4.getPokeObject(pokeChoice);
     obj3.setNumOfTypes(obj3);//Tracks for the 8 diff types
     
    cout<<"Your ACTIVE poke is:"<<endl;
    cout<<"Name: "<<obj3.getPokeName()<<" HP: "<<obj3.getHP()<<" A: "<<obj3.getAttack()<<" D: "<<obj3.getDefense()<<" S: "<<obj3.getSpeed()<<" M: "<<obj3.getMax()<<endl;
    
    cout<<"Please choose from the following options: "<<endl<<"1. Travel"<<endl<<"2. Rest"<<endl<<"3. Try your luck"<<endl<<"4. Quit the game"<<endl;
    cin>>turnChoice;
    
    
    if (turnChoice==1)
    {
        obj2.Travel();
    }
     if (turnChoice==2)
    {
           pokeballs=pokeballs-1;
           obj1.setPokeballs(pokeballs);//verified working
           //increase HP of all pokes in suite...
           int g=obj3.getHP();
           obj3.setHP(g+1);
           cout<<obj3.getHP()<<endl;
    }
    if (turnChoice==3)
    {
        int l=obj2.checkWildPokeProx();
        int m=rand() % 2;
        int zz=rand() % 152;
        if (l==1 && m==1)
        {
            cout<<"You caught a pokemon thats awesome! No pokeballs were used. "<<endl;
            obj1.addPokeToPokedex(zz);
        obj1.addPokeToSuite(zz);
            obj7=obj4.getPokeObject(zz);
            obj3.setNumOfTypes(obj7);
            cout<<"Name: "<<obj7.getPokeName()<<" HP: "<<obj7.getHP()<<" A: "<<obj7.getAttack()<<" D: "<<obj7.getDefense()<<" S: "<<obj7.getSpeed()<<" M: "<<obj7.getMax()<<endl;
             char playAgain;
            if (obj3.winnerCheck()=='Y')
            {
            cout<<"You Win The Game."<<endl;
            cout<<"Would you like to play again? Enter Y or N."<<endl;
            cin>>playAgain;
            if (playAgain=='N')
            {
             fstream myfile;
            myfile.open("resultsPokemon.txt", fstream::in | fstream::out | fstream::app);
             myfile<<name<<"    "<<obj3.winnerCheck()<<"    "<<obj5.getPoints()<<endl;
             myfile.close();
             return 0;
            }
            else if (playAgain=='Y')
            {
            cout<<"I will reset your data"<<endl;
            fstream myfile;
             myfile.open("resultsPokemon.txt", fstream::in | fstream::out | fstream::app);
             myfile<<name<<"    "<<obj3.winnerCheck()<<"    "<<obj5.getPoints()<<endl;
            myfile.close();
             return 0;
        }
        }
        }
    }
    if (turnChoice==4)
    {
        cout<<"You Lose The Game. You Can Always Try Again If You Would Like."<<endl;
         fstream myfile;
         myfile.open("resultsPokemon.txt", fstream::in | fstream::out | fstream::app);
         myfile<<name<<"    "<<obj3.winnerCheck()<<"    "<<obj5.getPoints()<<endl;
         myfile.close();
         return 0;
    }
    if (turnChoice > 4)
    {
        cout<<"Pick a actual option bruh, stop tryna break the game, mate. I bench over 300 pounds, and I control this game."<<endl;
    }
    
    obj2.moveWildPoke();//End of turn moving wild poke
    
    int mmm=obj2.checkWildPokeProx5x5();
    
    if (mmm=1)
    {
    cout<<"You ran into a wild Pokémon!"<<endl;
    cout<<"Your ACTIVE pokemon is:"<<endl;
    cout<<"Name: "<<obj3.getPokeName()<<" HP: "<<obj3.getHP()<<" A: "<<obj3.getAttack()<<" D: "<<obj3.getDefense()<<" S: "<<obj3.getSpeed()<<" M: "<<obj3.getMax()<<endl;
    cout<<"The opposing pokemon is:"<<endl;
    int kk=rand() % 150;
    obj4.setWildPoke(kk);
    obj6=obj4.getPokeObject(kk);
     cout<<"Name: "<<obj6.getPokeName()<<" HP: "<<obj6.getHP()<<" A: "<<obj6.getAttack()<<" D: "<<obj6.getDefense()<<" S: "<<obj6.getSpeed()<<" M: "<<obj6.getMax()<<endl;
     obj4.EncounterMenu();
    }
    
   int j=obj2.checkIfPlayerAtGym();
    if(j==1)//Trainer encounter
    {
    cout<<"You arrived at the Gym and the trainer is there. She wants to fight"<<endl;
    cout<<"Your ACTIVE pokemon is:"<<endl;
    cout<<"Name: "<<obj3.getPokeName()<<" HP: "<<obj3.getHP()<<" A: "<<obj3.getAttack()<<" D: "<<obj3.getDefense()<<" S: "<<obj3.getSpeed()<<" M: "<<obj3.getMax()<<endl;
    
    cout<<"What do you want to do"<<endl<<"1.Fight"<<endl<<"2.Switch Active Pokemon"<<endl;
    
    }
    
    //all pokemon healed to full HP
    obj1.Heal();
    
    //Call this at the end of rounds and encounters
         char playAgain;
                               if (obj3.winnerCheck()=='Y')
                               {
                               cout<<"You Win The Game."<<endl;
                               cout<<"Would you like to play again? Enter Y or N."<<endl;
                               cin>>playAgain;
                               if (playAgain=='N')
                               {
                                 fstream myfile;
                                myfile.open("resultsPokemon.txt", fstream::in | fstream::out | fstream::app);
                                 myfile<<name<<"    "<<obj3.winnerCheck()<<"    "<<obj5.getPoints()<<endl;
                                 myfile.close();
                                return 0;
                               }
                               else if (playAgain=='Y')
                               {
                                   cout<<"I will reset your data"<<endl;
                                fstream myfile;
                                myfile.open("resultsPokemon.txt", fstream::in | fstream::out | fstream::app);
                                 myfile<<name<<"    "<<obj3.winnerCheck()<<"    "<<obj5.getPoints()<<endl;
                                 myfile.close();
                                return 0;
                               }
                               }
                               
     
     //End of each turn sequence
    obj2.displayMap();
    cout<<"The sun is shining "<<name<<". It’s a beautiful day, we have "<<obj1.getPokeballs()<<" Pokéball left and your Pokémon are strong."<<endl;
    cout<<"Your ACTIVE poke is:"<<endl;
    cout<<"Name: "<<obj3.getPokeName()<<" HP: "<<obj3.getHP()<<" A: "<<obj3.getAttack()<<" D: "<<obj3.getDefense()<<" S: "<<obj3.getSpeed()<<" M: "<<obj3.getMax()<<endl;
       obj1.getNumOfPokeInParty();
    if (obj1.getNumOfPokeInPartyVar()>=2)
    {
       cout<<"Your SUITE pokes are:"<<endl;
       obj7=obj4.getPokeObject(obj1.getIDNumFromSuite(1));
         cout<<"Name: "<<obj7.getPokeName()<<" HP: "<<obj7.getHP()<<" A: "<<obj7.getAttack()<<" D: "<<obj7.getDefense()<<" S: "<<obj7.getSpeed()<<" M: "<<obj7.getMax()<<endl;
        if (obj1.getNumOfPokeInPartyVar()>=3)
        {
            obj8=obj4.getPokeObject(obj1.getIDNumFromSuite(2));
             cout<<"Name: "<<obj8.getPokeName()<<" HP: "<<obj8.getHP()<<" A: "<<obj8.getAttack()<<" D: "<<obj8.getDefense()<<" S: "<<obj8.getSpeed()<<" M: "<<obj8.getMax()<<endl;
        }
        if (obj1.getNumOfPokeInPartyVar()>=4)
        {
            obj9=obj4.getPokeObject(obj1.getIDNumFromSuite(3));
             cout<<"Name: "<<obj9.getPokeName()<<" HP: "<<obj9.getHP()<<" A: "<<obj9.getAttack()<<" D: "<<obj9.getDefense()<<" S: "<<obj9.getSpeed()<<" M: "<<obj9.getMax()<<endl;
        }
          if (obj1.getNumOfPokeInPartyVar()>=5)
        {
            obj10=obj4.getPokeObject(obj1.getIDNumFromSuite(4));
             cout<<"Name: "<<obj10.getPokeName()<<" HP: "<<obj10.getHP()<<" A: "<<obj10.getAttack()<<" D: "<<obj10.getDefense()<<" S: "<<obj10.getSpeed()<<" M: "<<obj10.getMax()<<endl;
        }
          if (obj1.getNumOfPokeInPartyVar()==6)
        {
            obj11=obj4.getPokeObject(obj1.getIDNumFromSuite(5));
            cout<<"Name: "<<obj11.getPokeName()<<" HP: "<<obj11.getHP()<<" A: "<<obj11.getAttack()<<" D: "<<obj11.getDefense()<<" S: "<<obj11.getSpeed()<<" M: "<<obj11.getMax()<<endl;
        }
    }
    
    
    
}