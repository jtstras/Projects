// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Project 3

#include <iostream>
#include <string>
#include <fstream>
#include "Gym.h"
using namespace std;


int Gym::getPoints()
{
    return points;
}

int Gym::getBadges()
{
    return badges;
}

void Gym::gymFight()
{
    //implementaion of the fight option with gym battles
}

void Gym::switchActive()
{
    //choice of the option to switch pokemon
}

void Gym::IWin()
{
    //Execute conditions of user victory
}

void Gym::UWin()
{
    //Execute conditions of trainer victory
}

string Gym::distributePokemonToUser()
{
    //Taking the trainer's pokemon
}
