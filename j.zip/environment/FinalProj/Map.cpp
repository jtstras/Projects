// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Project 3

#include <iostream>
#include <string>
#include <fstream>
#include "Map.h"
using namespace std;


int Map::checkIfPlayerAtGym()
{
    int a=getRows();
    int b=getColumns();
    cout<<a<<endl<<b<<endl;//returning 32676 and -57397704
    if (map[a][b] == 'G')
    {
        return 1;
    }
}

void Map::setColumns(int j)
{
    columns=j;
}

void Map::setRows(int j)
{
    rows=j;
}


int Map::getRows()
{
    return rows;
}

int Map::getColumns()
{
    return columns;
}


void Map::Travel()
{
    int direction;
     cout<<"Which direction would you like to travel my friend?"<<endl<<"1.North"<<endl<<"2.South"<<endl<<"3.West"<<endl<<"4.East"<<endl;
        cin>>direction;
        if (direction==1)
        {
            int pp=moveNorth();
            if (pp='Y')
            {
            cout<<"You moved north bro, nice!"<<endl;
            }
            else
            {
            cout<<"You can't move that way"<<endl;
            Travel();
            }
        }
        if (direction==2)
        {
            int pp=moveSouth();
            if (pp='Y')
            {
            cout<<"You moved south bro, nice!"<<endl;
            }
            else
            {
            cout<<"You can't move that way"<<endl;
            Travel();
            }
        }
        if (direction==3)
        {
            int pp=moveWest();
             if (pp='Y')
             {
            cout<<"You moved west bro, nice!"<<endl;
             }
            else
            {
            cout<<"You can't move that way"<<endl;
            Travel();
            }
        }
        if (direction==4)
        {
            int pp=moveEast();
             if (pp='Y')
             {
            cout<<"You moved east bro, nice!"<<endl;
             }
            else
            {
            cout<<"You can't move that way"<<endl;
            Travel();
            }
        }
}

int Map::checkWildPokeProx()
{
    for (int i=0;i<20;i++)
    {
        if ((wildpokemon[i].getX() <= rows+3 && wildpokemon[i].getY() >= rows-3) && (wildpokemon[i].getX() <= columns+3 && wildpokemon[i].getY() >= 3))
        {
            return 1;
        }
    }
    
}

int Map::checkWildPokeProx5x5()
{
    for (int i=0;i<20;i++)
    {
        if ((wildpokemon[i].getX() <= rows+2 && wildpokemon[i].getY() >= rows-2) && (wildpokemon[i].getX() <= columns+2 && wildpokemon[i].getY() >= 2))
        {
            return 1;
        }
    }
    
}

void Map::setWildPokeLocations()
{
    for (int i=0;i<20;i++)//Between these 80 locations, statistically all 20 of them should be able to intialize. This solution isn't perfect but its me trying my best
    {//The math here would be 217 land tiles without gyms/centers so with a better than 50 percent chance of each attempt initializing you're looking at 4 attempts with >50% chance
    int x=rand() % 25;
    int y=rand() % 16;
    int z=rand() % 25;
    int zz=rand() % 16;
    int hggh=getStarterLocX(); int hg=getStarterLocY();
    if (map [x][y] != 'w' && map[x][y] != 'C' && map[x][y] != 'G' && hggh != x && hg != y)
    {
    obj1.setPokeX(x);
    obj1.setPokeY(y);
    }
    else if (map [z][zz] != 'w' && map[z][zz] != 'C' && map[z][zz] != 'G' && hggh != z && hg != y)
    {
    obj1.setPokeX(z);
    obj1.setPokeY(zz);
    }
    else if (map [x][zz] != 'w' && map[x][zz] != 'C' && map[x][zz] != 'G' && hggh != x && hg != zz)
    {
    obj1.setPokeX(x);
    obj1.setPokeY(zz);
    }
       else if (map [z][y] != 'w' && map[z][y] != 'C' && map[z][y] != 'G' && hggh != z && hg != y)
    {
    obj1.setPokeX(z);
    obj1.setPokeY(y);
    }
    
    wildpokemon.push_back(obj1);
    }
   
}

void Map::moveWildPoke()
{
    int locationSet=0;
    while (locationSet != 0)
    {
        
    for (int i=0;i<20;i++)
    {
           int z=rand() % 2;
           int zz=rand() % 2;
        if (map [obj1.getX()+z][obj1.getY()+zz] != map[obj1.getX()][obj1.getY()] && map [obj1.getX()+z][obj1.getY()+zz] == 'p')
        {
        obj1.setPokeX(obj1.getX()+z);
        obj1.setPokeY(obj1.getY()+zz);
        locationSet=1;
        }
        wildpokemon.push_back(obj1);
    }
    }
}

int Map::getStarterLocX()
{
    if (pokeChoice=0)
    {
        rows=13;
    }
      if (pokeChoice=24)
    {
        rows=13;
    }
      if (pokeChoice=3)
    {
        rows=13;
    }
      if (pokeChoice=6)
    {
        rows=13;
    }
    return rows;
}

int Map::getStarterLocY()
{
    if (pokeChoice=0)
    {
        columns=7;
    }
      if (pokeChoice=24)
    {
        columns=10;
    }
      if (pokeChoice=3)
    {
        columns=8;
    }
      if (pokeChoice=6)
    {
        columns=9;
    }
    return columns;
}

void Map::setRowsStart(int r)
{
    startRows=r;
}

void Map::setColumnsStart(int s)
{
    startColumn=s;
}


char Map::readMap(string fileName)
{
ifstream myfile;//create output file stream
myfile.open(fileName);//open the file with the file stream
int rows=25;

if (myfile.fail())//if file fails to open
{
    return -1;
}

string line;
string temp[16];//temporary array
int lineindex = 0;//keep track of index

while (getline(myfile,line))//loop though file while line index is less than columns of array
{
    if (line != "")//if line is not empty
    {
        split (line, ',', temp, 16);//splits file into seperate numbers using split function
        for(int i=0;i<16;i++) {
            map[lineindex][i] = temp[i][0];
        } 
        lineindex++;//add 1 to line index
    }
}
myfile.close();//closing the file
 
return lineindex;//return number of integers added to array
}


char Map::moveNorth()
{
    char tellPlayer;
     if (map[getRows()-1][getColumns()] != 'w' && getRows()-1 != 0)//have tried '~'
            {
                setRows(getRows()-1);
                 tellPlayer='Y';
            }
             return tellPlayer;
}

char Map::moveSouth()
{
    char tellPlayer;
     if (map[getRows()+1][getColumns()] != 'w' && getRows()+1 != 25)
            {
                setRows(getRows()+1);
                 tellPlayer='Y';
            }
             return tellPlayer;
}

char Map::moveEast()
{
    char tellPlayer;
     if (map[getRows()][getColumns()+1] != 'w' && getColumns()+1 != 16)
            {
                setColumns(getColumns()+1);
                 tellPlayer='Y';
            }
             return tellPlayer;
}

char Map::moveWest()
{
    char tellPlayer;
     if (map[getRows()][getColumns()-1] != 'w' && getColumns()-1 != 0)
            {
                setColumns(getColumns()-1);
                 tellPlayer='Y';
            }
             return tellPlayer;
}

void Map::displayMap()
{
    int x=getRows()-1;
    int y=getColumns()-1;
    for(int i=x-3; i<x+4; i++)    //This loops on the rows.
	{
		for(int j=y-3; j<y+4; j++) //This loops on the columns
		{
		    if (map[i][j]=='w')
		    {
		        map[i][j]='~';
		    }
		     if (map[i][j]=='p')
		    {
		        map[i][j]='*';
		    }
		     if (map[i][j]=='@')
		     {
		          map[i][j]='X';
		     }
		}
	}
	map[x][y]='@';
	 for(int i=x-3; i<x+4; i++)    //This loops on the rows.
	{
		for(int j=y-3; j<y+4; j++) //This loops on the columns
		{
		   cout << map[i][j]  << "  ";
		}
			cout << endl;
	}
	
}