// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
//Proj 3

#include <iostream>
#include <string>
#include <fstream>
#include "Trainer.h"
using namespace std;

int Trainer::getIDNumFromSuite(int i)
{
    return suite[i];
}

int Trainer::getNumOfPokeInPartyVar()
{
    return numOfPokeInParty;
}

void Trainer::Heal()
{
    char choice;
    cout<<"Welcome to the Pokémon Center. All Pokémon in your party have been healed. Do you want to change the members of your party (Y/N): "<<endl;
    cin>>choice;
    if (choice='Y')
    {
    for (int i=0;i<5;i++)
    {
    //    objectP=getPokeObject(suite[i]);
   //     objectP.setHP() readRatings but HP only?
    }
    }
}



void Trainer::getNumOfPokeInParty()
{
    for (int i=0;i<5;i++)
    {
        if (suite[i] != 0)
        {
            numOfPokeInParty++;
        }
    }
}


void Trainer::addPokeToSuite(int ID)
{
    for (int i=0;i<5;i++)
    if (suite[i] == 0)
    {
    suite[i]=ID;
    break;
    }
}


void Trainer::addPokeToPokedex(int ID)
{
     for (int i=0;i<151;i++)
    if (pokedex[i] == 0)
    {
    pokedex[i]=ID;
    break;
    }
}

void::Trainer::setPokeballs(int pokeballs)
{
    Pokeballs=pokeballs;
}

int Trainer::getPokeballs()
{
    return Pokeballs;
}

