#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include <vector>
#include <fstream>
#include <iterator>
using namespace std;

class User
{
    private://Data members
    string username;
    int numRatings;
    int size;
   int ratings[50];
    
    public://Declaring all the member functions
    User();
    User(string s,int arr[], int i);
    string getUsername();
    void setUsername(string u);
    int getRatingAt(int index);
    bool setRatingAt(int index, int value);
    int getNumRatings();
    void setNumRatings(int j);
    int getSize();
};

User::User()//default constructor sets variables to default
{
    username="";
    numRatings=0;
    
    size=50;//size always 50
    ratings[size];
    for(int i=0;i<size;i++)
    {
    ratings[i]=0;//populating array with 0
    }
    
}

User::User(string s,int arr[], int i)//Parameterized Constructor that intializes variables with inputs
{
    username=s;
    for (int j=0;j<i;j++)
    {
     ratings[j]=arr[j];
    }
    if (i < 50)
    {
        int k=50-i;
        for (int m=0;m<k;m++)
        {
            ratings[0+i+m]=0;
        }
    }
    numRatings=i;
}

string User::getUsername()//grabs username
{
    return username;
}

void User::setUsername(string u)//sets username with input
{
    username=u;
}

int User::getRatingAt(int index)//grabs rating at index
{
    if (index >= 50 || index < 0)
    {
        return -1;
    }
    int holdRating;
    holdRating=ratings[index];
    return holdRating;
}

bool User::setRatingAt(int index, int value)//sets rating to value at the index
{
    if (index < 50 && value < 6 && value >= 0)
    {
    ratings[index]=value;
    return true;
    }
    else
    {
        return false;
    }
}

int User::getNumRatings()//grabs numRatings
{
    return numRatings;
}

void User::setNumRatings(int j)//sets numRatings
{
    numRatings=j;
}

int User::getSize()//grabs the size
{
    return size;
}

int split(string split, char delimiter, string words[], int size)
{
int count=0,i=0,reset=0;//declaring three variables we will use all integers

while(i<=split.length()) //loops through the string
{
    if(split[i]==delimiter||split[i]=='\0') //if split at index i or split at i is end of the string
    {
        if(reset!=i) //if start is not equal to i then
        {
            if(count==size)//if count equal to size of array then
            {
            return -1; //returns -1
            }
        words[count++] = split.substr(reset,i-reset); //adds the substring into words array and increments the count by 1
        }
      reset = i+ 1; //assigns i+1 to reset
     }
    i++; //increments i by 1
}
    return count; //returns the count
};

class Poke
{
    private://Data members
    int identityNum;
    string pokeName;
    int HP;
    int Attack;
    int Defense;
    int Speed;
    int Max;
    string mainType;
    string secondaryType;
    int numberOfTypesAcquired;
     int badges;
     int X;
     int Y;
    
    public://Declaring all the member functions
    void setPokeX(int x);
    void setPokeY(int y);
    void setID(int id);
    void setName(string n1);
    void setHP(int h);
    void setAttack(int a);
    void setDefense(int d);
    void setSpeed(int s);
    void setMax(int m);
    void setMainType(string m);
    void setSecondType(string m2);
    void setNumOfTypes(string m3);
    int getIDNum();
    string getPokeName();
    int getHP();
    int getAttack();
    int getDefense();
    int getSpeed();
    int getMax();
    string getMainType();
    string getSecondaryType();
    string compareSpeed();
    int getNumofTypes();
    void displayBattleInfo();
    void LvlPokeUp(Poke obj1);
    bool getIsWildAns();
    char winnerCheck();
     int getBadges();
      int getX();
    int getY();
    void setNumOfTypes(Poke object);
};

void Poke::setNumOfTypes(Poke object)
{
    int bugCount;int dragonCount;int iceCount;int fightCount;int fireCount;int flyingCount;int grassCount;int ghostCount;int groundCount;int electricCount;int normalCount;
    int poisonCount;int psychicCount; int rockCount;int waterCount;
    if (object.getMainType() == "Bug" && bugCount==0)
    {
        numberOfTypesAcquired++;
        bugCount++;
    }
    if (object.getMainType() == "Dragon" && dragonCount==0)
    {
        numberOfTypesAcquired++;
        dragonCount++;
    }
    if (object.getMainType() == "Ice" && iceCount==0)
    {
        numberOfTypesAcquired++;
        iceCount++;
    }
    if (object.getMainType() == "Fighting" && fightCount==0)
    {
        numberOfTypesAcquired++;
        fightCount++;
    }
     if (object.getMainType() == "Fire" && fireCount==0)
    {
        numberOfTypesAcquired++;
        fireCount++;
    }
     if (object.getMainType() == "Flying" && flyingCount==0)
    {
        numberOfTypesAcquired++;
        flyingCount++;
    }
     if (object.getMainType() == "Grass" && grassCount==0)
    {
        numberOfTypesAcquired++;
        grassCount++;
    }
     if (object.getMainType() == "Ghost" && ghostCount==0)
    {
        numberOfTypesAcquired++;
        ghostCount++;
    }
     if (object.getMainType() == "Ground" && groundCount==0)
    {
        numberOfTypesAcquired++;
        groundCount++;
    }
     if (object.getMainType() == "Electric" && electricCount==0)
    {
        numberOfTypesAcquired++;
        electricCount++;
    }
     if (object.getMainType() == "Normal" && normalCount==0)
    {
        numberOfTypesAcquired++;
        normalCount++;
    }
     if (object.getMainType() == "Poison" && poisonCount==0)
    {
        numberOfTypesAcquired++;
        poisonCount++;
    }
     if (object.getMainType() == "Psychic" && psychicCount==0)
    {
        numberOfTypesAcquired++;
        psychicCount++;
    }
     if (object.getMainType() == "Rock" && rockCount==0)
    {
        numberOfTypesAcquired++;
        rockCount++;
    }
     if (object.getMainType() == "Water" && waterCount==0)
    {
        numberOfTypesAcquired++;
        waterCount++;
    }
}

char Poke::winnerCheck()
{
    int k=getNumofTypes();
    if (k > 7)
    return 'Y';
    int m=getBadges();
    if (m > 5)
    return 'Y';
    else
    return 'N';
}

int Poke::getX()
{
    return X;
}

int Poke::getY()
{
    return Y;
}


void Poke::setPokeX(int x)
{
    X=x;
}

void Poke::setPokeY(int y)
{
    Y=y;
}


int Poke::getBadges()
{
    return badges;
}

void Poke::setID(int id)
{
    identityNum=id;
}

void Poke::setName(string n1)
{
    pokeName=n1;
}

void Poke::setHP(int h)
{
    HP=h;
}

void Poke::setAttack(int a)
{
    Attack=a;
}

void Poke::setDefense(int d)
{
    Defense=d;
}

void Poke::setSpeed(int s)
{
    Speed=s;
}

void Poke::setMax(int m)
{
    Max=m;
}

void Poke::setMainType(string m)
{
    mainType=m;
}

void Poke::setSecondType(string m2)
{
    secondaryType=m2;
}

int Poke::getHP()//returning name
{
    return HP;
}

int Poke::getAttack()//returning points
{
    return Attack;
}

int Poke::getDefense()//setting name to input
{
    return Defense;
}

int Poke::getSpeed()//setting name to input
{
    return Speed;
}

int Poke::getMax()//setting name to input
{
    return Max;
}

string Poke::getMainType()//setting name to input
{
    return mainType;
}

string Poke::getSecondaryType()//setting name to input
{
    return secondaryType;
}

int Poke::getNumofTypes()//setting name to input
{
    return numberOfTypesAcquired;
}

void Poke::LvlPokeUp(Poke obj1)
{
    obj1.setHP(obj1.getHP() * 1.02);
     obj1.setSpeed(obj1.getSpeed() * 1.02);
     
     if ((obj1.getAttack() * 1.02) <= obj1.getMax())
     {
     obj1.setAttack(obj1.getAttack() * 1.02);
     }
     
    if ((obj1.getDefense() * 1.02) <= obj1.getMax())
    {
    obj1.setDefense(obj1.getDefense() * 1.02);
    }
}

int Poke::getIDNum()
{
    return identityNum;
}

string Poke::getPokeName()
{
    return pokeName;
}

class Trainer
{
    private://Data members
    int Pokeballs;
    int Trainers;
    int wildPokemonNumber;
    int suite[5]={0};
    int pokedex[150]={0};
    int numOfPokeInParty;
    
    public://Declaring all the member functions
    void setPokeballs(int pokeballs);
    int getPokeballs();
   // int getWildPokeNumber();
    void addPokeToSuite(int ID);
    void addPokeToPokedex(int ID);
    int getNumOfPokeInPartyVar();
    void Heal();
    void getNumOfPokeInParty();
    int getIDNumFromSuite(int i);
};

int Trainer::getIDNumFromSuite(int i)
{
    return suite[i];
}

int Trainer::getNumOfPokeInPartyVar()
{
    return numOfPokeInParty;
}

void Trainer::Heal()
{
    char choice;
    cout<<"Welcome to the Pokémon Center. All Pokémon in your party have been healed. Do you want to change the members of your party (Y/N): "<<endl;
    cin>>choice;
    if (choice='Y')
    {
    for (int i=0;i<5;i++)
    {
    //    objectP=getPokeObject(suite[i]);
   //     objectP.setHP() readRatings but HP only?
    }
    }
}



void Trainer::getNumOfPokeInParty()
{
    for (int i=0;i<5;i++)
    {
        if (suite[i] != 0)
        {
            numOfPokeInParty++;
        }
    }
}


void Trainer::addPokeToSuite(int ID)
{
    for (int i=0;i<5;i++)
    if (suite[i] == 0)
    {
    suite[i]=ID;
    break;
    }
}


void Trainer::addPokeToPokedex(int ID)
{
     for (int i=0;i<151;i++)
    if (pokedex[i] == 0)
    {
    pokedex[i]=ID;
    break;
    }
}

void::Trainer::setPokeballs(int pokeballs)
{
    Pokeballs=pokeballs;
}

int Trainer::getPokeballs()
{
    return Pokeballs;
}

class Map
{
    private://Data members
    int gyms;
    bool hasBadge;
    bool hasVisited;
    int startRows;
    int startColumn;
    char map[25][16];  
    int pokeChoice;
    int rows;
    int columns;
    vector <Poke> wildpokemon;
    Poke obj1;
    Trainer obj2;
    
    public://Declaring all the member functions
    void setWildPokeLocations();
    void setPokeChoice(int l);
    void setRowsStart(int r);
    void setColumnsStart(int s);
    int getStarterLocX();
    int getStarterLocY();
    char readMap(string fileName);
    void TryUrLuck();
    void displayMap();
    char moveNorth();
    char moveSouth();
    char moveWest();
    char moveEast();
    void displayMapFirst();
    int checkWildPokeProx();
    int checkWildPokeProx5x5();
    void moveWildPoke();
   // int getWildPokeLocations(vector <Poke> wildpokemon);
    void Travel();
    int getRows();
    int getColumns();
    void setColumns(int j);
    void setRows(int j);
    int checkIfPlayerAtGym();
};

int Map::checkIfPlayerAtGym()
{
    int a=getRows();
    int b=getColumns();
    cout<<a<<endl<<b<<endl;//returning 32676 and -57397704
    if (map[a][b] == 'G')
    {
        return 1;
    }
}

void Map::setColumns(int j)
{
    columns=j;
}

void Map::setRows(int j)
{
    rows=j;
}


int Map::getRows()
{
    return rows;
}

int Map::getColumns()
{
    return columns;
}


void Map::Travel()
{
    int direction;
     cout<<"Which direction would you like to travel my friend?"<<endl<<"1.North"<<endl<<"2.South"<<endl<<"3.West"<<endl<<"4.East"<<endl;
        cin>>direction;
        if (direction==1)
        {
            int pp=moveNorth();
            if (pp='Y')
            {
            cout<<"You moved north bro, nice!"<<endl;
            }
            else
            {
            cout<<"You can't move that way"<<endl;
            Travel();
            }
        }
        if (direction==2)
        {
            int pp=moveSouth();
            if (pp='Y')
            {
            cout<<"You moved south bro, nice!"<<endl;
            }
            else
            {
            cout<<"You can't move that way"<<endl;
            Travel();
            }
        }
        if (direction==3)
        {
            int pp=moveWest();
             if (pp='Y')
             {
            cout<<"You moved west bro, nice!"<<endl;
             }
            else
            {
            cout<<"You can't move that way"<<endl;
            Travel();
            }
        }
        if (direction==4)
        {
            int pp=moveEast();
             if (pp='Y')
             {
            cout<<"You moved east bro, nice!"<<endl;
             }
            else
            {
            cout<<"You can't move that way"<<endl;
            Travel();
            }
        }
}

int Map::checkWildPokeProx()
{
    for (int i=0;i<20;i++)
    {
        if ((wildpokemon[i].getX() <= rows+3 && wildpokemon[i].getY() >= rows-3) && (wildpokemon[i].getX() <= columns+3 && wildpokemon[i].getY() >= 3))
        {
            return 1;
        }
    }
    
}

int Map::checkWildPokeProx5x5()
{
    for (int i=0;i<20;i++)
    {
        if ((wildpokemon[i].getX() <= rows+2 && wildpokemon[i].getY() >= rows-2) && (wildpokemon[i].getX() <= columns+2 && wildpokemon[i].getY() >= 2))
        {
            return 1;
        }
    }
    
}

void Map::setWildPokeLocations()
{
    for (int i=0;i<20;i++)//Between these 80 locations, statistically all 20 of them should be able to intialize. This solution isn't perfect but its me trying my best
    {//The math here would be 217 land tiles without gyms/centers so with a better than 50 percent chance of each attempt initializing you're looking at 4 attempts with >50% chance
    int x=rand() % 25;
    int y=rand() % 16;
    int z=rand() % 25;
    int zz=rand() % 16;
    int hggh=getStarterLocX(); int hg=getStarterLocY();
    if (map [x][y] != 'w' && map[x][y] != 'C' && map[x][y] != 'G' && hggh != x && hg != y)
    {
    obj1.setPokeX(x);
    obj1.setPokeY(y);
    }
    else if (map [z][zz] != 'w' && map[z][zz] != 'C' && map[z][zz] != 'G' && hggh != z && hg != y)
    {
    obj1.setPokeX(z);
    obj1.setPokeY(zz);
    }
    else if (map [x][zz] != 'w' && map[x][zz] != 'C' && map[x][zz] != 'G' && hggh != x && hg != zz)
    {
    obj1.setPokeX(x);
    obj1.setPokeY(zz);
    }
       else if (map [z][y] != 'w' && map[z][y] != 'C' && map[z][y] != 'G' && hggh != z && hg != y)
    {
    obj1.setPokeX(z);
    obj1.setPokeY(y);
    }
    
    wildpokemon.push_back(obj1);
    }
   
}

void Map::moveWildPoke()
{
    int locationSet=0;
    while (locationSet != 0)
    {
        
    for (int i=0;i<20;i++)
    {
           int z=rand() % 2;
           int zz=rand() % 2;
        if (map [obj1.getX()+z][obj1.getY()+zz] != map[obj1.getX()][obj1.getY()] && map [obj1.getX()+z][obj1.getY()+zz] == 'p')
        {
        obj1.setPokeX(obj1.getX()+z);
        obj1.setPokeY(obj1.getY()+zz);
        locationSet=1;
        }
        wildpokemon.push_back(obj1);
    }
    }
}

int Map::getStarterLocX()
{
    if (pokeChoice=0)
    {
        rows=13;
    }
      if (pokeChoice=24)
    {
        rows=13;
    }
      if (pokeChoice=3)
    {
        rows=13;
    }
      if (pokeChoice=6)
    {
        rows=13;
    }
    return rows;
}

int Map::getStarterLocY()
{
    if (pokeChoice=0)
    {
        columns=7;
    }
      if (pokeChoice=24)
    {
        columns=10;
    }
      if (pokeChoice=3)
    {
        columns=8;
    }
      if (pokeChoice=6)
    {
        columns=9;
    }
    return columns;
}

void Map::setRowsStart(int r)
{
    startRows=r;
}

void Map::setColumnsStart(int s)
{
    startColumn=s;
}


char Map::readMap(string fileName)
{
ifstream myfile;//create output file stream
myfile.open(fileName);//open the file with the file stream
int rows=25;

if (myfile.fail())//if file fails to open
{
    return -1;
}

string line;
string temp[16];//temporary array
int lineindex = 0;//keep track of index

while (getline(myfile,line))//loop though file while line index is less than columns of array
{
    if (line != "")//if line is not empty
    {
        split (line, ',', temp, 16);//splits file into seperate numbers using split function
        for(int i=0;i<16;i++) {
            map[lineindex][i] = temp[i][0];
        } 
        lineindex++;//add 1 to line index
    }
}
myfile.close();//closing the file
 
return lineindex;//return number of integers added to array
}


char Map::moveNorth()
{
    char tellPlayer;
     if (map[getRows()-1][getColumns()] != 'w' && getRows()-1 != 0)//have tried '~'
            {
                setRows(getRows()-1);
                 tellPlayer='Y';
            }
             return tellPlayer;
}

char Map::moveSouth()
{
    char tellPlayer;
     if (map[getRows()+1][getColumns()] != 'w' && getRows()+1 != 25)
            {
                setRows(getRows()+1);
                 tellPlayer='Y';
            }
             return tellPlayer;
}

char Map::moveEast()
{
    char tellPlayer;
     if (map[getRows()][getColumns()+1] != 'w' && getColumns()+1 != 16)
            {
                setColumns(getColumns()+1);
                 tellPlayer='Y';
            }
             return tellPlayer;
}

char Map::moveWest()
{
    char tellPlayer;
     if (map[getRows()][getColumns()-1] != 'w' && getColumns()-1 != 0)
            {
                setColumns(getColumns()-1);
                 tellPlayer='Y';
            }
             return tellPlayer;
}

void Map::displayMap()
{
    int x=getRows()-1;
    int y=getColumns()-1;
    for(int i=x-3; i<x+4; i++)    //This loops on the rows.
	{
		for(int j=y-3; j<y+4; j++) //This loops on the columns
		{
		    if (map[i][j]=='w')
		    {
		        map[i][j]='~';
		    }
		     if (map[i][j]=='p')
		    {
		        map[i][j]='*';
		    }
		     if (map[i][j]=='@')
		     {
		          map[i][j]='X';
		     }
		}
	}
	map[x][y]='@';
	 for(int i=x-3; i<x+4; i++)    //This loops on the rows.
	{
		for(int j=y-3; j<y+4; j++) //This loops on the columns
		{
		   cout << map[i][j]  << "  ";
		}
			cout << endl;
	}
	
}

class Gym
{
    private://Data members
     int badges;
     int points;
    
    public://Declaring all the member functions
    int getPoints();
     int getBadges();
     void gymFight();
     void switchActive();
     void IWin();
     void UWin();
     string distributePokemonToUser();
    
};

int Gym::getPoints()
{
    return points;
}

int Gym::getBadges()
{
    return badges;
}

void Gym::gymFight()
{
    //implementaion of the fight option with gym battles
}

void Gym::switchActive()
{
    //choice of the option to switch pokemon
}

void Gym::IWin()
{
    //Execute conditions of user victory
}

void Gym::UWin()
{
    //Execute conditions of trainer victory
}

string Gym::distributePokemonToUser()
{
    //Taking the trainer's pokemon
}

class Game
{
    private://Data members
    Poke poke[151];
    Trainer trainer[15];
    int activePoke;
    int wildpoke;
    Trainer objectT;
    Poke objectP;
    
    public://Declaring all the member functions
    int readRatings(string fileName);
    Poke getPokeObject(int i);
    void setActivePoke(int ID);
    void setWildPoke(int ID);
  // void intializeTrainers;
    void Fight();
    void EncounterMenu();
    void ActivePoke();
    void RandomChances();
    void Run();

};

void Game::RandomChances()
{
    int y=rand() % 10;int keepsit;char activePokeChoice;
    int w=rand() % 150;
   objectP=getPokeObject(w);
    if (y==0 || y==1 || y==2)
    {
        cout<<"A wild pokemon appears!!! "<<objectP.getPokeName()<<" Do you want to:"<<endl<<"1. Catch it "<<endl<<"2. Release it"<<endl;
        cin>>keepsit;
        if (keepsit==1)
        objectT.addPokeToSuite(w);
        objectT.addPokeToPokedex(w);
        objectT.setPokeballs(objectT.getPokeballs()-1);
        cout<<"Awesome!"<<objectP.getPokeName()<<"joins the Pokédex. You still have room in your battle party. Do you want to make Charizard your Active Pokémon? Enter Y or N"<<endl;
        cin>>activePokeChoice;
        if (activePokeChoice=='Y')
        {
            setActivePoke(objectP.getIDNum());
        }
    }
    //EVENT 2
    int z=rand() % 4;int m=rand() % 2;
    if (z==0 && m==0)
    {
        objectT.setPokeballs(objectT.getPokeballs()+2);
        cout<<"Great news! You have stumbled upon a hidden stash of Pokéballs. Your reserves increased to"<<objectT.getPokeballs()<<endl;
    }
    if (z==0 && m==1)
    {
        cout<<"Great news! You have stumbled upon a hidden stash of Poffins. Your Pokémon are delighted. Choose one of them to feast on the Poffins and Level Up:"<<endl;
        //loop through suite thing
    }
    
    int a=rand() % 5;
    if (a==0)
    {
        cout<<"Oh no! After years of legendary battles,"<<endl;
        //pick a random poke from suite and remove it
    }
}


void Game::setWildPoke(int ID)
{
    wildpoke=ID;
}

void Game::ActivePoke()
{
    cout<<"Pick another Active Pokémon"<<endl;
 //   int first=objectT.
 //   objectP=getPokeObject()//need to feed id num into getPokeObject
}

void Game::EncounterMenu()
{
    int fightOption;
    cout<<"What do you want to do (pick 1, 2, or 3):"<<endl<<"1. Fight"<<endl<<"2. Switch Active Pokémon"<<endl<<"3. Run"<<endl;
    cin>>fightOption;
    if (fightOption==1)
    {
     Fight();
    }
    if (fightOption==2)
    {
        ActivePoke();
    }
    if (fightOption==3)
    {
        Run();
    }
}

void Game::Run()
{
    Poke obj6;Poke obj3;
      obj3=getPokeObject(activePoke);
    obj6=getPokeObject(wildpoke);
    cout<<"The player is trying to escape"<<endl;
    int randomnum=rand() % 256;int F;int A;int B;int C;
    A=obj6.getSpeed();B=(obj3.getSpeed()/4) % 256;C=1;
    
    cout<<A<<B<<C<<endl;
    F=((A*32)/B)+30*C;
    cout<<F<<endl;
    
    if (F>255)
    {
        cout<<"The player escapes"<<endl;
        //Nearest poke center
    }
    else
    {
        if (randomnum < F)
        {
                cout<<"The player escapes"<<endl;
                //nearest poke center
        }
        else
        {
            EncounterMenu();
        }
    }
    
    C++;
}

void Game::Fight()
{
    int wildPokeEncounters;int F;int A;int B;int C;Poke obj6;Poke obj3;
      obj3=getPokeObject(activePoke);
    obj6=getPokeObject(wildpoke);
    A=obj6.getSpeed();B=(obj3.getSpeed()/4) % 256;C=0;
      if (wildPokeEncounters<2)
        {
            cout<<obj6.getPokeName()<<" joined your party! Awesome. "<<endl;
            cout<<" HP: "<<obj6.getHP()<<" A: "<<obj6.getAttack()<<" D: "<<obj6.getDefense()<<" S: "<<obj6.getSpeed()<<" M: "<<obj6.getMax()<<endl;
            wildPokeEncounters++;
              objectP.setNumOfTypes(obj6);
                                           //add winnerCheck to every gym badge obtained and every pokemon caught
              
        }
        else
        {
            int randomnum=rand() % 5;int AA;int DD;int damage;int restoreHealth=obj6.getHP();
            if (randomnum != 1 && randomnum != 4)
            {
                cout<<"It's rumble time. Lets fight. "<<endl;
                if (obj3.getSpeed() > obj6.getSpeed())
                {
                    cout<<obj3.getPokeName()<<" attacks first."<<endl;
                AA=rand() % obj3.getSpeed();
                DD=rand() % obj6.getDefense();
                    if (AA > DD)
                    damage=AA-DD;
                    obj6.setHP(obj6.getHP()-damage);
                    cout<<obj3.getPokeName()<<" deals"<<damage<<" damage."<<endl;
                    cout<<obj6.getPokeName()<<" HP: "<<obj6.getHP()<<" A: "<<obj6.getAttack()<<" D: "<<obj6.getDefense()<<" S: "<<obj6.getSpeed()<<" M: "<<obj6.getMax()<<endl;
                     if (obj6.getHP() <= 0)
                     {
                         int j=obj6.getIDNum();
                         obj6.setHP(restoreHealth);
                         objectT.addPokeToPokedex(j);
                         objectT.addPokeToSuite(j);
                             cout<<obj6.getPokeName()<<" joined your party! Awesome. "<<endl;
                            cout<<" HP: "<<obj6.getHP()<<" A: "<<obj6.getAttack()<<" D: "<<obj6.getDefense()<<" S: "<<obj6.getSpeed()<<" M: "<<obj6.getMax()<<endl;
                            obj3.LvlPokeUp(obj3);
                             objectP.setNumOfTypes(obj6);
                     }
                     else
                     {
                         EncounterMenu();
                     }
                }
                else
                {
                cout<<obj6.getPokeName()<<" attacks first."<<endl;
                AA=rand() % obj6.getSpeed();
                DD=rand() % obj3.getDefense();
                 if (AA > DD)
                 damage=AA-DD;
                 obj3.setHP(obj3.getHP()-damage);
                 cout<<obj6.getPokeName()<<" deals"<<damage<<" damage."<<endl;
                 cout<<obj3.getPokeName()<<" HP: "<<obj3.getHP()<<" A: "<<obj3.getAttack()<<" D: "<<obj3.getDefense()<<" S: "<<obj3.getSpeed()<<" M: "<<obj3.getMax()<<endl;
                 objectT.getNumOfPokeInParty();
                   int t=objectT.getNumOfPokeInPartyVar();
                 if (obj3.getHP() <= 0 && t>1)
                 {
                    cout<<"Your poke has fainted. You must go to poke center to fix him or her up.  "<<endl;
                    obj6.LvlPokeUp(obj6);
                    EncounterMenu();
                 }
                 else if(obj3.getHP() <= 0 && t==1)
                 {
                      cout<<"You lost the battle. "<<endl;
                      obj6.LvlPokeUp(obj6);
                 }
                 else
                     {
                         EncounterMenu();
                     }
                }
            }
            else
            {
                cout<<obj6.getPokeName()<<" is trying to run."<<endl;
                F=((A*32)/B)+30*C;
                if (F > 255)
                {
                    cout<<"His attempt is successful."<<endl;
                    
                }
                else
                {
                    int c=rand() % 256;
                    if (c < F)
                    {
                     cout<<"His attempt is successful."<<endl;
                     int randomX=rand() % 26;int randomY=rand() %17;
                     obj6.setPokeX(randomX);
                     obj6.setPokeY(randomY);
                    }
                     else
                     {
                     cout<<obj6.getPokeName()<<" did not escape."<<endl;
                     }
                }
            }
        }
}

/*
void intializeTrainers()
{
    for (int i=0;i<15;i++)
    {
    Trainer object;
    int rando=rand() % 6 + 1;
    for (int j=0;,j < rando; j++)
    {
        
    }
    }
}
*/ 

void Game::setActivePoke(int ID)
{
    activePoke=ID;
}

int Game::readRatings(string fileName)
{

string word = "";//create a variable for words
int count = 0;//set count to the number of users stored

ifstream myfile;//output stream
myfile.open(fileName);//Open the text file

if (myfile.is_open())
{
    while (getline(myfile, word)) //Read each line from the text file
    {
            if (word != "")//make sure line isnt empty
            {
              string array[51];//temp array
              int j=split(word, ',', array, 51);   
              for (int i=0;i<j;i++)
              {
            if (i=0)
            {
            poke[count].setID(stoi(array[i])); 
            }
            if (i=1)
            poke[count].setName(array[i]);  
            if (i=2)
            poke[count].setHP(stoi(array[i]));//populating the Users array with the usernames from the temp array grabbed from txt file 
            if (i=3)
            poke[count].setAttack(stoi(array[i]));
            if (i=4)
            poke[count].setDefense(stoi(array[i]));
            if (i=5)
            poke[count].setSpeed(stoi(array[i]));  
            if (i=6)
            poke[count].setMax(stoi(array[i])); 
            if (i=7)
            poke[count].setMainType((array[i]));
            if (i=8)
            poke[count].setSecondType((array[i]));
              count++;//add 1 to count
              }
              if (count == 151)//blocks a segmentation fault because total users in system cannot be accessed outside of while loop if it equals number of rows
              {
              return count;
              }
             }
     }
      return count;//return count
}

else // if anything else will return -1.
{
                return -1;
}

}

Poke Game::getPokeObject(int i)
{
    return poke[i];
}

int main()
{
    Trainer obj1;Map obj2;Game obj4;Gym obj5;
    Poke obj3;//active poke
    Poke obj6;//wild poke
    Poke obj7;Poke obj8;Poke obj9;Poke obj10;Poke obj11;//suite pokes
    int pokeballs=10;
    obj1.setPokeballs(pokeballs);
    string name;
    cout<<"Welcome to Pokemon, The Ultimate Game. "<<endl;
    cout<<"Please state your name"<<endl;
    cin>>name;int pokeChoice;
    cout<<"Welcome, "<<name<<", before you can begin your Pokémon adventure you must choose a starting Pokémon,courtesy of the Professor.";
    cout<<"Please choose from the following Pokémon:"<<endl;
    cout<<"0. Bulbasaur"<<endl;
    cout<<"3. Charmander"<<endl;
    cout<<"6. Squirtle"<<endl;
    cout<<"24. Pikachu"<<endl;
    cin>>pokeChoice;
    obj4.setActivePoke(pokeChoice);
    obj1.addPokeToSuite(pokeChoice);
    obj1.addPokeToPokedex(pokeChoice);
    obj2.setWildPokeLocations();
    if (pokeChoice != 0 && pokeChoice != 3 and pokeChoice != 6 && pokeChoice != 24)
    {
        cout<<"Choose a pokemon bruh. Look at the numbers. "<<endl;
    }
    
    int rows=13;int columns;
    if (pokeChoice==0)
    columns=7;
    if (pokeChoice==3)
    columns=8;
    if (pokeChoice==6)
    columns=9;
    if (pokeChoice==24)
    columns=10;
    obj2.setColumns(columns);
    obj2.setRows(rows);
    obj2.readMap("mapPoke.txt");
   obj2.displayMap();
   
    int turnChoice;
    cout<<"The sun is shining "<<name<<". It’s a beautiful day, we have "<<obj1.getPokeballs()<<" Pokéball left and your Pokémon are strong."<<endl;
   
    obj4.readRatings("pokemon.txt");
    obj3=obj4.getPokeObject(pokeChoice);
     obj3.setNumOfTypes(obj3);//Tracks for the 8 diff types
     
    cout<<"Your ACTIVE poke is:"<<endl;
    cout<<"Name: "<<obj3.getPokeName()<<" HP: "<<obj3.getHP()<<" A: "<<obj3.getAttack()<<" D: "<<obj3.getDefense()<<" S: "<<obj3.getSpeed()<<" M: "<<obj3.getMax()<<endl;
    
    cout<<"Please choose from the following options: "<<endl<<"1. Travel"<<endl<<"2. Rest"<<endl<<"3. Try your luck"<<endl<<"4. Quit the game"<<endl;
    cin>>turnChoice;
    
    
    if (turnChoice==1)
    {
        obj2.Travel();
    }
     if (turnChoice==2)
    {
           pokeballs=pokeballs-1;
           obj1.setPokeballs(pokeballs);//verified working
           //increase HP of all pokes in suite...
           int g=obj3.getHP();
           obj3.setHP(g+1);
    }
    if (turnChoice==3)
    {
        int l=obj2.checkWildPokeProx();
        int m=rand() % 2;
        int zz=rand() % 152;
        if (l==1 && m==1)
        {
            cout<<"You caught a pokemon thats awesome! No pokeballs were used. "<<endl;
            obj1.addPokeToPokedex(zz);
        obj1.addPokeToSuite(zz);
            obj7=obj4.getPokeObject(zz);
            obj3.setNumOfTypes(obj7);
            cout<<"Name: "<<obj7.getPokeName()<<" HP: "<<obj7.getHP()<<" A: "<<obj7.getAttack()<<" D: "<<obj7.getDefense()<<" S: "<<obj7.getSpeed()<<" M: "<<obj7.getMax()<<endl;
             char playAgain;
            if (obj3.winnerCheck()=='Y')
            {
            cout<<"You Win The Game."<<endl;
            cout<<"Would you like to play again? Enter Y or N."<<endl;
            cin>>playAgain;
            if (playAgain=='N')
            {
             fstream myfile;
            myfile.open("resultsPokemon.txt", fstream::in | fstream::out | fstream::app);
             myfile<<name<<"    "<<obj3.winnerCheck()<<"    "<<obj5.getPoints()<<endl;
             myfile.close();
             return 0;
            }
            else if (playAgain=='Y')
            {
            cout<<"I will reset your data"<<endl;
            fstream myfile;
             myfile.open("resultsPokemon.txt", fstream::in | fstream::out | fstream::app);
             myfile<<name<<"    "<<obj3.winnerCheck()<<"    "<<obj5.getPoints()<<endl;
            myfile.close();
             return 0;
        }
        }
        }
    }
    if (turnChoice==4)
    {
        cout<<"You Lose The Game. You Can Always Try Again If You Would Like."<<endl;
         fstream myfile;
         myfile.open("resultsPokemon.txt", fstream::in | fstream::out | fstream::app);
         myfile<<name<<"    "<<obj3.winnerCheck()<<"    "<<obj5.getPoints()<<endl;
         myfile.close();
         return 0;
    }
    if (turnChoice > 4)
    {
        cout<<"Pick a actual option bruh, stop tryna break the game, mate. I bench over 300 pounds, and I control this game."<<endl;
    }
    
    obj2.moveWildPoke();//End of turn moving wild poke
    
    int mmm=obj2.checkWildPokeProx5x5();
    
    if (mmm=1)
    {
    cout<<"You ran into a wild Pokémon!"<<endl;
    cout<<"Your ACTIVE pokemon is:"<<endl;
    cout<<"Name: "<<obj3.getPokeName()<<" HP: "<<obj3.getHP()<<" A: "<<obj3.getAttack()<<" D: "<<obj3.getDefense()<<" S: "<<obj3.getSpeed()<<" M: "<<obj3.getMax()<<endl;
    cout<<"The opposing pokemon is:"<<endl;
    int kk=rand() % 150;
    obj4.setWildPoke(kk);
    obj6=obj4.getPokeObject(kk);
     cout<<"Name: "<<obj6.getPokeName()<<" HP: "<<obj6.getHP()<<" A: "<<obj6.getAttack()<<" D: "<<obj6.getDefense()<<" S: "<<obj6.getSpeed()<<" M: "<<obj6.getMax()<<endl;
     obj4.EncounterMenu();
    }
    
   int j=obj2.checkIfPlayerAtGym();
    if(j==1)//Trainer encounter
    {
    cout<<"You arrived at the Gym and the trainer is there. She wants to fight"<<endl;
    cout<<"Your ACTIVE pokemon is:"<<endl;
    cout<<"Name: "<<obj3.getPokeName()<<" HP: "<<obj3.getHP()<<" A: "<<obj3.getAttack()<<" D: "<<obj3.getDefense()<<" S: "<<obj3.getSpeed()<<" M: "<<obj3.getMax()<<endl;
    
    cout<<"What do you want to do"<<endl<<"1.Fight"<<endl<<"2.Switch Active Pokemon"<<endl;
    
    }
    
    //all pokemon healed to full HP
   // obj1.Heal();
    
    //Call this at the end of rounds and encounters
         char playAgain;
                               if (obj3.winnerCheck()=='Y')
                               {
                               cout<<"You Win The Game."<<endl;
                               cout<<"Would you like to play again? Enter Y or N."<<endl;
                               cin>>playAgain;
                               if (playAgain=='N')
                               {
                                 fstream myfile;
                                myfile.open("resultsPokemon.txt", fstream::in | fstream::out | fstream::app);
                                 myfile<<name<<"    "<<obj3.winnerCheck()<<"    "<<obj5.getPoints()<<endl;
                                 myfile.close();
                                return 0;
                               }
                               else if (playAgain=='Y')
                               {
                                   cout<<"I will reset your data"<<endl;
                                fstream myfile;
                                myfile.open("resultsPokemon.txt", fstream::in | fstream::out | fstream::app);
                                 myfile<<name<<"    "<<obj3.winnerCheck()<<"    "<<obj5.getPoints()<<endl;
                                 myfile.close();
                                return 0;
                               }
                               }
                               
     
     //End of each turn sequence
    obj2.displayMap();
    cout<<"The sun is shining "<<name<<". It’s a beautiful day, we have "<<obj1.getPokeballs()<<" Pokéball left and your Pokémon are strong."<<endl;
    cout<<"Your ACTIVE poke is:"<<endl;
    cout<<"Name: "<<obj3.getPokeName()<<" HP: "<<obj3.getHP()<<" A: "<<obj3.getAttack()<<" D: "<<obj3.getDefense()<<" S: "<<obj3.getSpeed()<<" M: "<<obj3.getMax()<<endl;
       obj1.getNumOfPokeInParty();
    if (obj1.getNumOfPokeInPartyVar()>=2)
    {
       cout<<"Your SUITE pokes are:"<<endl;
       obj7=obj4.getPokeObject(obj1.getIDNumFromSuite(1));
         cout<<"Name: "<<obj7.getPokeName()<<" HP: "<<obj7.getHP()<<" A: "<<obj7.getAttack()<<" D: "<<obj7.getDefense()<<" S: "<<obj7.getSpeed()<<" M: "<<obj7.getMax()<<endl;
        if (obj1.getNumOfPokeInPartyVar()>=3)
        {
            obj8=obj4.getPokeObject(obj1.getIDNumFromSuite(2));
             cout<<"Name: "<<obj8.getPokeName()<<" HP: "<<obj8.getHP()<<" A: "<<obj8.getAttack()<<" D: "<<obj8.getDefense()<<" S: "<<obj8.getSpeed()<<" M: "<<obj8.getMax()<<endl;
        }
        if (obj1.getNumOfPokeInPartyVar()>=4)
        {
            obj9=obj4.getPokeObject(obj1.getIDNumFromSuite(3));
             cout<<"Name: "<<obj9.getPokeName()<<" HP: "<<obj9.getHP()<<" A: "<<obj9.getAttack()<<" D: "<<obj9.getDefense()<<" S: "<<obj9.getSpeed()<<" M: "<<obj9.getMax()<<endl;
        }
          if (obj1.getNumOfPokeInPartyVar()>=5)
        {
            obj10=obj4.getPokeObject(obj1.getIDNumFromSuite(4));
             cout<<"Name: "<<obj10.getPokeName()<<" HP: "<<obj10.getHP()<<" A: "<<obj10.getAttack()<<" D: "<<obj10.getDefense()<<" S: "<<obj10.getSpeed()<<" M: "<<obj10.getMax()<<endl;
        }
          if (obj1.getNumOfPokeInPartyVar()==6)
        {
            obj11=obj4.getPokeObject(obj1.getIDNumFromSuite(5));
            cout<<"Name: "<<obj11.getPokeName()<<" HP: "<<obj11.getHP()<<" A: "<<obj11.getAttack()<<" D: "<<obj11.getDefense()<<" S: "<<obj11.getSpeed()<<" M: "<<obj11.getMax()<<endl;
        }
    }
    
    
    
}