#include <iostream>
using namespace std;

//This is the header file for the Poke class, check Poke.cpp for comments on what these member functions do

class Poke
{
    private://Data members
    int identityNum;
    string pokeName;
    int HP;
    int Attack;
    int Defense;
    int Speed;
    int Max;
    string mainType;
    string secondaryType;
    int numberOfTypesAcquired;
     int badges;
     int X;
     int Y;
    
    public://Declaring all the member functions
    void setPokeX(int x);
    void setPokeY(int y);
    void setID(int id);
    void setName(string n1);
    void setHP(int h);
    void setAttack(int a);
    void setDefense(int d);
    void setSpeed(int s);
    void setMax(int m);
    void setMainType(string m);
    void setSecondType(string m2);
    void setNumOfTypes(string m3);
    int getIDNum();
    string getPokeName();
    int getHP();
    int getAttack();
    int getDefense();
    int getSpeed();
    int getMax();
    string getMainType();
    string getSecondaryType();
    string compareSpeed();
    int getNumofTypes();
    void displayBattleInfo();
    void LvlPokeUp(Poke obj1);
    bool getIsWildAns();
    char winnerCheck();
     int getBadges();
      int getX();
    int getY();
    void setNumOfTypes(Poke object);
};