// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 8 - Problem 2

#include <iostream>
#include <string>
#include <fstream>
#include "Player.h"
using namespace std;

Player::Player()//Default Constructor:points and string empty
{
    name="";
    points=0;
}

Player::Player(string nameInput, double pointsInput)//Parameterized constructor
{
    name=nameInput;
    points=pointsInput;
}

string Player::getName()//returning name
{
    return name;
}

double Player::getPoints()//returning points
{
    return points;
}

void Player::setName(string nameString)//setting name to input
{
    name=nameString;
}

void Player::setPoints(double pointsInput)//setting points to input
{
    points=pointsInput;
}


