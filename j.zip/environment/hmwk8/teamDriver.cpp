#include "Team.cpp"
using namespace std;

//Test cases for the Member functions of the Team Class

int main()
{
    Team obj1=Team();
    string obj1_teamname=obj1.getTeamName();
    int obj1_players=obj1.getNumPlayers();
     if (obj1_teamname=="")//Testing Default constructor
    {
        cout<<"Success"<<endl;
    }
    if (obj1_players==0)//Testing Default constructor
    {
        cout<<"Success"<<endl;
    }
    
    string nameInput="Jdog";
    obj1=Team(nameInput);
     string obj2_teamname=obj1.getTeamName();
    int obj2_players=obj1.getNumPlayers();
     if (obj2_teamname=="Jdog")//Testing Parameterized constructor
    {
        cout<<"Success"<<endl;
    }
    if (obj2_players==0)//Testing Default constructor
    {
        cout<<"Success"<<endl;
    }
    
    string name="Jaret";
    obj1.setTeamName(name);//setter test
    cout<<"name:"<<obj1.getTeamName()<<endl;//getter test
    
    Team team4("testing");
    cout << team4.getTeamName() << endl;
    team4.readRoster("roster1.txt");//read roster test
    int n4 = team4.getNumPlayers();//getter test shoudl be 5
    cout << n4 << endl;
    cout << team4.getPlayerPoints(-1) << endl;//-1
    cout << team4.getPlayerPoints(4) << endl;//1.7
    
    cout << team4.getPlayerName(-1) << endl;//ERROR
    cout << team4.getPlayerName(4) << endl;//Sankaralingam
}