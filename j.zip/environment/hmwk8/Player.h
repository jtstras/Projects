#include <iostream>
using namespace std;

//This is the header file for the Player class, check Player.cpp for comments on what these member functions do

class Player
{
    private://Data members
    string name;
    double points;
    
    public://Declaring all the member functions
    Player();
    Player(string nameInput, double pointsInput);
    string getName();
    double getPoints();
    void setName(string nameString);
    void setPoints(double pointsInput);
};