// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 8 - Problem 1

#include <iostream>
#include <fstream>
#include <string>
#include <vector>
using namespace std;

/**
* This function takes as input parameter arguments two vectors of integer values and returns a vector of integer values that combines the two input vectors by
  alternating between values from each of the two vectors.
 *Input parameters:int vectors
 * Output:nothing
 * Returns:combined vector
 */

vector<int> shuffle(vector<int> v1,vector<int> v2)
{
   vector<int> v3;//combined vector
   int i; int j;//for the for loops
   
   if(v1.size()==v2.size())//if both vectors have same length
   {
       for(i=0;i<v1.size();i++)//while less than vector 1 length
       {
           v3.push_back(v1[i]);//add element to combined from vector 1
           v3.push_back(v2[i]);//then add element to combined from vector 2
       }
   }
    else if (v2.empty())//if vector 2 empty
   {
       for (i=0;i<v1.size();i++)//while less than vector 1 length
       {
              v3.push_back(v1[i]);//add vector 1 elements to combined
       }
   }
    else if (v1.empty())//if vector 1 empty
   {
       for (i=0;i<v2.size();i++)//while less than vector 2 length
       {
              v3.push_back(v2[i]);//add vector 2 elements to combined
       }
   }
   else if(v1.size()<v2.size()) //if v2 has more elements than v1
   {
       for(i=0;i<v1.size();i++)//add v2 element first then add v1 element
       {
           v3.push_back(v2[i]);
           v3.push_back(v1[i]);
       }
       for(j=i;j<v2.size();j++)//adding extra elements of v2 since it is bigger
       v3.push_back(v2[j]);
   }
     else if(v1.size()>v2.size())    //if v1 has more elements than v2
   {
       for(i=0;i<v2.size();i++)//add v1 element first then add v2 element
       {
           v3.push_back(v1[i]);
           v3.push_back(v2[i]);
       }
       for(j=i;j<v1.size();j++)//adding extra elements of v1 since it is bigger
         v3.push_back(v1[j]);
   }
   return v3;
}

int main()
{
//test 1
//expected output:19 2 13 4 55 6 99 8 11 10 , because vectors are the same size
vector<int> v1{19,13,55,99,11};
vector<int> v2{2,4,6,8,10};
vector<int> v3 = shuffle(v1,v2);
for (int i=0; i < v3.size(); i++)
{
    cout << v3[i] << " "<<endl;
}
    
//test 2
//expected output:2 101 4 66 5 8 9 10, because vector 2 is bigger than vector 1
vector<int> v7{101,3,5,9};
vector<int> v8{2,4,66,8,10};
vector<int> v4 = shuffle(v7,v8);
cout<<"Second test"<<endl;
for (int i=0; i < v4.size(); i++) {
    cout << v4[i] << " "<<endl;
}

}

