#include <iostream>
#include "Player.h"
using namespace std;

//This is the header file for the Team class, check Team.cpp for comments on what these member functions do

class Team
{
    private://Data members
    string Teamname;
    vector <Player> players;
    
    public://Declaring all the member functions
    Team();
    Team(string nameInput);
    void setTeamName(string nameInput);
    void readRoster(string fileName);
    string getPlayerName(int i);
    double getPlayerPoints (int i);
    int getNumPlayers();
    string getTeamName();
};
