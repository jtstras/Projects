// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 8 - Problem 4

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "Team.h"
using namespace std;

/**
* This function takes two Team objects (filled with Playervectors) and returns the name (as a string) of the winning team.
 *Input parameters:team class objects
 * Output:nothing
 * Returns:team name of the winning team
 */

string game(Team players, Team players2)
{
    if(players.getNumPlayers() < 4 || players2.getNumPlayers() < 4)//if not enough players
    {
        return "forfeit";
    }
    int sum1=0;
    for (int i=0;i<5;i++)
    {
        sum1=players.getPlayerPoints(i)+sum1;//sum of team 1
    }
    int sum2=0;
    for (int j=0;j<5;j++)//sum of team two
    {
        sum2=players2.getPlayerPoints(j)+sum2;
    }
    if (sum1==sum2)//if sums are equal
    {
        return "draw";
    }
    else
    {//declaring winning team
        if (sum2 > sum1)
        return players.getTeamName();
        if (sum1 > sum2)
        return players2.getTeamName();
    }

}

int main()
{
//Test 1
//expedted output:My team
// Using roster1.txt and roster2.txt
Team team1("My team");
team1.readRoster("roster1.txt");
Team team2("Your team");
team2.readRoster("roster2.txt");
string winner = game(team1, team2);
cout << "The winner is: " << winner << endl;

//Test 2
//expected output:forfeit
// Using roster2.txt from Moodle
Team team3("Big boi");
team3.readRoster("roster00.txt");
Team team5("Greenie Weenies");
team5.readRoster("roster2.txt");
string winner2 = game(team3, team2);
cout << "The winner is:  "<< winner2 << endl;

}