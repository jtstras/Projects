// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 8 - Problem 3

#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "Team.h"
using namespace std;

Team::Team()//Default Constructor:points and vector empty
{
    Teamname="";
    players.empty();
}

Team::Team(string nameInput)//setting teamname & vector 
{
    Teamname=nameInput;
}

void Team::setTeamName(string nameInput)//setting teamname 
{
    Teamname=nameInput;
}

void Team::readRoster(string fileName)//reading text file and populating the vector
{
    ifstream myfile;
    myfile.open(fileName);
    string playername;double playerpoint;
    while (myfile)//while file is open
    {
        getline(myfile, playername,',');//getline called, text seperated by comma, stored in playername
        myfile>>playerpoint;//shifting the file into the variable
        players.push_back(Player(playername, playerpoint));//populating vector with both variables
        getline(myfile, playername);//getting the text after the comma
    }
    
}

string Team::getPlayerName(int i)
{
    if (i >= players.size() || i < 0)//out of bounds
    {
        return "ERROR";
    }
    else
        return players.at(i).getName();//using getName
}


double Team::getPlayerPoints(int i)
{
    if (i >= players.size() || i < 0)//out of bounds
    {
        return -1;
    }
    else
    {
        return players.at(i).getPoints();//using getPoints from player.cpp
    }
}

int Team::getNumPlayers()
{
   return players.size();
}

string Team::getTeamName()
{
    return Teamname;
}