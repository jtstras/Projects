#include "Player.cpp"
using namespace std;

//Test cases for the Member functions of the Player Class

int main()
{
    Player obj1=Player();//creating class object set to default constructor
    string obj1_name=obj1.getName();
    double obj1_points=obj1.getPoints();
    if (obj1_name=="")//Testing Default constructor
    {
        cout<<"Success"<<endl;
    }
    if (obj1_points==0)//Testing Default constructor
    {
        cout<<"Success"<<endl;
    }
    
    string nameInput="Jackie";double pointsInput=55;
    obj1=Player(nameInput, pointsInput);//parameterized constructor
    string obj1_name2=obj1.getName();
    double obj1_points2=obj1.getPoints();
    if (obj1_name2=="Jackie")//Testing Parameterized constructor
    {
        cout<<"Success"<<endl;
    }
    if (obj1_points2==55)//Testing Parameterized constructor
    {
        cout<<"Success"<<endl;
    }
    
    string nameString="Homeboy";pointsInput=67;
    obj1.setName(nameString);//Testing setter functions
    obj1.setPoints(pointsInput);
    
    cout<<"name:"<<obj1.getName()<<endl;//Testing getter functions
    cout<<"points:"<<obj1.getPoints()<<endl;
    
    
}
