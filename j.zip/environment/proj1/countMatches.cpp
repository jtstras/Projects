// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Project 1 - Problem 2

#include <iostream>
#include <string>
using namespace std;

/**
 * Algorithm:searches for substrings contained within a string
 * 1. checks if the parameter inputs are empty
 * if so returns -1
 * 2. else it sets a counter for substring occurences 
 * 3. for loop with a variable number i, as long as i is less than parent string , i increases by 1 each iteration
 * inside for loop an if statement for if substring equals any of the substrings within the string
 * add 1 to substring occurences counter
 * 4. returns number of substring occurences
 * Input parameters:character(s) (string type)
 * Output:nothing
 * Returns:an integer representing number of substring occurences
 */ 


int countMatches (string parentString, string subString)
{
  if ((subString == "" ) || (parentString == ""))// if one or more parameters are empty
  {
     return -1;//returns -1
  }
  else//if not
{
  int subsOccurences=0;//counter for substring occurences
  for (int i=0;i<parentString.length();i++)//i variable equals zero, as long as i is less than the length of substring, add 1 to i after each iteration
  {
   if (subString == parentString.substr(i,subString.length()))//if larger string equals the substring through all possible substrings of larger string
     {
      subsOccurences++;//add 1 to substring occurences 
     }
  }
  return subsOccurences;//return the number of substring occurences 
}

}


int main()
{
  //test 1
  //arguments:parentString=j, subString=jjjjjjjj
  //expected output:8
  //explanation:"jjjjjjjj" contains 8 j's
  int test1= countMatches ("jjjjjjjj", "j");
  cout<<"test1="<<test1<<endl;
   
  //test 2
  //arguments:parentString=sk,subString=skooupsk
  //expected output:2
  //explanation:skooupsk contains "sk" twice
  int test2= countMatches ("skooupsk", "sk");
  cout<<"test2="<<test2<<endl;
  
   //test 3
  //arguments:parentString="",subString=""
  //expected output:-1
  //explanation:-1 should be returned if any parameters empty
  int test3= countMatches ("", "");
  cout<<"test3="<<test3<<endl;
  
   
   //test 4
  //arguments:parentString=g,subString=gg
  //expected output:0
  //explanation:0 should be returned because loop should not execute because substring is larger than parent
  int test4= countMatches ("g", "gg");
  cout<<"test4="<<test4<<endl;
}