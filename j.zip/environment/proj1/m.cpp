#include <iostream>
#include <string>
using namespace std;

void ordinalText (int num)
{
   switch (num)
   {
       case 0:cout<<num;break;
       case 1:cout<<num<<"st"<<endl;break;
        case 2:cout<<num<<"nd"<<endl;break;
          case 3:cout<<num<<"rd"<<endl;break;
           default:cout<<num<<"th"<<endl;break;
   }
    
}

int main()
{
    ordinalText(1);
}