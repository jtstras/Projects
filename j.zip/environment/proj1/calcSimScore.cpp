// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Project 1 - Problem 4

#include <iostream>
#include <string>
using namespace std;


/**
* take the length of string inputs and typecast to double variables so that they can calculate properly
* 1.if the lengths of the string parameters dont match return 0
  2.if they do match, create a loop with integer i, for as long as i is less than the length of the strings continue loop, add i to each iteration
`   if the index of string input 1 does not match the index of string 2, add 1 to hamming distance
    calculate similarity score by taking length of string minus hamming distance divided by length of string
    return similarity score
 *Input parameters:strings for the sequences
 * Output:nothing
 * Returns:similarity score
 */ 
 

double calcSimScore (string sq1, string sq2)
{
double sq1Length=sq1.length();
double sq2Length=sq2.length();
 
if (sq1Length != sq2Length || sq1 == "")
    {
        return 0;
    }
else 
{
    double hammingDistance=0;//hamming distance
    for (int i = 0;i < sq1Length;i++) //as long as i is less than string length
    { 
        if (sq1[i] != sq2[i])// if the indexes of the string do not match
        {
            hammingDistance++; //add 1 to hamming distance
        }
    } 
        double similarityScore=((sq1Length - hammingDistance)/sq1Length);//similarity score calculation
        return similarityScore;//return statement
}
}

int main()
{
  //test 1
  //arguments:sq1="", sq2=jake
  //expected output:0
  //explanation:blank parameters should return 0
  double test1= calcSimScore ("", "jake");
  cout<<"test1="<<test1<<endl;
   
  //test 2
  //arguments:sq1=jakers,sq2=jake
  //expected output:0
  //explanation:not same length
  double test2= calcSimScore ("jakers", "jake");
  cout<<"test2="<<test2<<endl;
  
  //test 3
  //arguments:sq1=AT,sq2=AT
  //expected output:1
  //explanation:same strings
  double test3= calcSimScore ("AT", "AT");
  cout<<"test3="<<test3<<endl;
  
  //test 4
  //arguments:sq1=ATAGTCTAG,sq2=ATCTAGTAC
  //expected output:0.7
  //explanation:sim score calculation
  double test4= calcSimScore ("ATTTTGADAG", "ATATTTADAA");
  cout<<"test4="<<test4<<endl;
  
    
}