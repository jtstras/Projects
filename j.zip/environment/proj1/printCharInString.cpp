// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Project 1 - Problem 1

#include <iostream>
#include <string>
using namespace std;

/**
*Algorithm:checks if set of characters is inputted through console
* 1.Take the string passed to the function
  2.Check if its blank
  If yes, print "Given string is empty!"
  3.If not, create integer that represents a counter
  For as long as the counter is less than the number of characters in the string
  Output the character in the index of the string matching the value of the counter and end line
  Add one to counter after each iteration
 *Input parameters:character(s)
 * Output:Different string based on two categories of "" or string literal
 * Returns:nothing
 */ 

void printCharInString (string userWord)
{
    if (userWord == "")//check if input is blank
    {
        cout<< "Given string is empty!"<<endl;//output message
    }
    else // if not enter for loop matching an int counter value to the index value of string input and outputting one character per line
    {
        for (int i=0; i < userWord.length();i++)
        {
            cout<< userWord[i]<<endl;//output message
        }
    }
}

int main()
{
//test 1
//expected output
//Given string is empty!
printCharInString("");

//test 2
//expected output
//b (end line), l (end line), o (end line), etc..
printCharInString("blonde");
    
}
