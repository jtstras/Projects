// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Project 1 - Problem 5

#include <iostream>
#include <string>
using namespace std;

/**
* take the length of string inputs and typecast to double variables so that they can calculate properly
* 1.if the lengths of the string parameters dont match return 0
  2.if they do match, create a loop with integer i, for as long as i is less than the length of the strings continue loop, add i to each iteration
`   if the index of string input 1 does not match the index of string 2, add 1 to hamming distance
    calculate similarity score by taking length of string minus hamming distance divided by length of string
    return similarity score
 *Input parameters:strings for the sequences
 * Output:nothing
 * Returns:similarity score
 */ 
 

double calcSimScore (string sq1, string sq2)//calculate similarity score function
{
double sq1Length=sq1.length();
double sq2Length=sq2.length();
 
if (sq1Length != sq2Length || sq1 == "")
    {
        return 0;
    }
else 
{
    double hammingDistance=0;//hamming distance
    for (int i = 0;i < sq1Length;i++) //as long as i is less than string length
    { 
        if (sq1[i] != sq2[i])// if the indexes of the string do not match
        {
            hammingDistance++; //add 1 to hamming distance
        }
    } 
        double similarityScore=((sq1Length - hammingDistance)/sq1Length);//similarity score calculation
        return similarityScore;//return statement
}
}

/**
* 1.if the sequence length is greater than the genome length
* return 0
  2.otherwise integer i equals zero, for as long as i is less than the length of the genome
`  calculate the highest similairty score by calling the similairty score function and comparing all possible substrings of the genome to the sequence 
    if the highest similairty score is greater than zero, give that value to the variable highest score
    return highest score
 *Input parameters:strings for the genome and sequence
 * Output:nothing
 * Returns: highest similarity score
 */ 
 

double findBestSimScore (string genome, string sequence)//now we are finding the highest similarity score of a sequence of a genome
{
if (sequence.length() > genome.length())//the sequence cannot be longer than the genome
{
        return 0;//return statement
}
else //otherwise
{
        double highestScore=0;//highest score variable
        for (int i = 0; i < genome.length();i++) //for as long as i is less than genome length
        { 
        double simScore=(calcSimScore (genome.substr(i,sequence.length()),sequence));//double variable similarity score equals * the similarity score of the genome substrings between i index and 
                                                                                     //the length of the sequence and compares that to the sequence comparing all possible substrings and finding the
                                                                                     //highest possible similarity score of the sequence within the substrings of the genome
                                                                                
                                                                                    //* have to call similarity score function from above to calculate similarity score
                                                                                    
        if (simScore > highestScore)//if the calculated similarity score is greater than the highest score variable set at 0
            {
            highestScore=simScore;//highest score now is assigned the value of the calculated similairity score
            }
        }
          return highestScore;//return statement
}
}

int main()
{
  //test 1
  //arguments:genome=ATA,sequence=ATAT
  //expected output:0
  //explanation:sequence cant be longer than genome
  double test1= findBestSimScore ("ATA", "ATAT");
  cout<<"test1="<<test1<<endl;
  
  //test 2
  //arguments:genome="",sequence=AT
  //expected output:0
  //explanation:empty parameter
  double test2= findBestSimScore ("", "AT");
  cout<<"test2="<<test2<<endl;
  
  //test 3
  //arguments:genome=ATACCC,sequence=AGG
  //expected output:0.333333
  //explanation:the best sim score
  double test3= findBestSimScore ("ATACCC", "AGG");
  cout<<"test3="<<test3<<endl;
  
  //test 4
  //arguments:genome=ATACCCAHSHYTEGSG,sequence=AGGDHDHSGGGATRTT
  //expected output:0.0625
  //explanation:the best sim score
  double test4= findBestSimScore ("ATACCCAHSHYTEGSG", "AGGDHDHSGGGATRTT");
  cout<<"test4="<<test4<<endl;
}