// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Project 1 - Problem 3

#include <iostream>
#include <string>
using namespace std;

/**
* 1.menu is outputted to the user with the printMenu function, no parameters
* 2.number is inputted and returned from user input choice from the menu
  2.If input is 4, program ends
  3.If not, computer sorts input in three categories corresponding to the candidate
  4.Asks for the inputs needed for each candidate
  5.Uses those inputs to calculate the hire score for each candidate
  6.Outputs hire score to console and then will provide the menu in a loop until 4 is selected to end the program
 *Input parameters:doubles for attributes, int for menu choice
 * Output:hire score and then menu until 4 is chosen
 * Returns:nothing
 */ 
 
int printMenu()
{
    cout<<"Select a numerical option:"<<endl;//main menu 
	cout<<"=== menu ==="<<endl;
	cout<<"1. Fox"<<endl;
	cout<<"2. Bunny"<<endl;
	cout<<"3. Sloth"<<endl;
	cout<<"4. Quit"<<endl;
	int number;
	cin>>number;
	return number;//return user input
}

int main()
{
int userChoice=printMenu();//call what was returned from print menu function
while (userChoice != 4)//while user choice does not equal 4
{
if (userChoice==1)//user choice equals 1
{//the Fox 
double agility;// these three are the user inputs for attributes of the candidates depending on the candidate
double strength;
double speed;
    cout<<"Enter agility:"<<endl;//Fox you need to know his agility and strength
    cin>>agility;
    cout<<"Enter strength:"<<endl;
    cin>>strength;
    double hireScore = (1.8 * agility) + (2.16 * strength) + (3.24 * speed);//calculating hire score
    cout<<"Hire Score: "<<hireScore<<endl;//output message
    userChoice=printMenu ();//call print menu function
}

else if (userChoice==2)//user choice equals 2
{//the Bunny
double agility;// these three are the user inputs for attributes of the candidates depending on the candidate
double strength;
double speed;
    cout<<"Enter agility:"<<endl;//Need to know agility and speed
    cin>>agility;
    cout<<"Enter speed:"<<endl;
    cin>>speed;
    double hireScore = (1.8 * agility) + (2.16 * strength) + (3.24 * speed);//Calculating bunny's hire score
    cout<<"Hire Score: "<<hireScore<<endl;//output message
    userChoice=printMenu();//call print menu function
}

else if (userChoice==3)//user choice equals 3
{//the Sloth
double agility;// these three are the user inputs for attributes of the candidates depending on the candidate
double strength;
double speed;
    cout<<"Enter strength:"<<endl;//Need to know his strength and speed
    cin>>strength;
    cout<<"Enter speed:"<<endl;
    cin>>speed;
    double hireScore = (1.8 * agility) + (2.16 * strength) + (3.24 * speed);//Sloth hire score
    cout<<"Hire Score: "<<hireScore<<endl;//output message
	userChoice=printMenu();//call print menu function
}

}

}
