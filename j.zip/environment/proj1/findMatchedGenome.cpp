// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Project 1 - Problem 6

#include <iostream>
#include <string>
using namespace std;

/**
* take the length of string inputs and typecast to double variables so that they can calculate properly
* 1.if the lengths of the string parameters dont match return 0
  2.if they do match, create a loop with integer i, for as long as i is less than the length of the strings continue loop, add i to each iteration
`   if the index of string input 1 does not match the index of string 2, add 1 to hamming distance
    calculate similarity score by taking length of string minus hamming distance divided by length of string
    return similarity score
 *Input parameters:strings for the sequences
 * Output:nothing
 * Returns:similarity score
 */ 
 

double calcSimScore (string sq1, string sq2)//calculate similarity score function
{
double sq1Length=sq1.length();
double sq2Length=sq2.length();
 
if (sq1Length != sq2Length || sq1 == "")
    {
        return 0;
    }
else 
{
    double hammingDistance=0;//hamming distance
    for (int i = 0;i < sq1Length;i++) //as long as i is less than string length
    { 
        if (sq1[i] != sq2[i])// if the indexes of the string do not match
        {
            hammingDistance++; //add 1 to hamming distance
        }
    } 
        double similarityScore=((sq1Length - hammingDistance)/sq1Length);//similarity score calculation
        return similarityScore;//return statement
}
}

/**
* 1.if the sequence length is greater than the genome length
* return 0
  2.otherwise integer i equals zero, for as long as i is less than the length of the genome
`  calculate the highest similairty score by calling the similairty score function and comparing all possible substrings of the genome to the sequence 
    if the highest similairty score is greater than zero, give that value to the variable highest score
    return highest score
 *Input parameters:strings for the genome and sequence
 * Output:nothing
 * Returns: highest similarity score
 */ 
 

double findBestSimScore (string genome, string sequence)//now we are finding the highest similarity score of a sequence of a genome
{
if (sequence.length() > genome.length())//the sequence cannot be longer than the genome
{
        return 0;//return statement
}
else //otherwise
{
        double highestScore=0;//highest score variable
        for (int i = 0; i < genome.length();i++) //for as long as i is less than genome length
        { 
        double simScore=(calcSimScore (genome.substr(i,sequence.length()),sequence));//double variable similarity score equals * the similarity score of the genome substrings between i index and 
                                                                                     //the length of the sequence and compares that to the sequence comparing all possible substrings and finding the
                                                                                     //highest possible similarity score of the sequence within the substrings of the genome
                                                                                
                                                                                    //* have to call similarity score function from above to calculate similarity score
                                                                                    
        if (simScore > highestScore)//if the calculated similarity score is greater than the highest score variable set at 0
            {
            highestScore=simScore;//highest score now is assigned the value of the calculated similairity score
            }
        }
          return highestScore;//return statement
}
}

/**
* 1.if any of the string inputs are empty
* output that the parameters are empty
  2.else if the lengths of the genomes do not match
    output that they are different lengths
` 3. else call the function that calculates the best similarity score of a substring in a genome and use the parameters from this function, all three genomes
    if the best similarity score of each genome is equal then output all three genomes as the best match
    ELSE
    if genome 1 has the best or equal to best similairty score, output that genome 1 is the best match
    if genome 2 has the best or equal to best similairty score, output that genome 2 is the best match
    if genome 3 has the best or equal to best similairty score, output that genome 3 is the best match
 * Input parameters:strings for the genomes and sequence
 * Output:Which genome(s) are the best match to the sequence
 * Returns: nothing
 */ 

void findMatchedGenome (string g1, string g2, string g3, string sequencep6)
{
    if (g1 == "" || g2 == "" || g3 == "" || sequencep6 == "")//if parameter(s) are empty
    {
        cout<<"Genomes or sequence is empty."<<endl;//output message
    }
    else if (g1.length() != g2.length() || g1.length() != g3.length())//if lengths not equal
    {
        cout<<"Lengths of genomes are different."<<endl;//output message
    }
    else
    {
        double gen1=findBestSimScore (g1,sequencep6);//storing the called best similarity scores for each genomes in variables
        double gen2=findBestSimScore (g2, sequencep6);
        double gen3=findBestSimScore (g3, sequencep6);
        if (gen1 == gen2 && gen1 == gen3 && gen2 == gen3)//if are best sim scores are equal
        {
            cout<<"Genome 1 is the best match."<<endl;//output message
            cout<<"Genome 2 is the best match."<<endl;
            cout<<"Genome 3 is the best match."<<endl;
        }
          else 
        {
            if (gen1 >= gen2 && gen1 >= gen3)//if genome 1 is highest
            {
            cout<<"Genome 1 is the best match."<<endl;//output message
            }
            if (gen2 >= gen1 && gen2 >= gen3)// if genome 2 is highest
            {
                cout<<"Genome 2 is the best match."<<endl;//output message
            }
            if (gen3 >= gen1 && gen3 >= gen2)//if genome 3 is highest
            {
                cout<<"Genome 3 is the best match."<<endl;//output message
            }
        }
     }
}


int main()
{
  //test 1
  //expected output:Genomes or sequence is empty.
  //explanation:blank parameter
  findMatchedGenome ("TC", "", "CT", "TA");
  
  //test 2
  //expected output:Lengths of genomes are different.
  //explanation:lengths of the genomes are unequal
  findMatchedGenome ("AB", "BA", "BABA", "AB");
  
  //test 3
  /*expected output:
  Genome 1 is the best match.
  Genome 2 is the best match.
  Genome 3 is the best match. */ 
  //explanation:all genomes have the same sim score
  findMatchedGenome ("BABA", "BABA","BABA","BA" );
  
  //test 4
  //expected output:Genome 1 is the best match.
  //explanation:Genome 1 has the highest sim score
  findMatchedGenome ("TCTCTCTC", "LMLMLMLM", "POPOPOPO", "TC");
  
  //test 5
  //expected output:Genome 2 is the best match.
  findMatchedGenome("YOYO","BOBO","COCO","BO");
  
  //test 6
  //expected output:Genomes or sequence is empty.
  //explanation:empty sequence
  findMatchedGenome("YOYO","BOBO","COCO","");
  
  //test 7
  //expected output:Genome 3 is the best match
  findMatchedGenome("YOYO","BOBO","COCO","CO");
  
}