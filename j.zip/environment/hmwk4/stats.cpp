// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 4 - Problem 3

#include <iostream>
#include <string>
using namespace std;
#include <iomanip> 

/**
* This function executes for loops to find the minimum, maximum, and average values of an array by comparing a variable to every index of the array.
 *Input parameters:double for array, integer for length of array
 * Output:Minimum,Maximum, and Average of an array
 * Returns:nothing
 */ 

void stats(double array[], int length)
{
    double minValue=1000000000000000000;//very very large double number because I don't know how to do infinity or close to
    for (int a=0;a<length;a++)
    {
        if (array[a]<minValue)//if the index has a value less than quintillion
        {
            minValue=array[a];//set the index equal to min value, doing so for each index in the array
        }
    }
     cout<<"Min: "<<fixed<<setprecision(2)<<minValue<<endl;//output, fixed precision of two decimal points 
    
    
    double maxValue=-10000000000000000000;//has to be bigger than negative quintillion
    for (int i=0;i<length;i++)
    {
        if (array[i]>maxValue)//if the index is greater than zero, switch maxValue to index value, do this for every index in the array
        {
            maxValue=array[i];
        }
    } 
     cout<<"Max: "<<fixed<<setprecision(2)<<maxValue<<endl;//output, fixed precision of two decimal points 
     
     double comValue=0;//finding the value of every index added together in the array
     for(int j=0;j<length;j++)
     {
         comValue=comValue+array[j];//the total of all values in array
     }
     double avgValue=comValue/length;//dividing total by length of array to find the average
     cout<<"Avg: "<<fixed<<setprecision(2)<<avgValue<<endl;//output, fixed precision of two decimal points 
}

int main()
{
    //test 1
    //expected output
    //Min: 100.00 Max: 500.00 Avg: 300.00
    double array[] = {100, 500, 300};
    int length = 3;
    stats (array, length);
    
    //test 2
    //expected output
    //Min: - 500.00 Max: -100.00 Avg: -300.00
    double array2[] = {-100, -500, -300};
    int length2 = 3;
    stats (array2, length2);
}
