// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 4 - Problem 4

#include <iostream>
#include <string>
using namespace std;

/**
* This function swaps the values of the first and last elements in an array
 *Input parameters:int for array, integer for length of array
 * Output:nothing
 * Returns:nothing
 */ 


void swapFirstLast (int array[], int size)
{
    double value=array[0];//since arrays overwrite values we save the value in a variable for both the first and last elements
    double value2=array[size-1];
    array[size-1]=value;//setting the last element equal to the value of the first element
    array[0]=value2;///setting the first element equal to the value of the last element
}

int main()
{
    //test 1
    //expected output
    //300, new line 500, new line 100
    int array2[] = {100, 500, 300};
    int size2 = 3;
    swapFirstLast (array2, size2);
    for (int i=0;i<size2;i++)
    {
        cout<<array2[i]<<""<<endl;;
    }
    
    //test 2
    //expected output 
    //
    int array3[] = {12, 5000, 32, 55};
    int size3 = 4;
    swapFirstLast (array3, size3);
    for (int i=0;i<size3;i++)
    {
        cout<<array3[i]<<""<<endl;;
    }
}