// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 4 - Problem 2

#include <iostream>
#include <string>
using namespace std;

//This function prints an integer array backwards, one number for each line
//Input restrictions are an integer array and an integer for length of array
//Length should match the actual size of the array

void printArrReverse (int arr[], int len)
{
    for (int i=1;i <= len;i++)//as long as i is less than length of array iterate loop
    {
        cout<<arr[len-i]<<endl;//output the index of the array variable length minus variable i, output all indexes of array
    }
}


int main ()
{
    //test 1
    //expected output
    //100 (end line), 18 (end line), 5
    int arr[] = {5, 18, 100};
    int len = 3;
    printArrReverse(arr, len);
    
    //test 2
    //expected output
    //""
    int arr2[] = {};
    int len2 = 0;
    printArrReverse(arr2, len2);
}