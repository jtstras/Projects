// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 4 - Problem 1

#include <iostream>
#include <string>
using namespace std;

double temps [10]={-459.67,-459.67,-459.67,-459.67,-459.67,-459.67,-459.67,-459.67,-459.67,-459.67};//declaring four arrays populating the first two
string colors [5]={"Red", "Blue", "Green", "Cyan", "Magenta"};
int sequence[100];
char letters[52];

//This program takes four arrays and outputs them to the console according to their purpose
//1.10 instances of -459.67
//2.Red,Blue,Green,Cyan,Magenta in order
//3.The first 100 postive integers
//4.The upper case and lower case letters outputted side by side


int main ()
{
    for (int i=0;i<10;i++)//outputting the 10 indexes of temps array
    {
        cout<<temps[i]<<endl;
    }
    cout<<""<<endl;//space for better viewing pleasure
     for (int b=0;b<5;b++)//outputting 5 indexes of colors array
    {
        cout<<colors[b]<<endl;
    }
    cout<<""<<endl;
    for (int c=1;c<=100;c++)//outputting the first 100 positive integers
    {
        cout<<sequence[c]+c<<endl;//outputting the index plus its index number because indexes default to zero when not populated 
    }
    cout<<""<<endl;
    int k=0;//counter variable 
    for (int i=65;i<91;i++)//for 26 iterations because size of the alphabet is 26 
    {
        letters[k]=65+k;//Capital letters cooresponding to ASCII Table
         letters[k+22]=97+k;//Lowercase letters corresponding to ASCII Table
     cout<<letters[k]<<" "<<letters[k+22]<<endl;//Output the Upper case letters one at a time, then space then output lower case letters one at time on same line as its Capital letter
          k++;//add 1 to counter
         
}
}