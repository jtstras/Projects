// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 4 - Problem 5

#include <iostream>
#include <string>
using namespace std;

/**
* This function counts the number of words in a sentence
* 1.set counter to 1
* 2.i is zero, as long as i is less than the length of the sentence, add 1 to i every iteration
* loop through the sentence, if any index has a space int it, add 1 to counter
* 3.if sentence itself is blank, counter is zero
* 4.return counter
 *Input parameters:string for sentence
 * Output:nothing
 * Returns:number of words in sentence
 */ 

int getWordCount (string sentence)
{
    int counter=1;//counter is 1 because a one word sentence has no spaces
    for (int i=0;i < sentence.length(); i++)
    {
        if (sentence[i]==' ')//if any index of sentence has a space
        {
            counter++;//add 1 to counter
        }
    }
    if (sentence == "" )//if sentence itself is empty
        {
            counter=0;//no words at all
        }
    return counter;//return statement
}

int main ()
{
  //test 1
  //arguments:sentence="Have a great day"
  //expected output:4
  //explanation:four words
  double test1= getWordCount ("Have a great day");
  cout<<"test1="<<test1<<endl;
  
   //test 2
  //arguments:sentence=""
  //expected output:0
  //explanation:no words
  double test2= getWordCount ("");
  cout<<"test2="<<test2<<endl;
}