// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 5 - Problem 4

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

/**
* This function checks if an author has a book in your array of books
* 1. if no books are in array say so
* 2. else,
*   loop through the authors array and see if their is a match for author 
*   if so add 1 to counter
* 3. if no match for author output that, or output the list of books matching author
* 4. loop through the authors array again and output the titles that match the author we are searching for
 *Input parameters:string for titles array, string for authors array,  integer for length of arrays
 * Output:each book and its author
 * Returns:nothing
 */

void printBooksByAuthor (string titles[], string authors[], int numBooks, string authorName)
{
if (numBooks <= 0)//if strings are empty
    {
        cout<<"No books are stored"<<endl;
    }
else
{
    int count=0;//declare counter variable
    for (int j=0;j<numBooks;j++)
    {
            if (authors[j] == authorName)//loop through authors array to see if match authors name
            {
            count++;
            }
    }
    if (count > 0)//if a single match for authors name
             {
            cout<<"Here is a list of books by"<<" "<<authorName<<endl;//output message
             }
    else if (count==0)//not match for authors name
             {
            cout<<"There are no books by "<<authorName<<endl;//output message
             }
}
for (int j=0;j<numBooks;j++)
             {
                 if (authors[j] == authorName)//loop through array again
                 {
                  cout<<titles[j]<<endl;//populate titles array with books matching corresponding authors name
                 }
             }

}
int main()
{
    //test 1
    //Here is a list of books by Jackie Chan (next line), (Green Eggs N Ham)
    string array1[] = {"Green Eggs N Ham", "How To Be You", "Money Hunny"};
    string array2[] = {"Jackie Chan", "Mom", "Theodore Roosevelt"};
    int size1 = 3;
    string authname="Jackie Chan";
    printBooksByAuthor(array1, array2, size1, authname);
    
    //test 2
    //There are no books by Author A
    string book_titles[] = {"Book 1", "Book 2", "Book 3"};
    string book_authors[] = {"Author B", "Author C", "Author D"};
    int numberOfBooks = 3;
    string author = "Author A";
    printBooksByAuthor(book_titles, book_authors, numberOfBooks, author);
    
}
