// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 5 - Problem 2

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

/**
* This function splits the input string into pieces seperated by the delimiter, and then takes the pieces and 
* inserts them into an array up to the number of split pieces
* 
* 1.while the string at index i
* if the index at i equals the delimiter ot the index at i is the end of the string
* then if the reset variable is not equal to i
*    then if counter is equal to the size of the array, return -1 because the array cannot be smaller than the number of substrings
*    if not at counter index of words insert the substring of split at reset and reset minus i
* set reset equal to i plus 1
* return count
*
 *Input parameters:string for the variable to be split, delimiter must be a char, the array must be a string type, the size of array must be int
 * Output:nothing
 * Returns:number of pieces string was split into
 */ 

int split(string split, char delimiter, string words[], int size)
{
int count=0,i=0,reset=0;//declaring three variables we will use all integers

while(i<=split.length()) //loops through the string
{
    if(split[i]==delimiter||split[i]=='\0') //if split at index i or split at i is end of the string
    {
        if(reset!=i) //if start is not equal to i then
        {
            if(count==size)//if count equal to size of array then
            {
            return -1; //returns -1
            }
        words[count++] = split.substr(reset,i-reset); //adds the substring into words array and increments the count by 1
        }
      reset = i+ 1; //assigns i+1 to reset
     }
    i++; //increments i by 1
}
    return count; //returns the count
}

/**
* This function populates a pair of arrays with the titles and authors found in an txt file
* 1. open file
* 2. if file fails to open return negative one
* 3. if number of books stored equals the size of the array return negative two
* 4. if file is open
*   while looping through file and grabbing each line
*       if the line isn't empty
*           split the line by calling the split function
*           authors array at index j equals the first index of temp array
*           titles array at index j equals the second index of temp array
*           add 1 to j
*           num of book stored equals j
*           reset the temp arrays
* 5. close file
* 6. return number of books added
*
 *Input parameters:string for titles array, string for authors array,  integer for length of arrays
 * Output:each book and its author
 * Returns:nothing
 */ 

int readBooks (string fileName, string titles[], string authors[],int numBookStored, int size)
{
ifstream myfile;//create an output file
myfile.open(fileName.c_str());//open the file with the file stream
string line;
string arr[2];
int j=numBookStored;

if (numBookStored == size)//if number of books currently stored in array equals the size of the array
{
    return -2;
}

if (myfile.fail())//if the file fails to open
{
    return -1;
}

if(myfile.is_open())//if file is open
{
    while (getline(myfile,line))//loop through file
    {
    if (numBookStored == size)//zero case
    {
        return numBookStored;
    }
   else
   {
    if (line != "" )// if line is not empty
    {
        split (line, ',', arr , size);//split line using comma as delimiter and calling split function
        authors[j]=arr[0];//populating arrays
        titles[j]=arr[1];
        j++;
        numBookStored=j;//adding to numBookStored
        arr[0]="";//resetting temp array
        arr[1]="";
    }
    }
}
}
myfile.close();// closing the file
 
return numBookStored;//return statement
}


int main ()
{
    //test 1
    //expected output
    //-2 because numBookStored argument is equal to size
    string array1[4];
    string  array2[4];
    int x = readBooks("fileName.txt", array1, array2, 4, 4);
    cout << "Function returned: " << x << "\n";
    
    //test 2
    //expected output
    //-1 because the file does not exist
    string array3[5];
    string  array4[5];
    int y = readBooks("fileDNE.txt", array3, array4, 5, 7);
    cout << "Function returned: " << y << "\n";
    
    
}