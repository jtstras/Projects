// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 5 - Problem 3

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

/**
* This function displays all the books in an array and the corresponding author
* 1. if no books are in array say so
* 2. else,output each book and the corresponding author by index
*
 *Input parameters:string for titles array, string for authors array,  integer for length of arrays
 * Output:each book and its author
 * Returns:nothing
 */ 

void printAllBooks(string titles[], string authors[], int numBooks)
{
    if (numBooks <= 0)//if num of books is 0 or less
    {
        cout<<"No books are stored"<<endl;//output message
    }
    else
    {
         cout<<"Here is a list of books"<<endl;//output message
        for (int i=0;i < numBooks;i++)//as long as i is less than the number of books
        {
        cout << titles[i] << " by " << authors[i] << endl;//output the book located in title at i index and the author corresponding
        }
    }
}


int main()
{
    //test 1
    //should output each index of array 1 followed by "by" and array2. also a output message should preface that
    string array1[] = {"Green Eggs N Ham", "How To Be You", "Money Hunny"};
    string array2[] = {"Jackie Chan", "Mom", "Theodore Roosevelt"};
    int size1 = 3;
    printAllBooks(array1, array2, size1);
    for (int i=0;i<size1;i++)
    {
       cout << array1[i] << " by " << array2[i] << endl;
    }
    //test 2
    //no books are stored
    string book_titles[] = {};
    string book_authors[] = {};
    printAllBooks(book_titles, book_authors, -1);
}