// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 5 - Problem 5

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

/**
* This function prints out a map of points for whether the array is at or below the water level
* 1. for as long as i is less than rows
* for while j is less than 4 output into groups of 4
* if the water level input is greater than or equal to array indexed at i rows and j columns
*   output a asterik
* else(water level is less than index of array)
*   output a underscore
 *Input parameters:double for 2D array, int for number of rows, double for the water level
 * Output:a map of which indexes of the array are at or below the water level
 * Returns:nothing
 */

void floodMap (double array[][4], int rows, double waterLvl)
{
    for (int i=0;i < rows;i++)//for as long as i is less than rows
    {
        for (int j=0;j<4;j++)//grouping the output into groups of 4
        {
        if (waterLvl >= array[i][j])//if water level is equal to or greater than array at i rows and j columns
        {
            cout<<"*";//output

        }
        else
        {
            cout<<"_";//output
          
        }
        }
        cout<<endl;//seperating the output into lines of four
    }
}

int main()
{
    //test 1
    //expected output
    //since water level is 7.3 output should be 9 asteriks, 7 underscores in groups of 4 corresponding to each row of the array
    double arr[4][4] = {{5.9064, 15.7541, 6.11483, 11.3928},{16.8498, 5.736, 9.33342, 6.36095},{3.18645, 16.935, 4.7506, 9.63635},{2.22407, 0.815145, 0.298158, 13.466}};
    floodMap(arr, 4, 7.3);
    
    //test 2
    //expected output
    //since water level is 1.3 output should be all underscores because each number is higher than 1.3
    double arr2[2][4] = {{3.6, 19.95, 4.7506, 9.63635},{2.22407, 1.815145, 1.498158, 13.466}};
    floodMap(arr2, 2, 1.3);
}