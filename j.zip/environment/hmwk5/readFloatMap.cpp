// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 5 - Problem 6

#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
using namespace std;

/**
* This function splits the input string into pieces seperated by the delimiter, and then takes the pieces and 
* inserts them into an array up to the number of split pieces
* 
* 1.while the string at index i
* if the index at i equals the delimiter ot the index at i is the end of the string
* then if the reset variable is not equal to i
*    then if counter is equal to the size of the array, return -1 because the array cannot be smaller than the number of substrings
*    if not at counter index of words insert the substring of split at reset and reset minus i
* set reset equal to i plus 1
* return count
*
 *Input parameters:string for the variable to be split, delimiter must be a char, the array must be a string type, the size of array must be int
 * Output:nothing
 * Returns:number of pieces string was split into
 */ 


int split(string split, char delimiter, string words[], int size)
{
int count=0,i=0,reset=0;//declaring three variables we will use all integers

while(i<=split.length()) //loops through the string
{
    if(split[i]==delimiter||split[i]=='\0') //if split at index i or split at i is end of the string
    {
        if(reset!=i) //if start is not equal to i then
        {
            if(count==size)//if count equal to size of array then
            {
            return -1; //returns -1
            }
        words[count++] = split.substr(reset,i-reset); //adds the substring into words array and increments the count by 1
        }
      reset = i+ 1; //assigns i+1 to reset
     }
    i++; //increments i by 1
}
    return count; //returns the count
}

/**
* This function reads from a txt file and stores its contents in a 2D array
* 1.open file
* 2.if file fails to open return -1
* 3.loop through file while counter is less than the number of columns in the array
* 4. if line is not empty
* call split function to parse the line for each line of file
* the 2D array at counter number of rows and counter number of columns equals the converted double string from the line of the file
* add 1 to counter
* 5.close file
* 6.return counter
 *Input parameters:string for the file, double for 2D array, int for number of rows
 * Output:nothing
 * Returns:number of lines read
 */


int readFloatMap (string fileName, double arr[][4], int rows)
{
ifstream myfile;//create output file stream
myfile.open(fileName.c_str());//open the file with the file stream

if (myfile.fail())//if file fails to open
{
    return -1;
}

string line;
string temp[2];//temporary array
int lineindex = 0;//keep track of index

while (getline(myfile,line) && lineindex < 4)//loop though file while line index is less than columns of array
{
    if (line != "")//if line is not empty
    {
        split (line, ',', temp, rows);//splits file into seperate numbers using split function
        arr[lineindex][lineindex] = stod(line);//array at number of rows of line index and at column number of line index equals converted double from string
        lineindex++;//add 1 to line index
    }
}
    
myfile.close();//closing the file
 
return lineindex;//return number of integers added to array
}

int main()
{
//test 1
//expected output
//Function returned:-1
double floatMap[2][4];
int x = readFloatMap("DNEFile.txt", floatMap, 2);
cout << "Function returned: " << x << "\n";

//test 2
//expected output
//Function returned:-1 because the file is empty
double floatMap2[2][4];
int y = readFloatMap("empty.txt", floatMap2, 2);
cout << "Function returned: " << y << "\n";

}