// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 5 - Problem 1

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

/**
* This function populates an array for each line of an inputted text file
* 1. open file
* 2. if fail fails to open, return negative one
* 3. declare line index and line variable 
* while line index < length 
*   loop through the file reading one line at a time
*       at the index of the counter of the array populate with the converted string to intger value of the line of the text
*   add one to line index
* 4. close file
* 5.return number of integers added
 *Input parameters:string for the file, integer for the array,  integer for length of array
 * Output:nothing
 * Returns:number of integers added to array
 */ 


#include <iostream>
#include <string>
#include <fstream>
using namespace std;

int getLinesFromFile (string fileName, int array[], int length)
{
ifstream myfile;//create output file stream
myfile.open(fileName.c_str());//open the file with the file stream

if (myfile.fail())//if file fails to open
{
    return -1;
}

string line;
int lineindex = 0;//keep track of index

while (getline(myfile,line) && lineindex < length)//loop though file while line index is less than length of array
{
    if (line != "")//if line is not empty
    {
    array[lineindex] = stoi(line);//array at index of the line equals the converted string of the line
       lineindex++;
    }
}

   
myfile.close();//closing the file
 
return lineindex;//return number of integers added to array
}



int main ()
{
//test 1
//expected output
//Function returned:4, 1 nxt line, 2 nxt line, 3 nxt line, 4
int array1[4];
int x = getLinesFromFile("fileName.txt", array1, 4);
cout << "Function returned: " << x << "\n";
for(int i = 0; i < x; i++)
{
 cout << array1[i] << endl;
}

//test 2
//expected output
//Function returned:0
int array2[4];
int y = getLinesFromFile("empty.txt", array2, 4);
cout << "Function returned: " << y << "\n";
for(int j = 0; j < y; j++)
{
 cout << array2[j] << endl;
}

}