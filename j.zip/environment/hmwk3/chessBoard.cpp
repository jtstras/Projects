// CS1300 Fall 2019
// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 3 - Problem 3


#include <iostream>
using namespace std;

/*This program is a function determines if a square with a given letter or number on a chessboard, is dark (black) or light (white).The chessboard
is contained within letters a-h, numbers 1-8*/


void chessBoard (char letterInput, int numberInput)

{

int correspondingNumber=letterInput-'a'+1;

int sum=correspondingNumber+numberInput;

if(sum % 2 == 0)
{
    cout<<"black";
}
if (letterInput < 'a' || letterInput > 'h' || numberInput < 1 || numberInput > 8)
{
    cout<< "Chessboard squares can only have letters between a-h and numbers between 1-8.";
}
else if (sum % 2 != 0)
{
    cout<<"white";
}

}

int main ()

{
//test 1
//expected output
//Chessboard squares can only have letters between a-h and numbers between 1-8.
chessBoard ('b',9);

//test 2
//expected output
//white 
chessBoard ('c',4);
}
