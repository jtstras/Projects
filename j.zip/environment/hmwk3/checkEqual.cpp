// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 3 - Problem 2

#include <iostream>
using namespace std;

/* This function compares three numbers to each other. First it looks at whether the numbers are all the same, then it looks to see
if all three numbers are different. The function will output messages respectively and if neither of those cases exist the function
will output "Neither"
*/ 

void checkEqual (int num1, int num2, int num3)

{
    

if (num1 == num2 & num2 == num3)
{
cout<< "All same" ;
} 

else if (num1 != num2 & num2 != num3 & num1 != num3)
{
cout<< "All different";
}

else 
{
cout<< "Neither";
}

}

int main ()

{
//test 1
//expected output
//neither
checkEqual (2,1,2);

//test 2
//expected output
//All same
checkEqual (1,1,1);
}
