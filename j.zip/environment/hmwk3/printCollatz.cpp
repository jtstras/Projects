// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 3 - Problem 7

#include <iostream>
using namespace std;

/* This function prints the Collatz sequence for a number. The code does not seem that smooth to me but I struggled to find the less extraneous path to the solution as my 
code would execute through the odd sequence and finish */ 

void printCollatz (int startingNumber)
{
if (startingNumber <= 0)
    {
        cout<< "invalid number";
    }
else 
   {
        int evenNum;
        int oddNum;

       cout<<startingNumber;
        while(startingNumber>1 && startingNumber % 2 == 0)
       {
           evenNum=startingNumber/2;
           cout<<" "<<evenNum;
           startingNumber=evenNum;
       }
       while (startingNumber>1 && startingNumber % 2 != 0)
       {
           while (startingNumber>1 && startingNumber % 2 != 0)
          { 
           oddNum=(startingNumber*3)+1;
           cout<< " "<<oddNum;
           startingNumber=oddNum;
          }
           while (startingNumber>1 && startingNumber % 2 == 0)
           {
           evenNum=startingNumber/2;
           cout<<" "<<evenNum;
           startingNumber=evenNum;
           }
       }
       
   }
}

int main ()
{
//test 1
//expected output
//3 10 5 16 8 4 2 1
printCollatz(3);

//test 2
//expected output
//8 4 2 1
printCollatz(8);
    
}
