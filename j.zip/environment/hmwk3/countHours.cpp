// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 3 - Problem 5

#include <iostream>
using namespace std;

/* This function will take a month input as an integer and then output the total number of hours in that month using a switch statement
Assuming the year is not a gap year */ 

int countHours (int month)
{
switch (month)
{
    case 1:return 744;break;
    case 2:return 672;break;
    case 3:return 744;break;
    case 4:return 720;break;
    case 5:return 744;break;
    case 6:return 720;break;
    case 7:return 744;break;
    case 8:return 744;break;
    case 9:return 720;break;
    case 10:return 744;break;
    case 11:return 720;break;
    case 12:return 744;break;
    default:return 0;break;
}
    
}

int main()
{
//test 1
//expected output
//744
countHours(1);

//test 2
//expected output
//744
countHours (12);
}