// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 3 - Problem 10

#include <iostream>
using namespace std;

/* This program will print a grid based on an integer input that represents rows and columns and uses two for loops to construct the grid/ */ 

void printGrid (int gridSize)
{
    if (gridSize <= 0)
    {
        cout<< "The grid can only have a positive number of rows and columns."<<endl;
    }
    if (gridSize > 0)
    {
        for (int i=0;i<(2*gridSize+1);i++)
        {
            for (int j=0;j<(3*gridSize+1);j++)
            {
                if(i % 2 == 0)
                {
                    if (j % 3 == 0)
                    {
                        cout<<"+";
                    }
                    else
                    {
                        cout<<"-";
                    }
                }
                else 
                {
                    if (j % 3 == 0)
                    {
                        cout << "|";
                    }
                    else 
                    {
                        cout<< " ";
                    }
                }
            }
                cout<<endl; // struggled with this but an endl right here will format the grid correctly
        }
    }
}

int main()
{
//test 1
//expected output
//Should output 11 "rows", 11 "columns"
printGrid(10);

//test 2
//expected output
//Should output 5 "rows", 5 "columns"
printGrid(5);
}