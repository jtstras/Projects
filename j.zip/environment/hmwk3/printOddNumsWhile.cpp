// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 3 - Problem 8

#include <iostream>
using namespace std;

/* This function will take a number and output starting at 1, all the odd numbers from 1 to the number input */ 

void printOddNumsWhile (int maxValue)
{

int start=1;
     
while (start <= maxValue)
{
    
cout<< start << endl;
start=start+2;
}

}

int main ()
{
//test 1
//expected output
/*
1
3
5
7
9
11
13
*/
printOddNumsWhile (13);

//test 2
//expected output
/*
1
3
*/ 
printOddNumsWhile (5);
    
}