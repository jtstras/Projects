// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 3 - Problem 6

#include <iostream>
using namespace std;

/* This function takes a integer input representing a year in the Gregorian calendar and calculates whether the year
is a leap year or not a leap year */ 

bool checkLeapYear (int year)
{
    if (year < 1582 && year % 4 == 0 || year > 1582 && year % 4 == 0 && year % 100 != 0|| year % 400 == 0)
    {
        return true;
    }
}

int main ()
{

//test 1
//expected output
//1400 is a leap year.
checkLeapYear(1400);

//test 2
//expected output
//2019 is not a leap year.
checkLeapYear (2019);

}