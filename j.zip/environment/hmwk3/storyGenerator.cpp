// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 3 - Problem EC

#include <iostream>
using namespace std;

/* This story generator has three sets of stories that follow a MadLibs format and then pressing 4 will effectively
quit the game */ 

int main()
{
int storyNumber;
cout<< "Which story would you like to play? Enter the number of the story (1, 2, or 3) or type 4 to quit"<<endl;
cin>>storyNumber;
if(storyNumber==1)
{
    string noun;
    cout<<"Enter a noun:"<<endl;
    cin>>noun;
    cout<<"Be careful not to vacuum the "<<noun<<" when you clean under your bed."<<endl;
    cout<<endl;
    cout<< "Which story would you like to play? Enter the number of the story (1, 2, or 3) or type 4 to quit"<<endl;
    cin>>storyNumber;
    if (storyNumber==4)
{
    cout<<"Good bye!"<<endl;
}
}
else if (storyNumber==2)
{
    string name;
    string occupation;
    string place;
    cout<<"Enter a name:"<<endl;
    cin>>name;
    cout<<"Enter an occupation:"<<endl;
    cin>>occupation;
    cout<<"Enter a place:"<<endl;
    cin>>place;
    cout<<name<<" is a "<<occupation<<" who lives in "<<place<<"."<<endl;
    cout<<endl;
    cout<< "Which story would you like to play? Enter the number of the story (1, 2, or 3) or type 4 to quit"<<endl;
    cin>>storyNumber;
    if (storyNumber==4)
{
    cout<<"Good bye!"<<endl;
}
}
else if (storyNumber==3)
{
    string pluralNoun;
    string occupation3;
    string animal;
    string place;
    cout<<"Enter a plural noun:" <<endl;
    cin>>pluralNoun;
    cout<<"Enter an occupation:"<< endl; 
    cin>>occupation3;
    cout<<"Enter an animal:"<< endl;
    cin>>animal;
    cout<<"Enter a place:"<<endl;
    cin>>place;
    cout<<"In the book War of the "<<pluralNoun<<","<<" the main character is an anonymous "<<occupation3<<" who records the arrival of the "<<animal<<"s"<<" in "<<place<<"."<<endl;
    cout<<endl;
    cout<< "Which story would you like to play? Enter the number of the story (1, 2, or 3) or type 4 to quit"<<endl;
    cin>>storyNumber;
    if (storyNumber==4)
{
    cout<<"Good bye!"<<endl;
}
}
else if (storyNumber==4)
{
    cout<<"Good bye!"<<endl;
}
}