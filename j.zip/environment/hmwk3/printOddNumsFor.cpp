// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 3 - Problem 9

#include <iostream>
using namespace std;

/* This function uses a for loop to take a number input and calculate all the positive odd numbers less than or equal to the input */ 

void printOddNumsFor (int maxValue)
{
   
    for (int start=1;start <= maxValue;start=start+2)
    {
        cout<< start << endl;
    }
}

int main()
{
//test 1
//expected output 
//
printOddNumsFor (-10);

//test 2
//expected output
/*
1
3
5
*/
printOddNumsFor(7);
}