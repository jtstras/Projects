// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 3 - Problem 1

/*This program is an algorithm where it takes an input and then sorts the input into negative number, even number, or odd number
From there it returns the next value in the Collatz sequence using an if loop
*/

#include <iostream>
using namespace std;

int collatzStep (int parameter)
{
if (parameter < 0)
{
    return 0;
}

if (parameter % 2 == 0)
{
    return parameter/2;
}

else if (parameter % 2 != 0) 
{
    return parameter*3+1;
}

}

int main()

{
//test 1
//expected output
//370
collatzStep (123);

//test 2
//expected output
//3
collatzStep (6); 
}

