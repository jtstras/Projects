// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 3 - Problem 4

#include <iostream>
using namespace std;

/* This function will take a integer input and return how many digits are in the integer
The input can be a negative or positive number */ 

int countDigits (int num)
{
int count=0;

if (num==0)
{
    return 1;
}

while (num != 0)
    {
       num=num/10;
       ++count;
    }
return count;
}

int main()
{
//test 1
//expected output
//1
countDigits (0);

//test 2
//expected output
//7
countDigits (5555555);
}
