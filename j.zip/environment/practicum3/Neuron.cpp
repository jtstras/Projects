Neuron::Neuron(){
    transmitter="";
    inputWeight=0.5;
    threshold=10;
}

Neuron::Neuron(string s, double iw, double t){
    transmitter=s;
    inputWeight=iw;
    threshold=t;
}

void Neuron::setInputWeight(double iw){
    inputWeight=iw;    
}

void Neuron::setThreshold(double t){
    threshold=t;
}

void Neuron::setTransmitter(string s){
    transmitter=s;
}

double Neuron::getInputWeight(){
    return inputWeight;
}

string Neuron::getTransmitter(){
    return transmitter;
}

double Neuron::getThreshold(){
    return threshold;
}

bool Neuron::activate(double input){
    double activationQuotient;
    activationQuotient=input*inputWeight;
    if (activationQuotient>=threshold)
    {
        return true;
    }
    else
    {
        return false;
    }
}



