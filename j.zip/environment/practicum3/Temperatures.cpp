Temperatures::Temperatures(){
    for (int i=0;i<7;i++)
    {
        temp_values[i]=120.0;
    }
       for (int i=0;i<7;i++)
    {
        days[i]="";
    }
}

void Temperatures::ReadFile(string fileName){
string line;
int i = 0;
ifstream myfile("example.txt");
if (myfile.is_open())
{
    while (getline(myfile, line))

    {

    split (line, ',',)

    i = i + 1;

    }

myfile.close();

}

else

cout << "Unable to open file";

}
}

float Temperatures::getMinTemp(){
     minTemp=temp[0];
      for(int count = 0; count < 7; count++)
   {
   if(temp[count]<minTemp){
       minTemp=temp[count];
           }
   }
   return minTemp;
}

string Temperatures::getMinTempDay(){
       for(int count = 0; count < 7; count++)
   {
   if(minTemp==temp[count]){
       return days[count];
       }
   }
}