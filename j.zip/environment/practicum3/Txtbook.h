#include <iostream>
#include <string>
using namespace std;

//MAKE SURE AND READ THE MEMBER FUCNTIONS CAREFULLY.PUSHBACK MEANS VECTOR OBJECT IF IT AINT AN INPUT

class Textbook
{
    private://Data members
    string title;
    int pages;
    float cost;
    bool online;
    
    public://Declaring all the member functions
    Textbook();
    Textbook(string t, int p, float c, bool o);
    void setTitle(string t);
    string getTitle();
    void setPages(int p);
    int getPages();
    void setCost(float c);
    float getCost();
    void setOnline(bool o);
    bool getOnline();
    float costPerPage();
    

};