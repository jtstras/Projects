#include<iostream>
#include<fstream>

using namespace std;

const int MAX = 50;

class OddEven
{
    private:
        int numbers[MAX];
    public:
        //Constructor to initialize all numbers to -1
        OddEven()
        {
            for(int i = 0; i < MAX; i++)
                numbers[i] = -1;
        }
    
        /*Method to read numbers from file*/
        void ReadFile(string fileName)
        {
            int i = 0;
            ifstream f(fileName);
            while(!f.eof())
            {
                f>>numbers[i];
                i++;
            }
            f.close();
        }
    
        /*Method to return total numbers of odd numbers found in dataset*/
        int getOddCount()
        {
            int i = 0, count = 0;
            while(numbers[i] > 0)//while numbers are positive
            {
                if(numbers[i] % 2 != 0)//If number is odd
                    count++;
                i++;
            }
            return count;
        }
    
        /*Method to return total numbers of even numbers found in dataset*/
        int getEvenCount()
        {
            int i = 0, count = 0;
            while(numbers[i] > 0)//while numbers are positive
            {
                if(numbers[i] % 2 == 0)//If number is even
                    count++;
                i++;
            }
            return count;
        }
};