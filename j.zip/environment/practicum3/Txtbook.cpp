Textbook::Textbook(){
  title = "";
  pages  = 0;
  cost = 0.0;
  online = false;
}

Textbook::Textbook(string t, int p, float c, bool o){
  title = t;
  pages  = p;
  cost = c;
  online = o;
}
void Textbook::setTitle(string t){
  title=t;
}
string Textbook::getTitle(){
  return title;
}
void Textbook::setPages(int p){
  pages=p;
}
int Textbook::getPages(){
  return pages;
}
void Textbook::setCost(float c){
  cost=c;
}
float Textbook::getCost(){
  return cost;
}
void Textbook::setOnline(bool o){
  online=o;
}
bool Textbook::getOnline(){
  return online;
}
float Textbook::costPerPage(){
  return (cost / pages);
}