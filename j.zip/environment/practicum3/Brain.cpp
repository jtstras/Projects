
Brain::Brain()
{
   patientName = "John Doe";
}

Brain::Brain(string name)
{
   patientName = name;
}

bool Brain::AddRegion(double value, string region)
{
   if (activations.size() < 100)
   {
      activations.push_back(value);
      regions.push_back(region);
      return true;
   }
   return false;
}

double Brain::CalcAverage()
{   
   int count=0; 
   double sum=0;
   for (int i=0 ; i < activations.size() ; i++) 
      if (activations[i] > 0.) 
      {
         sum += activations[i]; 
         count++;
      }

   if (count > 0)
      return sum / count;
   else
      return 0;
}

int Brain::CountRegion(double min_activation)
{   
   int count=0; 
   for (int i=0 ; i < activations.size() ; i++) 
      if (activations[i] > min_activation) 
         count++;
   return count;
}
int Brain::CountSameRegion(string region)
{   
   int count=0; 
   for (int i=0 ; i < regions.size() ; i++) 
      if (regions[i] == region) 
         count++;
   return count;
}