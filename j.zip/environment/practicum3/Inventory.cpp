Inventory::Inventory()
{
   inventoryLocation = "Zone-1";
}

Inventory::Inventory(string location)

{

   inventoryLocation= location;

}

bool Inventory::AddItem(string name, int quantity, float cost)
{
   if ( Items.size() < 100)
   {
      Items.push_back(name);
      ItemQuantity.push_back(quantity);
      ItemCost.push_back(cost);

      return true;
   }

   return false;
}


float Inventory::CalcTotalCost()
{  
   float sum=0;
   
   for (int i=0 ; i < Items.size(); i++) 
   {
      sum += ItemCost[i]; 
   }
   
    return sum;
}

float Inventory::getMaxCost()
{   
   float max=0; 
   
   for (int i=0 ; i < Items.size() ; i++){
   
      if (ItemCost[i] >= max) 
         max = ItemCost[i];
    }
   return max;
}

string Inventory::getMaxQuantityItem()
{   
   int max=0; 
   string item = "";
   
   for (int i=0 ; i < Items.size() ; i++) 
   {
      if (ItemQuantity[i] > max)
      {
         max = ItemQuantity[i];
         item = Items[i];
       }
	}
   return item;
}