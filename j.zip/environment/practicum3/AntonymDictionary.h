
//MAKE SURE AND READ THE MEMBER FUCNTIONS CAREFULLY.PUSHBACK MEANS VECTOR OBJECT IF IT AINT AN INPUT

class AntonymDictionary
{
    private://Data members
    string words[50];
    string antonyms[50];
    
    public://Declaring all the member functions
    AntonymDictionary();
    int LoadWords(string filename);
    int SearchForWord(string wordName);
    string GetAntonym(string wordName);
};