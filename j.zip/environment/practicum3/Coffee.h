#include <iostream>
#include <string>
#include <fstream>
using namespace std;

//MAKE SURE AND READ THE MEMBER FUCNTIONS CAREFULLY.PUSHBACK MEANS VECTOR OBJECT IF IT AINT AN INPUT

class Coffee
{
    private://Data members
    string roastType;
    float temp;
    
    public://Declaring all the member functions
    Coffee();
    Coffee(string rt, float t);
    void setRoastType(string rt);
    string getRoastType();
    void setTemp(float t);
    float getTemp();
    string drinkability();
    
};