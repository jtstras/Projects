#include <iostream>
#include <fstream>
using namespace std;

class Temperature{
   //variable declare
   private :
       string days[7]={"Sunday"," Monday", "Tuesday"," Wednesday", "Thursday", "Friday", "Saturday"};
       int day[7];
       float temp[7];
       float minTemp;
   public:
       //default construcutre
   Temperature(){
      
   }
   //function to read data from file
   void ReadFile(){
       ifstream inFile;
       //read data from temp.xt
   inFile.open("temp.txt");
   //store data in array day and temp
       for(int count = 0; count < 7; count++)
   {
   inFile >>day[count]>>temp[count];
   }
   //print out the data read from file
   for(int count = 0; count < 7; count++)
   {
   cout <<day[count]<< " "<<temp[count]<<endl;
   }
   }
   //function to return minimum temperature
   float getMinTemp(){
       minTemp=temp[0];
      for(int count = 0; count < 7; count++)
   {
   if(temp[count]<minTemp){
       minTemp=temp[count];
           }
   }
   return minTemp;
   }
   //function to return the day of minimum temperature day
   string getMinTempDay(){
   for(int count = 0; count < 7; count++)
   {
   if(minTemp==temp[count]){
       return days[count];
       }
   }
      
   }
};