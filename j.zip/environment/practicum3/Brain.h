#include <iostream>
using namespace std;

//MAKE SURE AND READ THE MEMBER FUCNTIONS CAREFULLY.PUSHBACK MEANS VECTOR OBJECT IF IT AINT AN INPUT

class Brain
{
    private://Data members
    patientName;
    vector <double> activations;
    vector <string> regions;
    
    public://Declaring all the member functions
    Brain();
    Brain(string name);
    bool AddRegion(double value, string region);
    double calcAverage();
    int countRegion(double min_activation);
    int CountSameRegion(string region);
    
};