Coffee::Coffee(){
    roastType="";
    temp=180.0;
}

Coffee::Coffee(string rt, float t){
    roastType=rt;
    temp=t;
}

void Coffee::setRoastType(string rt){
    roastType=rt;
}

string Coffee::getRoastType(){
    return roastType;
}

void Coffee::setTemp(float t){
    temp=t;
}

float Coffee::getTemp(){
    return temp;
}

string Coffee::drinkability(){
    if (temp < 100.0)
    {
        return "Too Cold";
    }
    if (temp >= 180.0)
    {
        return "Too Hot";
    }
    if (temp >= 160.0 && temp < 180.0)
    {
        return "Hot";
    }
    else
    {
        return "Just Right";
    }
}