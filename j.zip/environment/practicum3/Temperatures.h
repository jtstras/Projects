#include <iostream>
#include <string>
using namespace std;

//MAKE SURE AND READ THE MEMBER FUCNTIONS CAREFULLY.PUSHBACK MEANS VECTOR OBJECT IF IT AINT AN INPUT

class Temperatures
{
    private://Data members
   float temp_values[7];
   int day[7];
   string days[7]={"Sunday"," Monday", "Tuesday"," Wednesday", "Thursday", "Friday", "Saturday"};
    
    public://Declaring all the member functions
    Temperatures();
    void ReadFile();
    int getMinTemp();
    string getMinTempDay();
    
};