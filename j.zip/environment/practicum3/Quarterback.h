#include <iostream>
#include <string>
using namespace std;

//MAKE SURE AND READ THE MEMBER FUCNTIONS CAREFULLY.PUSHBACK MEANS VECTOR OBJECT IF IT AINT AN INPUT

class Quarterback
{
    private://Data members
    int pass_completes;
    int pass_attempts;
    int total_yards;
    int touchdowns;
    int intercepts;
    string name;
    
    public://Declaring all the member functions
    Quarterback();
    Quarterback(string n, int comp, int att,int yards, int td, int i);
    Quarterback(string d);
    void setName(string new_name);
    void setComp(int x);
    int getComp();
    string getName();
    void setAtt(int x);
    int getAtt();
    void setYards(int x);
    int getYards();
    void setTD(int x);
    int getTD();
    void setPick(int x);
    int getPick();
    void PassCompleted(int x);
    void PassAttempted();
    void Interception();
    float PasserRating();
    void Touchdown(int x);
    
};