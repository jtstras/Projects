#include <iostream>
#include <fstream>
#include <string>
using namespace std;


AntonymDictionary::AntonymDictionary(){
    for (int i=0;i<50;i++)
    {
        words[i]="";
    }
      for (int i=0;i<50;i++)
    {
        antonyms[i]="";
    }
}

int AntonymDictionary::LoadWords(string filename){
  ifstream myfile;
        //read data from temp.xt
   myfile.open("filename.txt");
   //store data in array day and temp
     if (myfile.is_open()){
       for(int count = 0; count < 7; count++)
   {
   myfile >>words[count]>>antonyms[count];
   }
     }
    else 
   {
       return -1;
   }
   //print out the data read from file
/*   for(int count = 0; count < 7; count++)
   {
   cout <<day[count]<< " "<<temp[count]<<endl;
   }
   */

}

int AntonymDictionary::SearchForWord(string wordName){
    
   /* for (int i=0;i<50;i++)
    {
        if (words[i]=wordName)
        {
            return i;
        }
        else
        {
            return -1;
        }
    }
    */
    
}

int AntonymDictionary::GetAntonym(string wordName){
       for (int i=0;i<50;i++)
    {
        if (antonyms[i]=wordName)
        {
            return wordName;
        }
        else
        {
            return "";
        }
    }
}

int main(){
    
}