#include <iostream>
#include <string>
using namespace std;

//MAKE SURE AND READ THE MEMBER FUCNTIONS CAREFULLY.PUSHBACK MEANS VECTOR OBJECT IF IT AINT AN INPUT
//With this one, max age I just picked a big number, for the arrays look at the for loop in the constructor

class ChildGrowth
{
    private://Data members
    string name;
    int currentAge;
    int weightMetricConversion;
    float height[10];
    float weight[10];
    int Max_Age=100;
    
    public://Declaring all the member functions
    ChildGrowth();
    ChildGrowth(string n);
    ChildGrowth(string n, int a);
    ChildGrowth(string n, int a, float h[], float w[]);
    string getName();
    void setName(string new_name);
    int getCurrentAge();
    void setCurrentAge(int a);
    void setHeight(float h[]);
    void setWeight(float w[]);
    float feetToMeter(float feet);
    float poundToKg(float pound);
    float calculateBmi(int age);
    string getCategory(int age);

    
};