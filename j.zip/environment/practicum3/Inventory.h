#include <iostream>
using namespace std;

//MAKE SURE AND READ THE MEMBER FUCNTIONS CAREFULLY.PUSHBACK MEANS VECTOR OBJECT IF IT AINT AN INPUT

class Inventory
{
    private://Data members
    string inventoryLocation;
   vector <string> Items;
   vector <int> ItemQuantity;
   vector <float> ItemCost;
    
    public://Declaring all the member functions
    Inventory();
    Inventory(string location);
    bool AddItem(string name, int quantity, float cost);
    float CalcTotalCost();
    float getMaxCost();
    string getMaxQuantityItem();

};