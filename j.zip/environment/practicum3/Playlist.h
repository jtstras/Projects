#include <iostream>
using namespace std;

//MAKE SURE AND READ THE MEMBER FUCNTIONS CAREFULLY.PUSHBACK MEANS VECTOR OBJECT IF IT AINT AN INPUT

class Playlist
{
    private://Data members
    string playlistName;
    vector <string> songTitle;
    vector <string> songBand;
    vector <int> songId;
    string currentSong;
    
    public://Declaring all the member functions
    Playlist();
    Playlist(string name);
    bool addSong(string name, string band, int Id);
    int playSongById(int Id);
    int playSongByTitle(string title);
    int getBandCount(string band);
    
};