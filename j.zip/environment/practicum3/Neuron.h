#include <iostream>
using namespace std;

//MAKE SURE AND READ THE MEMBER FUCNTIONS CAREFULLY.PUSHBACK MEANS VECTOR OBJECT IF IT AINT AN INPUT

class Neuron
{
    private://Data members
    double inputWeight;
    double threshold;
    string transmitter;
    
    public://Declaring all the member functions
    Neuron();
    Neuron(string s, double iw, double t)
    void setInputWeight(double iw);
    void setThreshold(double t);
    void setTransmitter(string s);
    double getInputWeight();
    double getThreshold();
    string getTransmitter();
    bool activate(double input);
};