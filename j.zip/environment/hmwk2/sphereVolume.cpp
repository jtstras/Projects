// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 2 - Problem 5

//This program uses a void function to calculate volume of a sphere

#include <iostream>
#include <math.h>
using namespace std;

//This function calculates sphere volume

void sphereVolume(double radius)
{
    cin >> radius;
    double volume;
    volume = (4.0/3.0) * M_PI * pow(radius, 3);
    cout << "volume: " << volume << endl;
}

int main(){
//test 1
//expected output
//1629.51
sphereVolume(7.3);

//test 2
//expected output
//-137.258
sphereVolume(-3.2);
}