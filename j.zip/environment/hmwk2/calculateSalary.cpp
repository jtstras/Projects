// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 2 - Problem 10
 
//This program will calculate the salary of a field worker who makes $10 an hour and varies in his daily hours worked

#include <iostream>
#include <math.h>
using namespace std;

//This function calcukates the salary of a field worker who makes $10 an hour and daily time working varies on weather

int calculateSalary (int rainyDays, int coldDays, int sunnyDays)
{
    cin >> rainyDays; 
    cin>> coldDays; 
    cin>> sunnyDays;
    int salary=((rainyDays*5)+(coldDays*4)+(sunnyDays*8))*10;
    
    return salary;
    
}

int main()
{
//test 1
//expected output
//0
calculateSalary(0,0,0);

//test 2
//expected output
//2090
calculateSalary(5,8,19);
    
}
