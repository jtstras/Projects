// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 2 - Problem 2

//This program outputs a class greeting corresponding to your CS class number

#include <iostream>
using namespace std;

int main (){
    int course_Number;
    cout<<"Enter a CS course number:"<<endl;
    cin>>course_Number;
    cout<<"Hello, CS "<< course_Number <<" World!"<<endl;
}