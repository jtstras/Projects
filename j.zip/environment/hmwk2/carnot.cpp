// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 2 - Problem 9

//This program uses the Carnot efficency equation to calculate the maximum possible efficency of a heat engine

#include <iostream>
#include <math.h>
using namespace std;

//This function calculates the maximum possible efficency of a heat engine operating between two reservoirs at different temperatures
//coldTemp refers to the cold temperature reservoir integer value
//hotTemp refers to the hot temperature reservoir integer value

double carnot (int coldTemp, double hotTemp)
{
    cin >> coldTemp; hotTemp;
   double carnotEfficency= 1-(coldTemp/hotTemp);
   
   return carnotEfficency;
}

int main()
{
//test 1
//expected output
//0.730028
carnotEfficency(294, 1089);

//test 2
//expected output
//-1.2
carnotEfficency(22, 10);
    
}
