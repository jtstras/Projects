// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 2 - Problem 8

//This function will take an intial population value and use a pre-determined birth,death, and immigration rate to calculate the population value after a year

#include <iostream>
#include <math.h>
using namespace std;

//This function takes the a intital population and then calculates the population after one year given the pre-defined birth,death, and immigration rate.

int population (int initialPopulation)
{
    cin >> initialPopulation;
    int seconds_in_year=31536000;
    int birthsYear=seconds_in_year/8;
    int deathsYear=seconds_in_year/12;
   int immigrantsYear=seconds_in_year/27;
    int oneYearpopulation=(initialPopulation+(birthsYear+immigrantsYear)-deathsYear);
}

int main()
{
//test 1
//expected output
//2567000
population(85000);

//test 2
//expected output
//14847478
population(12365478);
    
}
