// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 2 - Problem 6

//This program uses a void function to calculate sphere surface area

#include <iostream>
#include <math.h>
using namespace std;

//This function calculates sphere surface area

void sphereSurfaceArea(double radius)
{
    cin >> radius;
    double surfacearea;
    surfacearea = (4) * M_PI *pow(radius,2);
    cout << "surface area: " << surfacearea << endl;
}

int main(){
//test 1
//expected output
//314.159
sphereVolume(5);

//test 2
//expected output
//128.68
sphereVolume(-3.2);
}