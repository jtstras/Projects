// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 2 - Problem 7

//This program will convert a integer in seconds and output that integer in hours, minutes, seconds

#include <iostream>
#include <math.h>
using namespace std;

//This function takes a input in seconds and outputs the time in hours, minutes, seconds

void convertSeconds (int secondsinput)
{
    cin >> secondsinput;
    int hours;
    int minutes;
    int seconds;
    hours=secondsinput/3600;
    secondsinput %= 3600;
    minutes=secondsinput/60;
    secondsinput %= 60;
    seconds=secondsinput;
    cout << hours <<" hour(s) "<< minutes <<" minute(s) "<< seconds << " second(s) "<< endl;
}

int main()
{
//test 1
//expected output
//0 hour(s) 1 minute(s) 0 second(s)
convertSeconds (60);

//test 2
//expected output
//0 hour(s) 0 minute(s) 0 second(s)
convertSeconds (0);
    
}