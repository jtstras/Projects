// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 2 - Problem 3

//This program outputs a CS class greeting using aa function

#include <iostream>
using namespace std;

//This function will give you a class greeting corresponding to your CS class number

void classGreeting (int course_number)
{
    cout<<"Course Number?";
    cin>>course_number;
cout<<"Hello, CS "<< course_number << " World! " << endl;

}

int main (){
//test 1
//expected output
//Hello CS 1300 World!
classGreeting (1300);

//test 2
//expected output
//Hello CS 2270 World!
classGreeting (2270);

}