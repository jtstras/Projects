// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 2 - Problem 1 

#include <iostream>
using namespace std;

int main (){
    cout<<"Hello World!"<< endl ;
}

