// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 2 - Problem 4

//This program will calculate the volume and surface area of a sphere

#include <iostream>
#include <math.h>
using namespace std;

int main(){
    cout << "Enter a radius: " << endl;
    double radius;
    cin >> radius;
    double volume;
    volume = (4.0/3.0) * M_PI * pow(radius, 3);
    cout << "volume: " << volume << endl;
    
    //your code goes here
    
    double surface_Area;
    surface_Area= (4) * M_PI *pow(radius,2);
    cout<< "surface area: "<<surface_Area<<endl;
   
}