// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 9 Prob 1

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

//This function uses a while loop to convert decimal numbers to binary

string decimalToBinaryIterative(int convertDec)
{
    string s;//returning string
    if (convertDec==0)//edge case
    return "0";
    
    while (convertDec > 0) 
    {
        if (convertDec % 2 == 0) //if remainder is 0
        {
            s = "0" + s;
        } 
        else 
        {
            s = "1" + s;
        }
        convertDec = convertDec / 2;//next digit
    }
    return s;
}

int main()
{
//test 1
//expected output:1011
int convertDec=11;
string result=decimalToBinaryIterative(convertDec);
cout<<"Got: "<<result<<endl;

//test 2
//expected output:101100
int convertDec2=44;
string result2=decimalToBinaryIterative(convertDec2);
cout<<"Got: "<<result2<<endl;

}