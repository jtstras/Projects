// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 9 Prob 2

#include <iostream>
#include <string>
#include <fstream>
using namespace std;

//Recursion is just calling a function within its function, which is sometimes more efficent than loops

//This function converts a decimal number to binary

string decimalToBinaryRecursive(int convertDec)
{
    if(convertDec == 0) 
        return "0";
    else if(convertDec == 1) 
        return "1";//because string should be returned
    else 
    {
        int e = convertDec % 2;//remainder of input number
        string s = e == 0 ? "0" : "1";//hold 0 IF e is zero, question mark is syntactic sugar. Hold 1 if e is not zero, the condition is false
        return decimalToBinaryRecursive(convertDec/2) + s;//recursive call of function
    }
}

int main()
{
//test 1
//expected output:1011 because thats the binary of 11
int convertDec=11;
string result=decimalToBinaryRecursive(convertDec);
cout<<"Got: "<<result<<endl;

//test 2
//expected output:101100 because thats the binary of 44
int convertDec2=44;
string result2=decimalToBinaryRecursive(convertDec2);
cout<<"Got: "<<result2<<endl;
}