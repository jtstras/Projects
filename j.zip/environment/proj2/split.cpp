// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 4 - Problem 6

#include <iostream>
#include <string>
using namespace std;

/**
* This function splits the input string into pieces seperated by the delimiter, and then takes the pieces and 
* inserts them into an array up to the number of split pieces
* 
* 1.while the string at index i
* if the index at i equals the delimiter ot the index at i is the end of the string
* then if the reset variable is not equal to i
*    then if counter is equal to the size of the array, return -1 because the array cannot be smaller than the number of substrings
*    if not at counter index of words insert the substring of split at reset and reset minus i
* set reset equal to i plus 1
* return count
*
 *Input parameters:string for the variable to be split, delimiter must be a char, the array must be a string type, the size of array must be int
 * Output:nothing
 * Returns:number of pieces string was split into
 */ 

int split(string split, char delimiter, string words[], int size)
{
int count=0,i=0,reset=0;//declaring three variables we will use all integers

while(i<=split.length()) //loops through the string
{
    if(split[i]==delimiter||split[i]=='\0') //if split at index i or split at i is end of the string
    {
        if(reset!=i) //if start is not equal to i then
        {
            if(count==size)//if count equal to size of array then
            {
            return -1; //returns -1
            }
        words[count++] = split.substr(reset,i-reset); //adds the substring into words array and increments the count by 1
        }
      reset = i+ 1; //assigns i+1 to reset
     }
    i++; //increments i by 1
}
    return count; //returns the count
}

int main ()
{
  //test 1
  //arguments:split=testcase, delimter=seperator, words=array1,size=3
  //expected output:3
  //explanation:string was split into three pieces
 string testcase = " big donkey boyz ";
 char separator = ' ';
 string array1[3];
 int test1 = split(testcase, separator, array1, sizeof(array1)/sizeof(string));
 for (int i=0 ; i < 10 && i < test1 ; i++)
   cout << "array1["<< i << "]:" << array1[i] << endl;
   cout << "Function returned value: " << test1 << endl;
   
   
//test 2
//arguments:split=testcase2, delimiter=seperator2, words=array2, size=7
//expected output:7
//explanation:seven pieces should be split from testcase
 string testcase2 = "I$WILL$FUNNY$BUNNY$ALL$OF$YOU";
 char separator2 = '$';
 string array2[7];
 int test2 = split(testcase2, separator2, array2, sizeof(array2)/sizeof(string));
 for (int i=0 ; i < 10 && i < test2 ; i++)
   cout << "array2["<< i << "]:" << array2[i] << endl;
   cout << "Function returned value: " << test2 << endl;
}

