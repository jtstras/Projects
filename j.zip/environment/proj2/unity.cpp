#include <iostream>
using namespace std;
#include <string>
#include <fstream>
#include <cmath>

//THIS IS WHERE I RAN TEST CASES ONE AT A TIME IN THE MAIN, I DELEDTED MOST OF THEM SO I COULD RUN ONE AT A TIME

//This is the header file for the Book class, check Book.cpp for comments on what these member functions do

class Book
{
    private://Data members
    string title;
    string author;
    
    public://Declaring all the member functions
    Book();
    Book(string titleInput, string authorInput);
    string getTitle();
    void setTitle(string j);
    string getAuthor();
    void setAuthor(string inputString);
};

//These are the Member functions for class "Book" per the specifications provided

Book::Book()//Default Constructor:title and string empty
{
    title="";
    author="";
}

Book::Book(string titleInput, string authorInput)//Parameterized Constructor:intializes title and author with inputs
{
    title=titleInput;
    author=authorInput;
}

string Book::getTitle()//Returns the title of book
{
  return title;
}

void Book::setTitle(string j)//Sets the title of book to input
{
    title=j;
}

string Book::getAuthor()//Returns author
{
    return author;
}

void Book::setAuthor(string inputString)//Sets author to input
{
    author=inputString;
}


class User
{
    private://Data members
    string username;
    int numRatings;
    int size;
   int ratings[50];
    
    public://Declaring all the member functions
    User();
    User(string s,int arr[], int i);
    string getUsername();
    void setUsername(string u);
    int getRatingAt(int index);
    bool setRatingAt(int index, int value);
    int getNumRatings();
    void setNumRatings(int j);
    int getSize();
};


User::User()//default constructor sets variables to default
{
    username="";
    numRatings=0;
    
    size=50;//size always 50
    ratings[size];
    for(int i=0;i<size;i++)
    {
    ratings[i]=0;//populating array with 0
    }
    
}

User::User(string s,int arr[], int i)//Parameterized Constructor that intializes variables with inputs
{
    username=s;
    for (int j=0;j<i;j++)
    {
     ratings[j]=arr[j];
    }
    if (i < 50)
    {
        int k=50-i;
        for (int m=0;m<k;m++)
        {
            ratings[0+i+m]=0;
        }
    }
    numRatings=i;
}

string User::getUsername()//grabs username
{
    return username;
}

void User::setUsername(string u)//sets username with input
{
    username=u;
}

int User::getRatingAt(int index)//grabs rating at index
{
    if (index >= 50 || index < 0)
    {
        return -1;
    }
    int holdRating;
    holdRating=ratings[index];
    return holdRating;
}

bool User::setRatingAt(int index, int value)//sets rating to value at the index
{
    if (index < 50 && value < 6 && value >= 0)
    {
    ratings[index]=value;
    return true;
    }
    else
    {
        return false;
    }
}

int User::getNumRatings()//grabs numRatings
{
    return numRatings;
}

void User::setNumRatings(int j)//sets numRatings
{
    numRatings=j;
}

int User::getSize()//grabs the size
{
    return size;
}


class Library
{
    private://Data members
    int sizeBook=50;
    int sizeUser=100;
    Book books[50];
    User users[100];
    int numBooks;
    int numUsers;
    
    public://Declaring all the member functions
    Library();
    int getSizeBook();
    int getSizeUser();
    int getNumBooks();
    int getNumUsers();
    int readBooks (string fileName);
    void printAllBooks();
    void printBooksByAuthor(string authorName);
    int readRatings(string fileName);
    int getRating(string username, string title);
    int getCountReadBooks(string username);
    void viewRatings(string username, int minRating);
    double calcAvgRating (string title);
    double calcAvgRatingByAuthor(string author);
    int addUser(string username);
    int checkOutBook(string username, string title, int newRating);
    void getRecommendations(string username);
};

Library::Library()
{
    numBooks=0;
    numUsers=0;
}

int Library::getSizeBook()
{
    return sizeBook;
}

int Library::getSizeUser()
{
    return sizeUser;
}

int Library::getNumBooks()
{
    return numBooks;
}

int Library::getNumUsers()
{
    return numUsers;
}

int split(string split, char delimiter, string words[], int size)
{
int count=0,i=0,reset=0;//declaring three variables we will use all integers

while(i<=split.length()) //loops through the string
{
    if(split[i]==delimiter||split[i]=='\0') //if split at index i or split at i is end of the string
    {
        if(reset!=i) //if start is not equal to i then
        {
            if(count==size)//if count equal to size of array then
            {
            return -1; //returns -1
            }
        words[count++] = split.substr(reset,i-reset); //adds the substring into words array and increments the count by 1
        }
      reset = i+ 1; //assigns i+1 to reset
     }
    i++; //increments i by 1
}
    return count; //returns the count
}

string to_lower(string s)//this helper function will convert a string to all lowercase characters
{
    
    string lowercase="";
    for (int i=0;i<s.length();i++)
    {
        lowercase += tolower(s[i]);//using tolower to lower upper to lower case characters
    }
     return lowercase;
    
}

int getUserIndex(User users[], int numUsers, string username)//helper function getIndex to grab index of users with username
{
   for (int i = 0; i < numUsers; i++)
   {
       int found = 1; // signifies true
       string currentuser = users[i].getUsername();//grabbing username

       if (username.size() == currentuser.size())//the the sizes of the string are equal
       {
           for (string::const_iterator j = username.begin(),  k = currentuser.begin(); j != username.end(); j++, k++)
           {//points to a character, j equals beginning of string, k equals beginning of current user. executes j until the end of username. const so cant modify container
               if (tolower(*j) != tolower(*k))//lowering the strings to lowercase also these are pointers
                //basically looping through both strings
               {
                   found = 0; // false - not found
                   break;//break loop
               }
           }
       }
       else
       {
           found = 0; // false - not found
       }

       if (found == 1)
       {
           return i;//returning the index
       }
   }

   return -1; // username is not found
}

int getBookIndex(Book books[], int numBooks, string title)
{
   for (int i = 0; i < numBooks; i++)
   {
       int found = 1; // signifies true
       string currentbook = books[i].getTitle();

       if (title.size() == currentbook.size())//if sizes are equal
       {
           for (string::const_iterator j = title.begin(), k = currentbook.begin(); j != title.end(); ++j,k++)
           {//points to a character, j equals beginning of string, k equals beginning of current book title. executes j until the end of title. const so cant modify container
            //basically looping through both strings
               if (tolower(*j) != tolower(*k))//if lowered strings are equal
               {
                   found = 0; // false - not found
                   break;//break loop
               }
           }
       }
       else
       {
           found = 0; // false - not found
       }

       if (found == 1)
       {
           return i;//hold index
       }
   }

   return -1; // book's title not found
} 


int Library::readBooks(string fileName)
{
ifstream myfile;//create an output file
myfile.open(fileName.c_str());//open the file with the file stream
string line;//line
string arr[2];//temp array
int j=numBooks;//another integer set to numBooks

if (j == sizeBook)//if number of books currently stored in array equals the size of the array
{
    return -2;
}

if (myfile.fail())//if the file fails to open
{
    return -1;
}

if(myfile.is_open())//if file is open
{
    while (getline(myfile,line))//loop through file
    {
    if (j == sizeBook)//zero case
    {
        return j;
    }
   else
   {
    if (line != "" )// if line is not empty
    {
       split (line, ',', arr , sizeBook);//split line using comma as delimiter and calling split function
        books[j].setAuthor(arr[0]);//set author member function to populate array with authors
        books[j].setTitle(arr[1]);//set title member function to populate array with titles
        j++;//increment j
        numBooks=j;//adding to numBooks
        arr[0]="";//reset temp arrays
        arr[1]="";
    }
    }
}
}
myfile.close();// closing the file
 
return j;//return statement
}

void Library::printAllBooks()
{
     if (numBooks <= 0)//if num of books is 0 or less
    {
        cout<<"No books are stored"<<endl;//output message
    }
    else
    {
        cout<<"Here is a list of books"<<endl;//output message
        for (int i=0;i < numBooks;i++)//as long as i is less than the number of books
        {
        cout << books[i].getTitle() << " by ";//output the title at index i using the member function get title
        cout << books[i].getAuthor() << endl;//output the author at index i using the member function get author
        }
    }
}

void::Library::printBooksByAuthor(string authorName)
{
    if (numBooks <= 0)//if array is empty
    {
        cout<<"No books are stored"<<endl;
    }
else
{
    int count=0;//declare counter variable
    
    for (int j=0;j<numBooks;j++)
    {
            if (books[j].getAuthor() == authorName)//loop through authors array to see if they match authors name
            {
            count++;//add 1 to counter
            }
    }
    if (count > 0)//if a single match for authors name
             {
            cout<<"Here is a list of books by"<<" "<<authorName<<endl;//output message
             }
    else if (count==0)//not match for authors name
             {
            cout<<"There are no books by "<<authorName<<endl;//output message
             }
}
for (int j=0;j<numBooks;j++)
             {
                 if (books[j].getAuthor() == authorName)//loop through array again grabbing author name's and see if equal to input
                 {
                  cout<<books[j].getTitle()<<endl;//output the books by the author
                 }
             }
}

int Library::readRatings(string fileName)
{
string word = "";//create a variable for words
int k=numUsers;//k equals num users
ifstream myfile;//output stream
myfile.open(fileName);//Open the text file

if (k >= sizeUser)//When numUsersStored is greater than or equal to the usersArrSize, return -2
{
    return -2;
}

if (myfile.is_open())
{
    while (getline(myfile, word) && k < sizeUser) //Read each line from the text file
    {
            if (word != "")//make sure line isnt empty
            {
              string array[51];//temp array
              int j=split(word, ',', array, 51);        //Split each line
              users[k].setUsername(array[0]);       //populating the Users array with the usernames from the temp array grabbed from txt file                                  
              for (int i = 1; i < j; i++)
              {
              users[k].setRatingAt((i-1),stoi(array[i])); //populating the Users array with the ratings from the temp array grabbed from txt file
                                                          //stoi converting string to int
              }                         
              k++;//add 1 to count
            
             }
             numUsers=k;//num users update till k
     }
      return k;//return count
}

else // if anything else will return -1.
{
                return -1;
}

}

int Library::getRating(string username, string title)
{
    string temp=to_lower(username);//temps to hold the lowered username and title
    string temp2=to_lower (title);
    int foundUser=0;
    int holdIndex=0;
    if (numBooks <= 0)//is there are no books
    {
        return -3;
    }
    for (int i=0;i<numUsers;i++)
    {
        if (to_lower(users[i].getUsername())==temp)//looping through the users array to check if the username is there and equal to username
        {
            foundUser++;//counter
            holdIndex=i;//grabbing that index
        }
    }
      int foundBook=0;
      int hold2=0;
      for (int j=0;j<numBooks;j++)
    {
        if (to_lower(books[j].getTitle())==temp2)//looping through the books array to check if the title is there
        {
            foundBook++;//counter
            hold2=j;//grabbing index
        }
    }
    if (foundUser > 0 && foundBook > 0)//if both the title and username exist
    {
        return users[holdIndex].getRatingAt(hold2);//return the rating at user index of username at get rating of the index of the title
    }
    else
    {
        return -3;//for other cases
    }
}

int Library::getCountReadBooks(string username)
{
int count=0;//all the counter variables
int holdIndex=0;
int testCaseCount=0;
string temp1=to_lower(username);//lowering the string
if (numBooks==0)//if there are no books
{
    return -3;
}

for (int i=0;i<numUsers;i++)
{
    if (to_lower(users[i].getUsername())==temp1)//lower case version of get username compared to username
    {
        holdIndex=i;//hold that index
        testCaseCount++;//for if the username does not exist
    }
   
}

if (testCaseCount==0)//if username does not exist
{
    return -3;
}
        
for (int j=0;j<numBooks;j++)//iterate as many times as num books
{
        if (users[holdIndex].getRatingAt(j) > 0)//if the rating at the held index of users is greater than zero
            {
                 count++;//add 1 to count
            }
        
}
        return count;
}

void Library::viewRatings(string username, int minRating)
{
int index = getUserIndex(users, numUsers, username);//helper function

    if (index == -1)//user not found
   {
       cout << username << " does not exist." << endl;
       return;
   }
   int count=0;
   for (int i = 0; i < numBooks; i++)
   {
       if (users[index].getRatingAt(i) >= minRating)//if the rating is greater than zero
       {
           count++;
       }
   }
   if (count==0)
   {
       cout<<username<<" has not rated any books yet."<<endl;
   }
     else if (count > 0)
   {
       cout<<"Here are the books that "<<username<<" rated"<<endl;
   }
   for (int i = 0; i < numBooks; i++)
   {
       if (users[index].getRatingAt(i) >= minRating)//if the rating is greater than zero
       {
           cout << "Title : "<<books[i].getTitle() <<endl;
           cout << "Rating : "<<users[index].getRatingAt(i) << endl;
           cout<<"-----"<<endl;
       }
   }
}

double Library::calcAvgRating (string title)
{
    if (numUsers==0)//if no users exist
    return -3;
    int holdIndex=-1;
    string temp1=to_lower(title);//lowering the case of title
    
    for (int i=0;i<numBooks;i++)
    {
    if (to_lower(books[i].getTitle())==temp1)//lower case version of get username compared to username
    {
        holdIndex=i;//hold that index
    }
    }
    if (holdIndex==-1)//if the book title does not exist
        return -3;
    
    double sum=0;
    double count2=0;
    for (int j=0;j<numUsers;j++)//loop through
    {
        sum=users[j].getRatingAt(holdIndex)+sum;//sum equals users at j index and grab rating at heldindex
        if(users[j].getRatingAt(holdIndex) > 0)//if rating is greater than 0
        {
            count2++;//add to count
        }
    }
    if (count2==0)//book has not been read by anyone
        return 0;//return 0
        
    return sum/count2;
}

double Library::calcAvgRatingByAuthor(string author)
{
     //holdIndex=i;//hold that index
    if (numUsers==0)//if no users exist
    return -3;
    int holdIndex=-1;
    string temp1=to_lower(author);//lowering the case of title  
    double sum=0;
    double count2=0;
    
     for (int i=0;i<numBooks;i++)
    {
    if (to_lower(books[i].getAuthor())==temp1)//lower case version of get username compared to username
    {
        holdIndex=i;//hold that index
    }
    }
    if (holdIndex==-1)//if the book title does not exist
        return -3;
    
    for (int i=0;i<numBooks;i++)
    {
    if (to_lower(books[i].getAuthor())==temp1)//lower case version of get username compared to username
    {
        for (int j=0;j<numUsers;j++)//loop through
        {
        sum=users[j].getRatingAt(i)+sum;//sum equals users at j index and grab rating at heldindex
        if(users[j].getRatingAt(i) > 0)//if rating is greater than 0
        {
            count2++;//add to count
        }
        if (count2==0)//book has not been read by anyone
        return 0;//return 0
        }
    }
    }
     return sum/count2;
}

int Library::addUser(string username)
{
    string temp4=to_lower(username);
    if (numUsers == sizeUser)
       return -2; // the users array is already full
    int index = getUserIndex(users, numUsers,temp4 );
   if (index != -1)
       return 0; // username is already existed

   User userobj1;
   userobj1.setUsername(temp4);

   users[numUsers] = userobj1;
   numUsers++;

   return 0; // user is successfully added
} // end of addUser function

int Library::checkOutBook(string username, string title, int newRating)
{
    string temp6=to_lower (username);
    string temp7=to_lower (title);
   if (newRating < 0 || newRating > 5)
       return -4; // rating value is not valid

   int userIndex = getUserIndex(users, numUsers, temp6);
   int bookIndex = getBookIndex(books, numBooks, temp7);

   if (userIndex == -1 || bookIndex == -1)
       return -3; // user or title not exist in the database

   users[userIndex].setRatingAt(bookIndex, newRating);

   return 1; // rating is succeffully added
}

void Library::getRecommendations(string username)
{
    int userInd = getUserIndex(users, numUsers, username);//call helper function to grad user index containig username

   if (userInd == -1)
   {
       cout << username << " does not exist." << endl;
       return; //end 
   }

   int SSDScore=0;
   int bookCount=0;
   int minSSDScore=1000;
   int minSSDIndex=0;
   int tempbooks[5];

 
   for (int i = 0;i < numUsers;i++)
   {
       if (getCountReadBooks(users[i].getUsername())==0||i==userInd)
       {
           continue;
       }
        for(int z=0;z<numBooks;z++)   
        {
            SSDScore += pow(users[userInd].getRatingAt(z) - users[i].getRatingAt(z), 2);
        }
        if (SSDScore < minSSDScore)
        {
            minSSDScore=SSDScore;
            minSSDIndex=i;
        }
        SSDScore=0;
        i++;
   }
    for(int a=0;a<numBooks;a++)
    {
        if(users[userInd].getRatingAt(a)==0 && users[minSSDIndex].getRatingAt(a)> 2 && bookCount<5)
        {
            tempbooks[bookCount]=a;
            bookCount++;
        }
    }
    if (bookCount>0)
    {
        cout<<"Here is the list of recommendations"<<endl;
        int y=0;
        for (int y=0;y<bookCount;y++)
        {
            cout<<books[tempbooks[y]].getTitle()<<" by "<<books[tempbooks[y]].getAuthor()<<endl;
        }
    }
    else
    {
        cout<<"There are no recommendations for "<<username<<" at present."<<endl;
    }
    
}

int main()
{
Library l28 = Library();
int numBooks = l28.readBooks("books.txt");
int numUsers = l28.readRatings("ratings.txt");
l28.getRecommendations("gregory");

}