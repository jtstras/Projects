#include <iostream>
#include "Library.cpp"
using namespace std;

int main()
{
Library l;
cout << "numBooks = " << l.getNumBooks() << endl;
cout << "numUsers = " << l.getNumUsers() << endl;
cout << "book arr size = " << l.getSizeBook() << endl;
cout << "user arr size = " << l.getSizeUser() << endl;

Library l4 = Library();
int numUsers = l4.readRatings("books.txt");
cout << "readRatings returned: " << numUsers << endl;
cout << "numUsers = " << l4.getNumUsers() << endl;

//20 books txt to library 
/*
Library j = Library();
int numBooks = j.readBooks("books.txt");
cout << "readBooks returned: " << numBooks << endl;
cout << "numBooks = " << j.getNumBooks() << endl; 

Library l29 = Library();
int numBooks = l29.readBooks("books.txt");
int numUsers = l29.readRatings("ratings.txt");
cout << l29.getRating("adam", "The Five People You Meet in Heaven");
*/

}