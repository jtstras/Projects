#include <iostream>
#include "User.h"
#include "Book.h"
using namespace std;

//This is the header file for the Library class, check Library.cpp for comments on what these member functions do

class Library
{
    private://Data members
    int sizeBook=50;
    int sizeUser=100;
    Book books[50];
    User users[100];
    int numBooks;
    int numUsers;
    
    public://Declaring all the member functions
    Library();
    int getSizeBook();
    int getSizeUser();
    int getNumBooks();
    int getNumUsers();
    int readBooks (string fileName);
    void printAllBooks();
    void printBooksByAuthor(string authorName);
    int readRatings(string fileName);
    int getRating(string username, string title);
    int getCountReadBooks(string username);
    void viewRatings(string username, int minRating);
    double calcAvgRating (string title);
    double calcAvgRatingByAuthor(string author);
    int addUser(string username);
    int checkOutBook(string username, string title, int newRating);
    void getRecommendations(string username);
};