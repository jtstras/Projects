// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Proj 2 - Problem 2

#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include "Library.h"
using namespace std;

int displayMenu(){//menu provided
    cout << "Select a numerical option:" << endl;
    cout << "======Main Menu=====" << endl;
    cout << "1. Read books" << endl;
    cout << "2. Read ratings" << endl;
    cout << "3. Print all books" << endl;
    cout << "4. Print books by author" << endl;
    cout << "5. Get rating" << endl;
    cout << "6. Find number of books user rated" << endl;
    cout << "7. View ratings" << endl;
    cout << "8. Get average rating" << endl;
    cout << "9. Get average rating by author" << endl;
    cout << "10. Add a user" << endl;
    cout << "11. Checkout a book" << endl;
    cout << "12. Get recommendations" << endl;
    cout << "13. Quit" << endl;
    int number;
    cin>>number;
    return number;//returning user choice
}

int main()
{
       int intTest;//This is making sure database is intialized
       int count1;//making sure quit option works correctly
        Library jt=Library();//creating class object
     int userChoice=displayMenu();//call what was returned from print menu function
         if (userChoice==13)//quit option in case user immediately quits
        {
            cout<<"Good bye!"<<endl;
            count1++;
        }
    while (userChoice != 13)//while user choice does not equal 4
{
      if (userChoice > 13 || userChoice < 1) //if the input is invalid
    {
            cout<<"Invalid input."<<endl<<"\n";//output message
            userChoice=displayMenu();
    }
    if (userChoice==1)//user choice equals 1
     {
        string fileName = "";//string empty
        cout<<"Enter a book file name:"<<endl;
        cin>>fileName;//input into string
        int comparevalue=jt.readBooks(fileName);//call readbooks and store the result 
        if (comparevalue == -1)//if function returns -1
        {
            cout<<"No books saved to the database."<<endl<<"\n";
            intTest++;
        }
        else if (comparevalue == -2)//readbooks called equals -2 or 50
        {
            cout<<"Database is already full. No books were added."<<endl<<"\n";
            intTest++;
        }
        else if (comparevalue == 50)
        {
            cout<<"Database is full. Some books may have not been added."<<endl<<"\n";
            intTest++;
        }
        else if ((comparevalue !=-1) && comparevalue !=-2 && comparevalue != 50)//if numBookStored isnt any of the above numbers
        {
            cout<<"Total books in the database: "<<comparevalue<<endl<<"\n";
            intTest++;
        }
        userChoice=displayMenu();//print menu function
     }
    if  (userChoice==2)
     {
       string fileName2;
       cout<<"Enter a user file name:"<<endl;
       cin>>fileName2;
       int valuecompare=jt.readRatings(fileName2);//calling read ratings
       if (valuecompare==-1)
       {
           cout<<"No users saved to the database."<<endl<<"\n";
            intTest++;
       }
        if (valuecompare==-2)
       {
           cout<<"Database is already full. No users were added."<<endl<<"\n";
            intTest++;
       }
       if (valuecompare==100)
       {
           cout<<"Database is full. Some users may have not been added."<<endl<<"\n";
            intTest++;
       }
       else if (valuecompare != -1 && valuecompare != -2 && valuecompare != 100)
       {
           cout<<"Total users in the database: "<<valuecompare<<endl<<"\n";
            intTest++;
       }
       userChoice=displayMenu();//print menu function
     }
        if (userChoice==3)
     {
        if (intTest < 2)
        {
            cout<<"Database has not been fully initialized."<<endl<<"\n";
             
        }
        else
        {
            jt.printAllBooks();//calling print all books
            cout<<"\n";
        }
         userChoice=displayMenu();//Print Menu functiom
        }
     
     if (userChoice==4)
     {
          if (intTest < 2)
        {
            cout<<"Database has not been fully initialized."<<endl<<"\n";
        }
        else
        {
         string authorName;
         cout<<"Enter an author name:"<<endl;
           cin.ignore();
        getline(cin, authorName, '\n');
    
         jt.printBooksByAuthor(authorName);//calling printbooks by author
          cout<<"\n";
        }
        userChoice=displayMenu();//Print Menu functiom
     }
     if (userChoice==5)
     {
          string username;string title;
             if (intTest < 2)
        {
            cout<<"Database has not been fully initialized."<<endl<<"\n";
        }
        else
        {
             cout<<"Enter a user name:"<<endl;
              cin.ignore();
        getline(cin, username, '\n');
             cout<<"Enter a book title:"<<endl;
              cin.ignore();
        getline(cin, title, '\n');
             int compares=jt.getRating(username, title);//calling getRating
             if (compares==0)
             {
                 cout<<username<<" has not rated "<<title<<endl<<"\n";
             }
             if (compares==-3)
             {
                 cout<<username<<" or "<<title<<" does not exist."<<endl<<"\n";
             }
             else
             {
                 cout<<username<<" rated "<<title<<" with "<<compares<<endl<<"\n";
             }
        }
          userChoice=displayMenu();//Print Menu functiom
     }
     if (userChoice==6)
     {
         string username2;
        if (intTest < 2)
        {
            cout<<"Database has not been fully initialized."<<endl<<"\n";
             
        }
        else
        {
             cout<<"Enter a user name:"<<endl;
             cin.ignore();
        getline(cin, username2, '\n');
            int values=jt.getCountReadBooks(username2);//calling getCountReadBooks
            if (values==0)
            {
                cout<<username2<<" has not rated any books."<<endl<<"\n";
            }
            if (values==-3)
            {
                cout<<username2<<" does not exist."<<endl<<"\n";
            }
            else if (values != 3 && values != 0)
            {
                cout<<username2<<" rated "<<values<<" books."<<endl<<"\n";
            }
        }
        userChoice=displayMenu();//Print Menu functiom
     }
     if (userChoice==7)
     {
            string username3;int minRating;
           if (intTest < 2)
        {
            cout<<"Database has not been fully initialized."<<endl<<"\n";
        }
        else
        {
            cout<<"Enter a user name:"<<endl;
             cin.ignore();
        getline(cin, username3, '\n');
             cout<<"Enter a minimum rating:"<<endl;
             cin>>minRating;
             jt.viewRatings(username3, minRating);//calling viewRatings
             cout<<"\n";
        }
        userChoice=displayMenu();//Print Menu functiom
     }
     if (userChoice==8)
     {
             string title;
             if (intTest < 2)
        {
            cout<<"Database has not been fully initialized."<<endl<<"\n";
        }
        else
        {
            cout<<"Enter a book title:"<<endl;
            cin.ignore();
        getline(cin, title, '\n');
             double valuecar=jt.calcAvgRating(title);//calling calcAvgRating
             if (valuecar==-3)
             {
                 cout<<title<<" does not exist."<<endl<<"\n";
             }
             else
             {
                 cout<<"The average rating for "<<title<<" is "<<valuecar<<endl<<"\n";
             }
        }
        userChoice=displayMenu();//Print Menu functiom
     }
     if (userChoice==9)
     {
           string author;
               if (intTest < 2)
        {
            cout<<"Database has not been fully initialized."<<endl<<"\n";
        }
        else
        {
            cout<<"Enter an author name:"<<endl;
       cin.ignore();
        getline(cin, author, '\n');
            double jackie=jt.calcAvgRatingByAuthor(author);//calling CalcAvgRatingByAuthor
            if (jackie=-3)
            {
                  cout<<author<<" does not exist."<<endl<<"\n";
            }
            else
            {
                cout<<"The average rating for"<<author<<" is "<<jackie<<endl<<"\n";
            }
        }
        userChoice=displayMenu();//Print Menu functiom
     }
     string username4;
     if (userChoice==10)
     {
            cout<<"Enter a user name:"<<endl;
            cin.ignore();
        getline(cin, username4, '\n');
             int myvalue=jt.addUser(username4);//calling addUser
             if (myvalue==1)
             {
                 cout<<"Welcome to the library "<<username4<<endl<<"\n";
                  intTest++;
             }
             if (myvalue==0)
             {
                 cout<<username4<<" already exists in the database."<<endl<<"\n";
                    intTest++;
             }
             if (myvalue==-2)
             {
                 cout<<"Database is already full. "<<username4<< " was not added."<<endl<<"\n";

             }
             userChoice=displayMenu();//Print Menu functiom
    }
    
     if (userChoice==11)
     {
              string username11;string title11;int newRating;
               if (intTest < 2)
        {
            cout<<"Database has not been fully initialized."<<endl<<"\n";
        }
        else
        {
            cout<<"Enter a user name:"<<endl;
             cin.ignore();
        getline(cin, username11, '\n');
             cout<<"Enter a book title:"<<endl;
             cin.ignore();
        getline(cin, title11, '\n');
             cout<<"Enter a new rating:"<<endl;
             cin>>newRating;
             int devalue=jt.checkOutBook(username11,title11,newRating);//calling checkOutBook
             if (devalue==1)
             {
                 cout<<"We hope you enjoyed your book. The rating has been updated."<<endl<<"\n";
             }
             if (devalue==-4)
             {
                 cout<<newRating<<" is not valid."<<endl<<"\n";
             }
             if (devalue==-3)
             {
                 cout<<username11<<" or "<<title11<<" does not exist."<<endl<<"\n";
             }
             
        }
        userChoice=displayMenu();//Print Menu functiom
     }
     string username55;
     if (userChoice==12)
     {
           if (intTest < 2)
        {
            cout<<"Database has not been fully initialized."<<endl<<"\n";
        }
        else
        {
            cout<<"Enter a user name:"<<endl;
             cin.ignore();
        getline(cin, username55, '\n');
             jt.getRecommendations(username55);//calling getRecommendations 
              cout<<"\n";
        }
         userChoice=displayMenu();//Print Menu functiom
     }
      if (userChoice==13 && count1 != 1)//quit option in case user immediately quits
        {
            cout<<"Good bye!"<<endl;
        }
    
}
}

