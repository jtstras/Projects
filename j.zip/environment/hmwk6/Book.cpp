// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 6 - Problem 3

#include <iostream>
#include <string>
#include <fstream>
#include "Book.h"
using namespace std;

//These are the Member functions for class "Book" per the specifications provided

Book::Book()//Default Constructor:title and string empty
{
    title="";
    author="";
}

Book::Book(string titleInput, string authorInput)//Parameterized Constructor:intializes title and author with inputs
{
    title=titleInput;
    author=authorInput;
}

string Book::getTitle()//Returns the title of book
{
    return title;
}

void Book::setTitle(string j)//Sets the title of book to input
{
    title=j;
}

string Book::getAuthor()//Returns author
{
    return author;
}

void Book::setAuthor(string inputString)//Sets author to input
{
    author=inputString;
}