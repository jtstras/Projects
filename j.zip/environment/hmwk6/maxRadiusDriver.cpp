// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 6 - Problem 2

#include <iostream>
#include <string>
#include <fstream>
#include "Planet.cpp"
#include <cmath>
using namespace std;

/**
* This function finds the planet with the largest radius in a class object array using the object class Planet
* 
* 1.if there are zero or less elements in array, return -1
* 2.for loop, as long as i is less than the number of elements in array
*   if the radius of the planet at index i of the the array is greater than the maximum radius (default zero)
*   the maximum radius equals that number and the index containing the planet with maximum radius is i
* 3.return that index
*
 *Input parameters:Planet class array, int for number of elements
 * Output:nothing
 * Returns:index with the planet with largest radius
 */ 


int maxRadius (Planet arrPlanet[], int elements)
{
    if (elements <= 0)//if zero or less elements
    {
        return -1;
    }
    double maximumRadius=0;//holder of max radius
    int indexmaxRadius=0;//index containing the max radius
    for (int i=0;i<elements;i++)//while i is less than elemtns
    {
        if (arrPlanet[i].getRadius() > maximumRadius)//if the radius at i is greater than the max radius
        {
            maximumRadius=arrPlanet[i].getRadius();//set max radius to that value
            indexmaxRadius=i;//hold the index with the max radius
        }
    }
    return indexmaxRadius;//return statement
    
}

int main()
{
    //test 1
    //expected output FUN TIMES WORLD because it has the largest radius, Radius should be 66, Volume should be 287496
    Planet planets[5];
    planets[0] = Planet("COOOL WORLD",12);
    planets[1] = Planet("FUN TIMES WORLD",66);
    int idx = maxRadius(planets, 2);
    cout << planets[idx].getName() << endl;
    cout << planets[idx].getRadius() << endl;
    cout << planets[idx].getVolume() << endl;
    
    //test 2
    //expected output FAST WORLD because it has the largest radius, Radius should be 4545, Volume should be 9.38862e^10
    Planet planets2[2];
    planets2[0] = Planet("DASH WORLD",2200);
    planets2[1] = Planet("FAST WORLD",4545);
    planets2[2] = Planet("LIT FUN WORLD",1322);
    int idx2 = maxRadius(planets2, 3);
    cout << planets2[idx].getName() << endl;
    cout << planets2[idx].getRadius() << endl;
    cout << planets2[idx].getVolume() << endl;
}