// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 6 - Problem 7

#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
using namespace std;

//This is the header file for the Book class, check Book.cpp for comments on what these member functions do

class Book
{
    private://Data members
    string title;
    string author;
    
    public://Declaring all the member functions
    Book();
    Book(string titleInput, string authorInput);
    string getTitle();
    void setTitle(string j);
    string getAuthor();
    void setAuthor(string inputString);
};

//These are the Member functions for class "Book" per the specifications provided

Book::Book()//Default Constructor:title and string empty
{
    title="";
    author="";
}

Book::Book(string titleInput, string authorInput)//Parameterized Constructor:intializes title and author with inputs
{
    title=titleInput;
    author=authorInput;
}

string Book::getTitle()//Returns the title of book
{
    return title;
}

void Book::setTitle(string j)//Sets the title of book to input
{
    title=j;
}

string Book::getAuthor()//Returns author
{
    return author;
}

void Book::setAuthor(string inputString)//Sets author to input
{
    author=inputString;
}

//This is the print menu function provided by CU Boulder Faculty

int printMenu(){
    cout << "======Main Menu=====" << endl;
    cout << "1. Read books" << endl;
    cout << "2. Print all books" << endl;
    cout << "3. Print books by author" << endl;
    cout << "4. Quit" << endl;
    int number;
    cin>>number;
    return number;//returning the user choice to main
}

/**
* This function splits the input string into pieces seperated by the delimiter, and then takes the pieces and 
* inserts them into an array up to the number of split pieces
* 
* 1.while the string at index i
* if the index at i equals the delimiter ot the index at i is the end of the string
* then if the reset variable is not equal to i
*    then if counter is equal to the size of the array, return -1 because the array cannot be smaller than the number of substrings
*    if not at counter index of words insert the substring of split at reset and reset minus i
* set reset equal to i plus 1
* return count
*
 *Input parameters:string for the variable to be split, delimiter must be a char, the array must be a string type, the size of array must be int
 * Output:nothing
 * Returns:number of pieces string was split into
 */ 

int split(string split, char delimiter, string words[], int size)
{
int count=0,i=0,reset=0;//declaring three variables we will use all integers

while(i<=split.length()) //loops through the string
{
    if(split[i]==delimiter||split[i]=='\0') //if split at index i or split at i is end of the string
    {
        if(reset!=i) //if start is not equal to i then
        {
            if(count==size)//if count equal to size of array then
            {
            return -1; //returns -1
            }
        words[count++] = split.substr(reset,i-reset); //adds the substring into words array and increments the count by 1
        }
      reset = i+ 1; //assigns i+1 to reset
     }
    i++; //increments i by 1
}
    return count; //returns the count
}

/**
* This function populates a pair of arrays with the titles and authors found in an txt file
* 1. open file
* 2. if file fails to open return negative one
* 3. if number of books stored equals the size of the array return negative two
* 4. if file is open
*   while looping through file and grabbing each line
*       if the line isn't empty
*           split the line by calling the split function
*           populate each cell of class object array with each author and book
*           add 1 to j
*           num of book stored equals j
*           reset the temp arrays
* 5. close file
* 6. return number of books added
*
 *Input parameters:string for titles array, string for authors array,  integer for length of arrays
 * Output:each book and its author
 * Returns:nothing
 */ 

int readBooks (string fileName, Book books[],int numBookStored, int booksArrSize=50)
{
ifstream myfile;//create an output file
myfile.open(fileName.c_str());//open the file with the file stream
string line;//line
string arr[2];//temp array
int j=numBookStored;//another integer set to numBookStored

if (numBookStored == booksArrSize)//if number of books currently stored in array equals the size of the array
{
    return -2;
}

if (myfile.fail())//if the file fails to open
{
    return -1;
}

if(myfile.is_open())//if file is open
{
    while (getline(myfile,line))//loop through file
    {
    if (numBookStored == booksArrSize)//zero case
    {
        return numBookStored;
    }
   else
   {
    if (line != "" )// if line is not empty
    {
       split (line, ',', arr , booksArrSize);//split line using comma as delimiter and calling split function
        books[j].setAuthor(arr[0]);//set author member function to populate array with authors
        books[j].setTitle(arr[1]);//set title member function to populate array with titles
        j++;//increment j
        numBookStored=j;//adding to numBookStored
        arr[0]="";//reset temp arrays
        arr[1]="";
    }
    }
}
}
myfile.close();// closing the file
 
return numBookStored;//return statement
}

/**
* This function will print all the books in a "book" class object array
* 
* 1.if there are zero or less elements in array, output that there are no books
* 2.else output the list od books using get title and get author member functions
*
 *Input parameters:Planet class array, int for number of elements
 * Output:nothing
 * Returns:index with the planet with largest radius
 */ 

void printAllBooks(Book arr[], int numBooks)
{
    if (numBooks <= 0)//if num of books is 0 or less
    {
        cout<<"No books are stored"<<endl;//output message
    }
    else
    {
         cout<<"Here is a list of books"<<endl;//output message
        for (int i=0;i < numBooks;i++)//as long as i is less than the number of books
        {
        cout << arr[i].getTitle() << " by ";//output the title at index i using the member function get title
        cout << arr[i].getAuthor() << endl;//output the author at index i using the member function get author
        }
    }
}

/**
* This function will print all the books matching the name of an author in a "book" class object array
* 
* 1.if there are zero or less elements in array, output that there are no books
* 2.else loop through the array and see if the input matches the author in each cell
*   if match add 1 to count
* 3.if count is greater than zero output message
* else output that no matches exist
* 4.loop through the array again and output the titles by an author that matches the author inputted
*
 *Input parameters:Planet class array, int for number of elements, string for the author name
 * Output:nothing
 * Returns:index with the planet with largest radius
 */ 


void printBooksByAuthor (Book arr[], int numBooks, string authorName)
{
if (numBooks <= 0)//if array is empty
    {
        cout<<"No books are stored"<<endl;
    }
else
{
    int count=0;//declare counter variable
    
    for (int j=0;j<numBooks;j++)
    {
            if (arr[j].getAuthor() == authorName)//loop through authors array to see if match authors name
            {
            count++;//add 1 to counter
            }
    }
    if (count > 0)//if a single match for authors name
             {
            cout<<"Here is a list of books by"<<" "<<authorName<<endl;//output message
             }
    else if (count==0)//not match for authors name
             {
            cout<<"There are no books by "<<authorName<<endl;//output message
             }
}
for (int j=0;j<numBooks;j++)
             {
                 if (arr[j].getAuthor() == authorName)//loop through array again grabbing author name's and see if equal to input
                 {
                  cout<<arr[j].getTitle()<<endl;//output the books by the author
                 }
             }
}


}