#include <iostream>
using namespace std;

//Header file for Planet class, check Planet.cpp for comments on what these member functions do

class Planet
{
    private://Data members
    string planetName;
    double planetRadius;
    
    public://Declaring all the member functions
    Planet();
    Planet(string planetName, double planetRadius);
    string getName();
    void setName(string j);
    double getRadius();
    void setRadius(double input);
    double getVolume();
};
