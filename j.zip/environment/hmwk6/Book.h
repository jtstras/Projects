#include <iostream>
using namespace std;

//This is the header file for the Book class, check Book.cpp for comments on what these member functions do

class Book
{
    private://Data members
    string title;
    string author;
    
    public://Declaring all the member functions
    Book();
    Book(string titleInput, string authorInput);
    string getTitle();
    void setTitle(string j);
    string getAuthor();
    void setAuthor(string inputString);
};