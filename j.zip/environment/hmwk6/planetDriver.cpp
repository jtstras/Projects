#include <iostream>
#include "Planet.cpp"
using namespace std;

//Test Cases for the Member Functions of Prob 1

int main()
{
   Planet neptune=Planet();//class object Neptune set to default constructor
   
   string neptune_name=neptune.getName();//gettting defualt name and radius
   double neptune_radius=neptune.getRadius();
   if (neptune_name == "")//if name is blank default constructor worked
   {
      cout<<"Good stuff"<<endl;
   }
   if (neptune_radius == 0.0)//if radius is blank defualt constructor worked
   {
      cout<<"Good stuff"<<endl;
   }
  
   
    string s="Jerry World";double num=15.0;
    neptune=Planet(s,num);//testing parametized constructor
    neptune_name=neptune.getName();//grabbing the name and radius
    neptune_radius=neptune.getRadius();
   if (neptune_name == "Jerry World")//making sure the name is correct
   {
      cout<<"Good stuff"<<endl;
   }
   if (neptune_radius == 15.0)//making sure radius is correct
   {
      cout<<"Good stuff"<<endl;
   }
  
   
    neptune.setName("Facts World");//Here we are testing the setter member functions
    neptune.setRadius(18.0);
    
   cout<<"name:"<<neptune.getName()<<endl;//Testing the getter memeber functions Expected="name:Facts World"
   cout<<"radius:"<<neptune.getRadius()<<endl;//expected radius:18
   cout<<"volume:"<<neptune.getVolume()<<endl;//expected volume:5832
   
}