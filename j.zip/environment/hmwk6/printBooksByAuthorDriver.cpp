// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 6 - Problem 6

#include <iostream>
#include <string>
#include <fstream>
#include "Book.cpp"
#include <cmath>
using namespace std;

/**
* This function will print all the books matching the name of an author in a "book" class object array
* 
* 1.if there are zero or less elements in array, output that there are no books
* 2.else loop through the array and see if the input matches the author in each cell
*   if match add 1 to count
* 3.if count is greater than zero output message
* else output that no matches exist
* 4.loop through the array again and output the titles by an author that matches the author inputted
*
 *Input parameters:Planet class array, int for number of elements, string for the author name
 * Output:nothing
 * Returns:index with the planet with largest radius
 */ 


void printBooksByAuthor (Book arr[], int numBooks, string authorName)
{
if (numBooks <= 0)//if array is empty
    {
        cout<<"No books are stored"<<endl;
    }
else
{
    int count=0;//declare counter variable
    
    for (int j=0;j<numBooks;j++)
    {
            if (arr[j].getAuthor() == authorName)//loop through authors array to see if match authors name
            {
            count++;//add 1 to counter
            }
    }
    if (count > 0)//if a single match for authors name
             {
            cout<<"Here is a list of books by"<<" "<<authorName<<endl;//output message
             }
    else if (count==0)//not match for authors name
             {
            cout<<"There are no books by "<<authorName<<endl;//output message
             }
}
for (int j=0;j<numBooks;j++)
             {
                 if (arr[j].getAuthor() == authorName)//loop through array again grabbing author name's and see if equal to input
                 {
                  cout<<arr[j].getTitle()<<endl;//output the books by the author
                 }
             }
}

int main()
{
//test 1
//expected output:"There are no books by JK Rowling" 
Book auth1 = Book("FUNNY MAN", "POLAR BEAR");
Book auth2 = Book("HAPPY TIMES GONE", "STRING CHEESE HUMAN");
Book auth3 = Book("QUEEN BEE", "JIMMY NEUTRON");
Book listOfBooks[] = {auth1, auth2, auth3};
int numberOfBooks = 3;
string authorName = "JK Rowling";
printBooksByAuthor(listOfBooks, numberOfBooks, authorName);

//test 2
//expected output:Here is a list of books by STRING CHEESE HUMAN (all the books in array)
Book auth12 = Book("FUNNY MAN", "STRING CHEESE HUMAN");
Book auth22 = Book("HAPPY TIMES GONE", "STRING CHEESE HUMAN");
Book auth32 = Book("QUEEN BEE", "STRING CHEESE HUMAN");
Book listOfBooks2[] = {auth12, auth22, auth32};
int numberOfBooks2 = 3;
string authorName2 = "STRING CHEESE HUMAN";
printBooksByAuthor(listOfBooks2, numberOfBooks2, authorName2);


}
