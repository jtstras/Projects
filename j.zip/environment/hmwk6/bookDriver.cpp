#include "Book.cpp"
using namespace std;

//Test cases for the Member functions of the Book Class

int main()
{
    Book obj1=Book();//class object set to default constructor
   
   string obj1_title=obj1.getTitle();//gettting default title and author
   string obj1_author=obj1.getAuthor();
   if (obj1_title == "")//if title is blank default constructor worked
   {
      cout<<"Good stuff"<<endl;
   }
   if (obj1_author == "")//if author is blank defualt constructor worked
   {
      cout<<"Good stuff"<<endl;
   }
   
    string titleInput="Narnia";string authorInput="C Lewis";
    obj1=Book(titleInput,authorInput);//testing parametized constructor
    obj1_title=obj1.getTitle();//grabbing the title and author
    obj1_author=obj1.getAuthor();
   if (obj1_title == "Narnia")//making sure the title is correctt
   {
      cout<<"Good stuff"<<endl;
   }
   if (obj1_author == "C Lewis")//making sure author is correct
   {
      cout<<"Good stuff"<<endl;
   }
  
   
    obj1.setTitle("Eragon");//Here we are testing the setter member functions
    obj1.setAuthor("Jackie Daniels");
    
   cout<<"title:"<<obj1.getTitle()<<endl;//Testing the getter memeber functions Expected="name:Facts World"
   cout<<"author:"<<obj1.getAuthor()<<endl;//expected radius:18
   
}