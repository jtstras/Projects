// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 6 - Problem 1

#include <iostream>
#include <string>
#include <fstream>
#include "Planet.h"
#include <cmath>
using namespace std;

//Member functions for Planet class

double pi = 3.1415926535897932384626433832795028841971;//pi for about thirty digits

Planet::Planet()//constructor
{
    planetName="";
    planetRadius=0.0;
}

Planet::Planet(string s, double num)//parametized constructor that intializes planet name and radius from inputs
{
    planetName=s;
    planetRadius=num;
}

string Planet::getName()//returns planet name
{
    return planetName;
}

void Planet::setName(string j)//sets the planet name to input
{
    planetName=j;
}

double Planet::getRadius()//returns the radius
{
    return planetRadius;
}

void Planet::setRadius(double input)//sets the radius to input
{
    planetRadius=input;
}

double Planet::getVolume()//calculates the volume of the planet using volume of sphere equation
{
    double volume=(1.33333333 * pi *pow(planetRadius,3.0));
}

