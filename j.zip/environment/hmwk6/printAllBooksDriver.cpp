// CS1300 Fall 2019
// CS1300 Fall 2019
// Author: Jaret Strasheim
// Recitation: 304
// Homework 6 - Problem 5

#include <iostream>
#include <string>
#include <fstream>
#include "Book.cpp"
#include <cmath>
using namespace std;

/**
* This function will print all the books in a "book" class object array
* 
* 1.if there are zero or less elements in array, output that there are no books
* 2.else output the list of books using get title and get author member functions
*
 *Input parameters:Planet class array, int for number of elements
 * Output:nothing
 * Returns:index with the planet with largest radius
 */ 

void printAllBooks(Book arr[], int numBooks)
{
    if (numBooks <= 0)//if num of books is 0 or less
    {
        cout<<"No books are stored"<<endl;//output message
    }
    else
    {
         cout<<"Here is a list of books"<<endl;//output message
        for (int i=0;i < numBooks;i++)//as long as i is less than the number of books
        {
        cout << arr[i].getTitle() << " by ";//output the title at index i using the member function get title
        cout << arr[i].getAuthor() << endl;//output the author at index i using the member function get author
        }
    }
}

int main()
{
//test 1
//expected output:Here is a list of books (list of the books in the books array and the corresponding author)
// print three books
Book books[3];

// putting books in the books array
books[0].setTitle("My Big Fun Adventure");
books[0].setAuthor("Mozzart");

books[1].setTitle("Wikipedia The Movie");
books[1].setAuthor("Santa Claus");

books[2].setTitle("Green Eggs N Ham");
books[2].setAuthor("Mr Man");

printAllBooks(books, 3);

//test 2
//expected output:"No books are stored" because numBooks is 0
// print two books
Book books2[2];

// putting books in the books array
books2[0].setTitle("Penguin Man");
books2[0].setAuthor("Penguin Shelverstein");

books2[1].setTitle("Sandwhich Town");
books2[1].setAuthor("Mom");

printAllBooks(books, 0);

}