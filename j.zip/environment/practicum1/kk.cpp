#include <iostream>
#include <string>
using namespace std;


double waterBill(double gallonsUsed, double lowUsageLimit)
{
    double costPerGallon;
    if (gallonsUsed<= lowUsageLimit)
    {
        costPerGallon=0.012;
    }
    else 
    {
        costPerGallon=0.018;
    }
    double cost=gallonsUsed*costPerGallon;
    return cost;
}

int main()
{
      double test3= waterBill(4000,4000);
  cout<<"test3="<<test3<<endl;
}