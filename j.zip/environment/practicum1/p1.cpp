Practicum 1

13)
double TuitionCost (int units, double costPerUnit )
{
    if (units < 0 || costPerUnit < 0)
    {
        return -1;
    }
    else
    {
        if (units <= 16)
        {
            double cost=units * costPerUnit;
            return cost;
        }
        else
        {
            int excessUnits=units-16;
            double cost=(16*costPerUnit)+(excessUnits)*(costPerUnit * 1/2);
            return cost;
        }
    }
}

12)
int sumOfMultiples (int seed, int cap)
{
    int i=0;int sum=0;
    while (seed * i <= cap)
    {
        sum=sum + (i * seed);
        i++;
    }
    return sum;
}

11)
int prodDigits(int n){
   int p = 1;
   if (n==0)
   {
       return 0;
   }
   while(n!=0){
      p = p * (n%10);
      n = n / 10;
   }
   return p;
}



10)
void stepSizePrint(int start, int end, int step) {
    if (step==0)
    {
        cout<<"Step size cannot be zero."<<endl;
    }
    else if (step > 0) {
        if (end > start) {
            for (int i = start; i < end; i += step) {
                cout << i << endl;
            }
        } else {
            cout << "Wrong settings!" << endl;
        }
    } else if (step < 0) {
        if (end < start) {
            for (int i = start; i > end; i += step) {
                cout << i << endl;
            }
        } else {
            cout << "Wrong settings!" << endl;
        }
    } else {
        cout << "Wrong settings!" << endl;
    }
}


9)
#include <iostream>

using namespace std;

int addOddMinusEven(int,int);//function prototype

int addOddMinusEven(int a,int b)

{

int oddSum=0;//to hold oddSum

int evenSum=0;//to hold evenSum

for(int i=a;i<b;i++)

{

if(i%2==0)

evenSum+=i;//adding even numbers

else

oddSum+=i;//adding odd numbers

}

return oddSum-evenSum;//return sum

}

8)
double PizzaParty (int numOfPizza, double costPerPizza, double discount)
{
    if (numOfPizza < 10 )
    {
        double cost= (numOfPizza * costPerPizza)+ 10;
        return cost;
    }
    else
    {
        double cost2=numOfPizza * (costPerPizza-(discount * costPerPizza));
        return cost2;
    }
   
}

7)
double PaintHouse (int width, int depth, int windows)
{
    if (width < 0 || depth < 0 || windows < 0)
    {
        return -1;
    }
    else
    {
        int perimeter=2*(width + depth);
        double costOfWall;
        if (perimeter <= 100)
        {
            costOfWall=perimeter * 8;
        }
        else if (perimeter <= 200)
        {
            costOfWall=800 + (10 * (perimeter % 100));
        }
        else
        {
              costOfWall=1800+(15 * (perimeter % 200));
        }
        double costOfDoorWindow=6.75 * windows;
        double totalcost=costOfWall+costOfDoorWindow;
    }
}

*Failed Hidden Tests?LAST

6)
void numberDigits(int n){
   int count = 0, val = n;
   if(n == 0){
      count = 1;
   }
   else{
      while(n!=0){
         n = n / 10;
         count++;
      }
   }
   cout<<"The number " <<val<< " has " <<count<< " digits."<<endl;
}

5)
void LeavesPerTree(double leavesRaked)
{
    double leavesTree=0.001*10000;
    double leavesPer=leavesRaked-leavesTree;
    cout<<leavesPer;
    leaf weight/input/trees
    if (leavesPer>10,000)
    {
        cout<<"More leaves than last year"<<endl;
    }
}

 leaf weight/input/trees
 
 ***NOT CORRECT


4)
double GasBill (int unitsUsed)
{
    double cost;
    if (unitsUsed < 0)
    {
        cout<<"Incorrect input"<<endl;
        return 0;
    }
    else
    {
        if (unitsUsed < 100)
        {
            cost=unitsUsed*1.23;
        }
        else if (unitsUsed < 200)
        {
            cost=123 + ((unitsUsed % 100) * 1.14);
        }
        else 
        {
            cost=237 + ((unitsUsed % 200)*1.08);
        }
        return cost;
    }
}


3)
void DayOfWeek (int dayOfWeek)
{
    if (dayOfWeek == 1)
    {
        cout<<"MONDAY"<<endl;
    }
    else if (dayOfWeek == 2 || dayOfWeek == 3 || dayOfWeek == 4)
    {
        cout<<"WORKDAY"<<endl;
    }
    else if (dayOfWeek == 5)
    {
        cout<<"FUNDAY"<<endl;
    }
    else if (dayOfWeek == 6 || dayOfWeek==0)
    {
        cout<<"SLEEPDAY"<<endl;
    }
    else
    {
        cout<<"INVALID"<<endl;
    }
    
2)
void calculator(double d1, double d2, char ch){
   double result;
   switch(ch){
      case '+':
         result=d1+d2;
         break;
      case '-':
         result=d1-d2;
         break;
      case '*':
         result=d1*d2;
         break;
      case '/':
         result=d1/d2;
         break;
      default:
         cout<<"Invalid operator!"<<endl;
         return;
   }
   cout<<d1<<" "<<ch<<" "<<d2<<" = "<<setprecision(2)<<result<<endl;
}
    

1)
double CoffeeCost(int no_of_cups, double price_per_cup)

{

double total_amount;

int freecup=0;

if (price_per_cup==0)
{
    return 0;
}

if (no_of_cups<=12)

{

return no_of_cups*price_per_cup;

}

else if (no_of_cups>=13)

{

freecup==no_of_cups/13;

double value=(no_of_cups*price_per_cup)-freecup-3;

}

}

*Failed Hidden tests








