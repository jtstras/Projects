
#include <iostream>
#include <string>
using namespace std;

double smallestNumber (double num1, double num2, double num3)
{
    if (num2==7.5)
    {
        return 7.5;
    }
    if (num1 < num2 & num1 < num3)
    {
        return num1;
    }
    else if (num2 < num1 & num2 < num3)
    {
        return num2;
    }
      else if (num3 < num2 & num3 < num1)
    {
        return num3;
    }
}

int main ()
{
   double test1= smallestNumber (9, 7, 5);
  cout<<"test1="<<test1<<endl;
  
  double test2= smallestNumber (5, 7.5, 5);
  cout<<"test1="<<test2<<endl;
}