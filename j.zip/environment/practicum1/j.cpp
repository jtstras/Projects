
#include <iostream>
#include <string>
using namespace std;

void printSeriesSquareFifth(int n) {
	int sum = 0;
	
	for(int i=1;i<=n;i++)
	{
	     if (i%5 == 0) {
            //If the number is divisible by 5, print its square and add the square to the sum
            cout << i*i;
            sum = sum + i*i;
	     }
        else {
            //If the number is not divisible by 5, print the number and add the number to the sum
            cout << i;
            sum = sum + i;
        }
          if (i != n){
            //This check is added to not print the last '+'
            cout << " + ";
        }
	}
	 cout << endl << "Result of the series is "<< sum << endl;
	}

int main()
{
    //test 1
    printSeriesSquareFifth(6);
    
    //test 2
    printSeriesSquareFifth(15);
}