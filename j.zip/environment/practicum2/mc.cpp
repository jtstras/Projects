// + to concatenate strings
//offset.png for offset question
//add for loops together for value of 2D array set to count
//for an array[5], 5 is an invalid index
//Only the column size must be a constant provided as an argument to the function
//By default, arrays are passed by reference to a function.
//a. out_file << name "this writes a name to data file"
//Replacing cin II. Replace all occurrences of > > and get_line with the appropriate operations for ifstream objects DONT
//Call-by-reference parameters are passed ACTUAL ARGUMENT
//The statement results in an error because the + operation cannot be performed on string literals.
// a. str.substr(0, 5) extracts five 
// while(inFile >> intOne >> intTwo) reads one of two int values into each

//If the name of the input file was in a variable named filename, which of the following is the correct way to open the input stream named inFile and associate it with this file?
// inFile.open(filename);




ifstream in_file;
in_file.open("C:\users\documents\File.txt");//ERROR


int mymarks[10];
int total;
for (int cnt = 1; cnt <= 10; cnt++)
{
  cout << "Enter the marks: ";
  cin >> mymarks[cnt];
  total = total + mymarks[cnt];
}
cout << total;//bounds error or redundant data




int temp = data[first]; 
data[first] = data[second];
data[second] = temp;//swaps first and second





Assume that the file "Payroll.txt" contains the following data:

Peter 90000

John 90000

Mary Lou 120000

Robert 150000

Simon 150000

What does the following program do?Average is 9000

int main()
{
   string name;
   double total = 0;
   int count = 0;
   double average = 0;
   double payments;
   ifstream read_file;
   read_file.open("Payroll.txt");
   while (read_file >> name >> payments)
   {
      total = total + payments;
      count ++;
   }
   average = total / count;
   cout << "Average: " << average << endl;
   return 0;
}




File.txt contains two lines:

This is line1  
And this is line2
What is the output of the following code snippet?THIS CODE WORKS. 
int main()
{   
   ifstream read_file;
   read_file.open("File.txt");
   
   char line1[80];
   string line2;
   read_file.getline(line1,80);
   getline(read_file, line2);
   
   cout << line1 << endl;
   cout << line2 << endl;
   return 0;
}

The File.txt file contains the statement This is a file. What is the output of the following code snippet? THIS CODE PRINTS THE LINE ONCE
int main()
{
   
   ifstream in_file;
   in_file.open("File.txt");
   
   string str1, str2;
   getline(in_file, str1);
   getline(in_file, str2);
 
   cout << str1 << endl;
   cout << str2 << endl;
   return 0;
}

int i = 0;//this counts the number of words
ifstream in_file;
string myword;
in_file.open("test.txt");
while (in_file >> myword)
{
   i++;
}
cout << i << endl;