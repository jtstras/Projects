#include <iostream>
#include <string>
#include <fstream>

using namespace std;

int split(string split, char delimiter, string words[], int size)
{
int count=0,i=0,reset=0;//declaring three variables we will use all integers

while(i<=split.length()) //loops through the string
{
    if(split[i]==delimiter||split[i]=='\0') //if split at index i or split at i is end of the string
    {
        if(reset!=i) //if start is not equal to i then
        {
            if(count==size)//if count equal to size of array then
            {
            return -1; //returns -1
            }
        words[count++] = split.substr(reset,i-reset); //adds the substring into words array and increments the count by 1
        }
      reset = i+ 1; //assigns i+1 to reset
     }
    i++; //increments i by 1
}
    return count; //returns the count
}


int calcPastries(string filename)
{
    ifstream myfile;
    myfile.open(filename.c_str());
    if (myfile.fail())
    return -1;
    string line;
    string word[2];
    int num=0;
    getline (myfile, line);
     split(line, ',', word, 2);
    /*if ( == "")
    {
        cout<<word[0]<<":"<<word[1]*word[2];
    }*/ 
}

int main ()
{
    
}