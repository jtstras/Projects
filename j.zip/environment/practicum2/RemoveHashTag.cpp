#include <iostream>
#include <string>

using namespace std;

string RemoveHashTag(string s) {
    string result = "";
    for(int i = 0; i < s.size(); ++i) {
        if(s[i] != '#') {
            result += s[i];
        }
    }
    return result;
}

//takes a string as input and removes all the hashtags (#) characters. The function returns a string value without the hashtag characters.