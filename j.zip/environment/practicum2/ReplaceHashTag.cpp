#include <iostream>
#include <string>

using namespace std;

string ReplaceHashTag(string s) {
    string result = "";
    for(int i = 0; i < s.size(); ++i) {
        if(s[i] == '#') {
            result += "@";
        } else {
            result += s[i];
        }
    }
    return result;
}

//Write a function, ReplaceHashTag, that takes a string as input and replaces all the hashtags (#) characters with @ character. 
//The function returns a string representing input string containing # character replaced with @ character.