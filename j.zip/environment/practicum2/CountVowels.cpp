//Write a function, CountVowels, that takes a string as input and count the number of vowels (a,e,i,o,u either upper or lower case) alphabetic characters. 
//The function returns an integer value for the number of vowels.

#include <iostream>

using namespace std;

int CountVowels(string str) // called function

{

int vowels=0; // initially number of vowels is 0

if(str.length()==0) // if string is empty

vowels = -1; // number vowels changed to -1

else{ // if string is not empty

for(int i = 0; str[i]!='\0'; ++i) // Loop to check vowels

    {

        if(str[i]=='a' || str[i]=='e' || str[i]=='i' ||

           str[i]=='o' || str[i]=='u' || str[i]=='A' ||

           str[i]=='E' || str[i]=='I' || str[i]=='O' ||

           str[i]=='U')

           {

            ++vowels; // If there is a vowel then increment count

           }

    }

}

return vowels; // retun number of vowels

}