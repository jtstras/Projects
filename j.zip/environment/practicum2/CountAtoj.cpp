#include <iostream>
using namespace std;

int CountAtoJ (string word)
{
    int count=0;
    if (word.length()==0)
    {
        return -1;
    }
    else
    {
       for (int i=0;word[i] != '\0';i++) 
       {
          if(word[i]=='A' || word[i]=='B' || word[i]=='C' || word[i]=='D' || word[i]=='E' || word[i]=='F' || word[i]=='G' || word[i]=='H' || word[i]=='I' ||word[i]=='J')
           {
               count++;
           }
       }
       if (count==0)
       return -2;
    }
    return count;
}

int main()
{
    cout << CountAtoJ("ALL THE BEST") << endl;
    cout << CountAtoJ("aabbccGhhiijj") << endl;
    cout << CountAtoJ("all the best") << endl;
}