#include <iostream>
#include <string>

using namespace std;

string removeDigits(string s) {
    string result = "";
    for(int i = 0; i < s.size(); ++i) {
        if ( s[i] != 0 || s[i] != 1 || s[i] != 2 || s[i] != 3 || s[i] != 4 || s[i] != 5 || s[i] != 6 ||  s[i] != 7 || s[i] != 8 || s[i] != 9)
        {
           result=s[i]-result;
        }
    }
    return result;
}



int main()
{
cout << removeDigits("8947342873") << endl;
cout << removeDigits("Hello World") << endl;
cout << removeDigits("123132Hello Computer Science World21324") << endl;
}
