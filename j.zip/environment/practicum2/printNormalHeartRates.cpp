#include <iostream>
#include <string>
using namespace std;

void printNormalHeartRates(string patientNames[], int heart_rate[],  int elements) {
    for(int i = 0; i < elements; ++i) {
        if (heart_rate[i] >= 70 && heart_rate[i] <= 190)
        {
               cout<<patientNames[i]<<" "<<heart_rate[i]<<endl;
        }
    }
}

int main ()
{
    	
string patients[4] = {"Joe", "Jack", "Amy", "Bob"};
int heart_rate[4] = {70, 80, 190, 100};
printNormalHeartRates(patients, heart_rate, 4);
}