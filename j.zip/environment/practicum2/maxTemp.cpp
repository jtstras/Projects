// /Write a function maxTemp which takes a filename as string argument and returns the maximum temperature as float type for the week. 
//Input file will contain temperature readings for each day of the week. Your function should read each line from the given filename, parse and process the data, and
//return the required information. Your function should return the highest temperature for the whole week.  Empty lines do not count as entries, and should be ignored. 
//If the input file cannot be opened, return -1. Remember temperature readings can be decimal and negative numbers.


// definition of the function.

float maxTemp(string filename)

{

// declare the variable of type ifstream.

ifstream in;

// open the file.

in.open(filename.c_str());

// check the condition.

if(in.fail())

return -1;

// Declare the string variable.

string line;

string wor[2];

// declare float variable.

float num=0.0;

// call the getline function.

getline(in, line);

// check the condition.

if(split(line, ',', wor, 2)==2)

{

// Assign value to variable.

num=stof(wor[1]);

}

// Start the while loop

while(!in.eof())

{

// call the getline function.

getline(in, line);

// check the condition.

if(split(line, ',', wor, 2)==2)

{

// check the condition

if(num<stof(wor[1]))

{

// Assign value.

num=stof(wor[1]);

}

}

}

// return value.

return num;

}

// Definition of the function.

int Split(string s, char sep, string words[], int max_words)

{

// Declare variable.

istringstream ss(s);

int n=0;

// start the while loop.

while(getline(ss, words[n], sep) && n<max_words){

// Update the vaue.

n++;

}

// return value.

return n;

}