//Write a function, IsAllLower, that takes a string as input and returns true if all the alphabetic characters in the string are lowercase alphabetic characters. 
//The function returns false otherwise. If input string contains non-alphabetic character, return false.

#include<iostream>

using namespace std;

bool IsAllLower(string str){

for(int i=0; i<str.size(); i++){

if(str[i]<'a' || str[i]>'z')

return false;

i++;

}

return true;

}