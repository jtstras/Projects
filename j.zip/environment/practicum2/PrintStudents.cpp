#include <fstream>

#include <iostream>

#include <sstream>

#include <string>

using namespace std;

//Create a function named PrintStudents, which takes a string input filename and an integer minimum score value and a string output file name as a parameters.  
//The function will read the student scores and names from the file and output the names of the students with scores greater than or equal to the value given.  
//This function returns the integer number of entries read from the file.  If the input file cannot be opened, return -1 and do not print anything to the file.

int split(string s, char sep, string words[], int max_words);

int readFile(string inFile, string outFile, int score);

int main()

{

int result = readFile("data.txt", "out.txt", 80);

if (result == 1)

{

cout << "Done" << endl;

}

return 0;

}

int split(string s, char sep, string words[], int max_words)

{

try

{

int counter = 0;

istringstream ss(s);

string token;

//Separate string based on commas and white spaces

while (getline(ss, token, sep))

{

words[counter] = token;

counter++;

}

return 1;

}

catch (const std::exception &e)

{

return 0;

}

}

int readFile(string inputFile, string outFile, int score)

{

ifstream inFile(inputFile);

ofstream outdata(outFile);

int i = 0;

while (inFile)

{

string s;

//Read until no more lines in text file to read

while (getline(inFile, s))

{

string words[4];

int result = split(s, ',', words, 4);

if (stoi(words[1]) >= score)

{

outdata << words[0] << "," << words[1] << "," << words[2] << endl;

}

}

return 1;

}

if (!inFile.eof())

{

return 0;

}

}